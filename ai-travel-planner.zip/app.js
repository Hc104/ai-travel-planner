
// ========================================
// 图片懒加载优化
// ========================================
function initImageLazyLoad() {
    if ('IntersectionObserver' in window) {
        var lazyObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    var img = entry.target;
                    var src = img.getAttribute('data-src');
                    if (src) {
                        img.src = src;
                        img.removeAttribute('data-src');
                    }
                    observer.unobserve(img);
                }
            });
        }, {
            rootMargin: '50px',
            threshold: 0.1
        });

        document.querySelectorAll('img[data-src]').forEach(function(img) {
            lazyObserver.observe(img);
        });
    } else {
        document.querySelectorAll('img[data-src]').forEach(function(img) {
            img.src = img.getAttribute('data-src');
            img.removeAttribute('data-src');
        });
    }
}

// ========================================
// localStorage 存储清理机制
// ========================================
function cleanupLocalStorage() {
    try {
        var EXPIRE_DAYS = 30;

        var historyStr = localStorage.getItem(HISTORY_KEY);
        if (historyStr) {
            var history = JSON.parse(historyStr);
            var now = Date.now();
            var expireTime = EXPIRE_DAYS * 24 * 60 * 60 * 1000;
            
            // 过滤过期记录
            history = history.filter(function(item) {
                return item.timestamp && (now - item.timestamp < expireTime);
            });
            
            // 过滤旧格式记录（无version或version < '2'）
            history = history.filter(function(item) {
                return item.version && item.version >= '2';
            });
            
            if (history.length > MAX_HISTORY) {
                history = history.slice(0, MAX_HISTORY);
            }
            
            localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
        }

        var detailKey = '_currentAttractionDetail';
        var detailStr = localStorage.getItem(detailKey);
        if (detailStr) {
            try {
                var detail = JSON.parse(detailStr);
                if (detail.timestamp && (now - detail.timestamp > expireTime)) {
                    localStorage.removeItem(detailKey);
                }
            } catch(e) {
                localStorage.removeItem(detailKey);
            }
        }
    } catch(e) {
        console.warn('localStorage cleanup failed:', e);
    }
}

// ========================================
// 高德JS API 插件（输入提示 + 路线规划）
// ========================================

var HISTORY_KEY = 'travel_planner_history_v1';
var MAX_HISTORY = 10;

var hotCityData = [
    { name: "北京", lng: 116.397128, lat: 39.916527 },
    { name: "上海", lng: 121.473658, lat: 31.230378 },
    { name: "广州", lng: 113.264385, lat: 23.129112 },
    { name: "深圳", lng: 114.054539, lat: 22.546555 },
    { name: "成都", lng: 104.065735, lat: 30.659462 },
    { name: "杭州", lng: 120.153576, lat: 30.287459 },
    { name: "重庆", lng: 106.504962, lat: 29.533155 },
    { name: "西安", lng: 108.948024, lat: 34.263161 },
    { name: "大理", lng: 100.225516, lat: 25.590698 },
    { name: "三亚", lng: 109.508268, lat: 18.247872 },
    { name: "厦门", lng: 118.112392, lat: 24.489696 },
    { name: "丽江", lng: 100.232709, lat: 26.871241 },
    { name: "长沙", lng: 112.982279, lat: 28.19409 },
    { name: "武汉", lng: 114.298572, lat: 30.584355 },
    { name: "南京", lng: 118.767413, lat: 32.041544 },
    { name: "青岛", lng: 120.355173, lat: 36.082982 }
];

// 已支持完整攻略的目的地城市（有完整景点/美食/行程数据）
const supportedDestinationCities = [
    { name: '成都', emoji: '\u{1F43C}', desc: '美食之都', lng: 104.065735, lat: 30.659462 },
    { name: '杭州', emoji: '\u{1F30A}', desc: '人间天堂', lng: 120.153576, lat: 30.287459 },
    { name: '北京', emoji: '\u{1F3DB}', desc: '皇城古都', lng: 116.397128, lat: 39.916527 },
    { name: '西安', emoji: '\u{1F3EF}', desc: '千年古都', lng: 108.948024, lat: 34.263161 },
    { name: '上海', emoji: '\u{1F303}', desc: '魔都风情', lng: 121.473658, lat: 31.230378 },
    { name: '大理', emoji: '\u{1F3D4}', desc: '风花雪月', lng: 100.225516, lat: 25.590698 },
    { name: '重庆', emoji: '\u{1F336}', desc: '8D魔幻', lng: 106.504962, lat: 29.533155 },
    { name: '三亚', emoji: '\u{1F3D6}', desc: '热带海岛', lng: 109.508268, lat: 18.247872 },
    { name: '丽江', emoji: '\u{1F3D8}', desc: '古城雪山', lng: 100.232709, lat: 26.871241 },
    { name: '桂林', emoji: '\u{26F0}', desc: '山水甲天下', lng: 110.290023, lat: 25.273566 },
    { name: '厦门', emoji: '\u{1F334}', desc: '文艺小岛', lng: 118.112392, lat: 24.489696 },
    { name: '张家界', emoji: '\u{1F3DE}', desc: '奇峰仙境', lng: 110.478920, lat: 29.117080 },
    { name: '长沙', emoji: '\u{1F35C}', desc: '美食星城', lng: 112.982279, lat: 28.194090 },
    { name: '苏州', emoji: '\u{1F3E1}', desc: '江南水乡', lng: 120.619585, lat: 31.299379 },
    { name: '青岛', emoji: '\u{1F37A}', desc: '啤酒之都', lng: 120.355173, lat: 36.082982 },
    { name: '南京', emoji: '\u{1F986}', desc: '六朝古都', lng: 118.767413, lat: 32.041544 }
];

// 中国主要机场数据（城市名 -> 机场信息，含坐标用于距离计算）
const airportData = {
    '北京': [{code:'PEK',name:'首都国际机场',lng:116.5844,lat:40.0799},{code:'PKX',name:'大兴国际机场',lng:116.4105,lat:39.5088}],
    '上海': [{code:'SHA',name:'虹桥国际机场',lng:121.3363,lat:31.1979},{code:'PVG',name:'浦东国际机场',lng:121.8083,lat:31.1443}],
    '广州': [{code:'CAN',name:'白云国际机场',lng:113.2988,lat:23.3924}],
    '深圳': [{code:'SZX',name:'宝安国际机场',lng:113.8108,lat:22.6395}],
    '成都': [{code:'CTU',name:'双流国际机场',lng:103.9471,lat:30.5785},{code:'TFU',name:'天府国际机场',lng:104.4456,lat:30.3194}],
    '重庆': [{code:'CKG',name:'江北国际机场',lng:106.6417,lat:29.7192}],
    '杭州': [{code:'HGH',name:'萧山国际机场',lng:120.4303,lat:30.2359}],
    '南京': [{code:'NKG',name:'禄口国际机场',lng:118.8613,lat:31.7420}],
    '武汉': [{code:'WUH',name:'天河国际机场',lng:114.2081,lat:30.7838}],
    '西安': [{code:'XIY',name:'咸阳国际机场',lng:108.7514,lat:34.4371}],
    '长沙': [{code:'CSX',name:'黄花国际机场',lng:113.2209,lat:28.1892}],
    '郑州': [{code:'CGO',name:'新郑国际机场',lng:113.8411,lat:34.2085}],
    '天津': [{code:'TSN',name:'滨海国际机场',lng:117.3463,lat:39.1244}],
    '昆明': [{code:'KMG',name:'长水国际机场',lng:102.9292,lat:25.1019}],
    '厦门': [{code:'XMN',name:'高崎国际机场',lng:118.1278,lat:24.5439}],
    '青岛': [{code:'TAO',name:'胶东国际机场',lng:120.3744,lat:36.3986}],
    '大连': [{code:'DLC',name:'周水子国际机场',lng:121.5381,lat:38.9657}],
    '三亚': [{code:'SYX',name:'凤凰国际机场',lng:109.4123,lat:18.3028}],
    '海口': [{code:'HAK',name:'美兰国际机场',lng:110.3539,lat:19.9349}],
    '丽江': [{code:'LJG',name:'三义国际机场',lng:100.2299,lat:26.6816}],
    '大理': [{code:'DLU',name:'凤仪机场',lng:100.1875,lat:25.6497}],
    '桂林': [{code:'KWL',name:'两江国际机场',lng:110.3040,lat:25.2139}],
    '贵阳': [{code:'KWE',name:'龙洞堡国际机场',lng:106.8009,lat:26.5844}],
    '福州': [{code:'FOC',name:'长乐国际机场',lng:119.6626,lat:25.9339}],
    '济南': [{code:'TNA',name:'遥墙国际机场',lng:117.2160,lat:36.5126}],
    '沈阳': [{code:'SHE',name:'桃仙国际机场',lng:123.4838,lat:41.6397}],
    '哈尔滨': [{code:'HRB',name:'太平国际机场',lng:126.2497,lat:45.6234}],
    '长春': [{code:'CGQ',name:'龙嘉国际机场',lng:125.6847,lat:43.9966}],
    '南宁': [{code:'NNG',name:'吴圩国际机场',lng:108.1722,lat:22.6286}],
    '南昌': [{code:'KHN',name:'昌北国际机场',lng:115.8960,lat:28.8444}],
    '合肥': [{code:'HFE',name:'新桥国际机场',lng:117.0517,lat:31.7797}],
    '石家庄': [{code:'SJW',name:'正定国际机场',lng:114.5103,lat:38.2808}],
    '太原': [{code:'TYN',name:'武宿国际机场',lng:112.6250,lat:37.7186}],
    '兰州': [{code:'LHW',name:'中川国际机场',lng:103.6203,lat:36.5153}],
    '乌鲁木齐': [{code:'URC',name:'地窝堡国际机场',lng:87.4737,lat:43.9084}],
    '拉萨': [{code:'LXA',name:'贡嘎国际机场',lng:90.9111,lat:29.2977}],
    '呼和浩特': [{code:'HET',name:'白塔国际机场',lng:111.8134,lat:40.5497}],
    '西宁': [{code:'XNN',name:'曹家堡机场',lng:101.7034,lat:36.5425}],
    '银川': [{code:'INC',name:'河东国际机场',lng:106.3925,lat:38.3197}],
    '温州': [{code:'WNZ',name:'龙湾国际机场',lng:120.8547,lat:27.9055}],
    '宁波': [{code:'NGB',name:'栎社国际机场',lng:121.4622,lat:29.8266}],
    '珠海': [{code:'ZUH',name:'金湾机场',lng:113.3764,lat:22.0066}],
    '无锡': [{code:'WUX',name:'苏南硕放国际机场',lng:120.4328,lat:31.4972}],
    '苏州': [{code:'WUX',name:'苏南硕放国际机场',lng:120.4328,lat:31.4972}],
    '烟台': [{code:'YNT',name:'蓬莱国际机场',lng:120.9633,lat:37.6586}],
    '泉州': [{code:'JJN',name:'晋江国际机场',lng:118.5433,lat:24.7947}],
    '揭阳': [{code:'SWA',name:'潮汕国际机场',lng:116.5220,lat:23.5462}],
    '北海': [{code:'BHY',name:'福成机场',lng:109.2839,lat:21.5278}],
    '张家界': [{code:'DYG',name:'荷花国际机场',lng:110.4375,lat:29.1069}],
    '西双版纳': [{code:'JHG',name:'嘎洒国际机场',lng:100.7997,lat:22.0083}],
    '九寨沟': [{code:'JZH',name:'黄龙机场',lng:103.7369,lat:33.2503}],
    '黄山': [{code:'TXN',name:'屯溪国际机场',lng:118.2722,lat:29.7147}],
    '敦煌': [{code:'DNH',name:'莫高国际机场',lng:94.6622,lat:40.1422}],
    '香格里拉': [{code:'DIG',name:'迪庆机场',lng:99.7078,lat:27.7803}],
    '稻城': [{code:'DCY',name:'亚丁机场',lng:100.2983,lat:28.4422}],
    '腾冲': [{code:'TCZ',name:'驼峰机场',lng:98.4953,lat:25.0147}],
    '延安': [{code:'ENY',name:'南泥湾机场',lng:109.5544,lat:36.5189}],
    '宜昌': [{code:'YIH',name:'三峡机场',lng:111.4414,lat:30.5556}],
    '洛阳': [{code:'LYA',name:'北郊机场',lng:112.3747,lat:34.7447}],
    '徐州': [{code:'XUZ',name:'观音国际机场',lng:117.2311,lat:34.0539}],
    '常州': [{code:'CZX',name:'奔牛机场',lng:119.7786,lat:31.9189}],
    '南通': [{code:'NTG',name:'兴东机场',lng:120.9739,lat:32.0678}],
    '扬州': [{code:'YTY',name:'泰州国际机场',lng:119.7114,lat:32.5567}],
    '连云港': [{code:'LYG',name:'白塔埠机场',lng:119.2758,lat:34.5692}],
    '盐城': [{code:'YNZ',name:'南洋机场',lng:120.1614,lat:33.4433}],
    '义乌': [{code:'YIW',name:'义乌机场',lng:120.0319,lat:29.3111}],
    '舟山': [{code:'HSN',name:'普陀山机场',lng:122.3606,lat:29.9447}],
    '湛江': [{code:'ZHA',name:'吴川机场',lng:110.3589,lat:21.2017}],
    '包头': [{code:'BAV',name:'东河机场',lng:109.9728,lat:40.5622}],
    '鄂尔多斯': [{code:'DSN',name:'伊金霍洛机场',lng:109.7864,lat:39.4858}],
    '满洲里': [{code:'NZH',name:'西郊机场',lng:117.3217,lat:49.4039}],
    '延吉': [{code:'YNJ',name:'朝阳川机场',lng:129.4150,lat:42.8828}],
    '赣州': [{code:'KOW',name:'黄金国际机场',lng:114.8953,lat:25.8233}],
    '景德镇': [{code:'JDZ',name:'罗家机场',lng:117.1697,lat:29.3167}],
    '宜宾': [{code:'YBP',name:'菜坝机场',lng:104.5336,lat:28.8511}],
    '泸州': [{code:'LZO',name:'蓝田机场',lng:105.3875,lat:28.8528}],
    '绵阳': [{code:'MIG',name:'南郊机场',lng:104.7347,lat:31.4275}],
    '南充': [{code:'NAO',name:'高坪机场',lng:106.0636,lat:30.7853}],
    '遵义': [{code:'ZYI',name:'新舟机场',lng:106.9803,lat:27.8947}],
    '毕节': [{code:'BFJ',name:'飞雄机场',lng:105.3617,lat:27.1664}],
    '安顺': [{code:'AVA',name:'黄果树机场',lng:105.8947,lat:26.2519}],
    '铜仁': [{code:'TEN',name:'凤凰机场',lng:109.2025,lat:27.9839}],
    '柳州': [{code:'LZH',name:'白莲机场',lng:109.3869,lat:24.2247}],
    '威海': [{code:'WEH',name:'大水泊机场',lng:122.2397,lat:37.1861}],
    '临沂': [{code:'LYI',name:'沭埠岭机场',lng:118.4236,lat:35.0617}],
    '潍坊': [{code:'WEF',name:'南苑机场',lng:119.1172,lat:36.6408}],
    '济宁': [{code:'JNG',name:'曲阜机场',lng:116.7581,lat:35.5567}],
    '大同': [{code:'DAT',name:'云冈机场',lng:113.4089,lat:40.0408}],
    '长治': [{code:'CIH',name:'王村机场',lng:113.1281,lat:36.2483}],
    '南阳': [{code:'NNY',name:'姜营机场',lng:112.6228,lat:32.9828}],
    '襄阳': [{code:'XFN',name:'刘集机场',lng:112.2942,lat:32.4078}],
    '恩施': [{code:'ENH',name:'许家坪机场',lng:109.4864,lat:30.3189}],
    '万州': [{code:'WXN',name:'五桥机场',lng:108.4217,lat:30.8067}],
    '达州': [{code:'DAX',name:'河市坝机场',lng:107.2683,lat:31.1544}],
    '广元': [{code:'GYS',name:'盘龙机场',lng:105.6481,lat:32.3969}],
    '林芝': [{code:'LZY',name:'米林机场',lng:94.3364,lat:29.2928}],
    '日喀则': [{code:'RKZ',name:'和平机场',lng:88.8811,lat:29.2564}],
    '普洱': [{code:'SYM',name:'思茅机场',lng:100.9567,lat:22.7978}],
    '百色': [{code:'AEB',name:'机场',lng:106.9633,lat:23.8122}],
    '榆林': [{code:'UYN',name:'榆阳机场',lng:109.7253,lat:38.2783}],
    '汉中': [{code:'HZG',name:'西关机场',lng:107.0361,lat:33.0631}],
    '天水': [{code:'THQ',name:'麦积山机场',lng:105.7972,lat:34.5581}],
    '武夷山': [{code:'WUS',name:'机场',lng:118.0003,lat:27.8286}],
    '井冈山': [{code:'JGS',name:'机场',lng:114.7167,lat:26.8533}],
    '攀枝花': [{code:'PZI',name:'保安营机场',lng:101.9806,lat:26.6317}],
    '西昌': [{code:'XIC',name:'青山机场',lng:102.1847,lat:27.8983}],
    '兴义': [{code:'ACX',name:'万峰林机场',lng:104.9569,lat:25.0872}],
    '琼海': [{code:'BAR',name:'博鳌机场',lng:110.4611,lat:19.1414}],
    '惠州': [{code:'HUZ',name:'平潭机场',lng:114.6100,lat:23.1747}],
    '梅州': [{code:'MXZ',name:'梅县机场',lng:116.0964,lat:24.3100}],
    '常德': [{code:'CGD',name:'桃花源机场',lng:111.6389,lat:28.9114}],
    '永州': [{code:'LLF',name:'零陵机场',lng:111.6175,lat:26.3964}]
};

// 检查城市是否有机场
function hasAirport(cityName) {
    if (!cityName) return false;
    if (airportData[cityName]) return true;
    for (const city of Object.keys(airportData)) {
        if (cityName.includes(city) || city.includes(cityName)) return true;
    }
    return false;
}

// 获取城市的机场信息
function getAirportInfo(cityName) {
    if (!cityName) return null;
    if (airportData[cityName]) return airportData[cityName];
    for (const [city, airports] of Object.entries(airportData)) {
        if (cityName.includes(city) || city.includes(cityName)) return airports;
    }
    return null;
}

// 查找离目标坐标最近的有机场城市（用于中转方案）
function findNearestAirportCity(destLng, destLat, destCity, maxDistKm) {
    maxDistKm = maxDistKm || 300; // 默认300km范围内找机场
    let nearest = null;
    let minDist = Infinity;
    for (const [city, airports] of Object.entries(airportData)) {
        // 跳过目标城市自身
        if (city === destCity) continue;
        if (destCity && (destCity.includes(city) || city.includes(destCity))) continue;
        for (const ap of airports) {
            const dLng = (ap.lng - destLng) * 111 * Math.cos((ap.lat + destLat) / 2 * Math.PI / 180);
            const dLat = (ap.lat - destLat) * 111;
            const dist = Math.sqrt(dLng * dLng + dLat * dLat);
            if (dist < minDist && dist <= maxDistKm) {
                minDist = dist;
                nearest = { city: city, airport: ap, distKm: Math.round(dist) };
            }
        }
    }
    return nearest;
}

// 高德输入提示（使用JS API插件）
function searchAmapPlaces(keyword) {
    return new Promise((resolve) => {
        if (!keyword || keyword.trim().length < 2) { resolve([]); return; }
        try {
            const autoComplete = new AMap.AutoComplete({ city: '全国' });
            autoComplete.search(keyword, (status, result) => {
                if (status === 'complete' && result.tips) {
                    const results = result.tips
                        .filter(t => t.location && t.location.lng && t.location.lat && t.name && t.name !== '[]')
                        .map(t => ({
                            name: t.name,
                            district: t.district || '',
                            address: t.address || '',
                            type: t.typecode ? getTypeName(t.typecode) : '',
                            lng: t.location.lng,
                            lat: t.location.lat
                        }));
                    resolve(results.slice(0, 10));
                } else {
                    resolve([]);
                }
            });
        } catch (e) {
            console.error('搜索失败:', e);
            resolve([]);
        }
    });
}

function getTypeName(typecode) {
    const code = typecode.toString();
    if (code.startsWith('19')) return '地铁站';
    if (code.startsWith('15')) return '火车站';
    if (code.startsWith('01')) return '景点';
    if (code.startsWith('05')) return '餐饮';
    if (code.startsWith('10')) return '酒店';
    if (code.startsWith('06')) return '购物';
    if (code.startsWith('16')) return '机场';
    if (code.startsWith('170')) return '风景名胜';
    return '';
}

// 高德POI周边搜索（美食店铺）
function searchNearbyFood(keyword, city, lng, lat) {
    return new Promise(function(resolve) {
        if (!keyword || !lng || !lat) { resolve([]); return; }
        try {
            AMap.plugin('AMap.PlaceSearch', function() {
                var placeSearch = new AMap.PlaceSearch({
                    type: '050000',  // 餐饮服务
                    city: city || '',
                    citylimit: true,
                    pageSize: 10,
                    pageIndex: 1,
                    extensions: 'all'
                });
                var center = new AMap.LngLat(parseFloat(lng), parseFloat(lat));
                placeSearch.searchNearBy(keyword, center, 5000, function(status, result) {
                    if (status === 'complete' && result.poiList && result.poiList.pois) {
                        var pois = result.poiList.pois.map(function(p) {
                            return {
                                name: p.name,
                                address: p.address || '',
                                tel: p.tel || '',
                                dist: p.distance ? Math.round(p.distance) : 0,
                                lng: p.location ? p.location.lng : 0,
                                lat: p.location ? p.location.lat : 0,
                                rating: p.biz_ext && p.biz_ext.rating ? p.biz_ext.rating : '',
                                cost: p.biz_ext && p.biz_ext.cost ? p.biz_ext.cost : '',
                                type: p.typeName || '',
                                photos: p.photos || []
                            };
                        }).filter(function(p) { return p.lng && p.lat; });
                        // 按网络热度排序：有评分的优先，评分高的在前；无评分的按距离排序
                        pois.sort(function(a, b) {
                            var scoreA = a.rating ? parseFloat(a.rating) : 0;
                            var scoreB = b.rating ? parseFloat(b.rating) : 0;
                            if (scoreA > 0 && scoreB > 0) return scoreB - scoreA;
                            if (scoreA > 0) return -1;
                            if (scoreB > 0) return 1;
                            return a.dist - b.dist;
                        });
                        resolve(pois);
                    } else {
                        resolve([]);
                    }
                });
            });
        } catch (e) {
            console.error('POI搜索失败:', e);
            resolve([]);
        }
    });
}

// 高德驾车路线规划（使用JS API插件）
function getDrivingRoute(oLng, oLat, dLng, dLat) {
    return new Promise((resolve, reject) => {
        try {
            const driving = new AMap.Driving({ policy: AMap.DrivingPolicy.LEAST_TIME });
            driving.search(
                new AMap.LngLat(oLng, oLat),
                new AMap.LngLat(dLng, dLat),
                (status, result) => {
                    if (status === 'complete' && result.routes && result.routes.length > 0) {
                        const route = result.routes[0];
                        resolve({
                            distance: route.distance,
                            time: route.time,
                            tolls: route.tolls || 0
                        });
                    } else {
                        reject(new Error('路线规划失败: ' + status));
                    }
                }
            );
        } catch (e) { reject(e); }
    });
}

// 高德公交换乘查询（含城际火车真实班次）
function getTrainRoutes(depCity, destCity, oLng, oLat, dLng, dLat) {
    return new Promise((resolve) => {
        try {
            AMap.plugin('AMap.Transfer', function() {
                const transfer = new AMap.Transfer({
                    city: depCity,
                    cityd: destCity,
                    policy: AMap.TransferPolicy.LEAST_TIME
                });
                transfer.search(
                    new AMap.LngLat(oLng, oLat),
                    new AMap.LngLat(dLng, dLat),
                    function(status, result) {
                        if (status === 'complete' && result.plans) {
                            const trains = [];
                            result.plans.forEach(plan => {
                                plan.segments.forEach(seg => {
                                    if (seg.transit_mode === 'RAILWAY' && seg.transit) {
                                        const t = seg.transit;
                                        const rawDep = t.departure_stop ? t.departure_stop.time : '';
                                        const rawArr = t.arrival_stop ? t.arrival_stop.time : '';
                                        const depTime = rawDep ? String(rawDep).padStart(4, '0') : '';
                                        const arrTime = rawArr ? String(rawArr).padStart(4, '0') : '';
                                        const depStation = t.departure_stop ? t.departure_stop.name : '';
                                        const arrStation = t.arrival_stop ? t.arrival_stop.name : '';
                                        // 提取最优价格（优先二等座）
                                        let bestPrice = null, priceLabel = '';
                                        const seen = new Set();
                                        if (t.spaces) {
                                            const priority = ['火车二等座', '火车硬座', '火车硬卧中铺', '火车硬卧下铺', '火车硬卧上铺', '火车软卧下铺', '火车软卧上铺', '火车一等座', '火车商务座', '火车无座'];
                                            for (const label of priority) {
                                                const match = t.spaces.find(s => s.type === label);
                                                if (match && !seen.has(match.cost) && match.cost > 0) {
                                                    seen.add(match.cost);
                                                    if (!bestPrice) { bestPrice = match.cost; priceLabel = label; }
                                                }
                                            }
                                            // 如果优先列表没找到，取第一个有效价格
                                            if (!bestPrice && t.spaces.length > 0) {
                                                for (const s of t.spaces) {
                                                    if (s.cost > 0 && !seen.has(s.cost)) {
                                                        bestPrice = s.cost; priceLabel = s.type; break;
                                                    }
                                                }
                                            }
                                        }
                                        trains.push({
                                            name: t.name || '',
                                            type: t.type || '',
                                            trip: t.trip || '',
                                            depStation: depStation,
                                            arrStation: arrStation,
                                            depTime: depTime,
                                            arrTime: arrTime,
                                            duration: seg.time || 0,
                                            cost: bestPrice || 0,
                                            priceLabel: priceLabel,
                                            allSpaces: t.spaces || []
                                        });
                                    }
                                });
                            });
                            // 去重（同名车次）
                            const unique = [];
                            const seenNames = new Set();
                            trains.forEach(t => {
                                const key = t.trip || t.name;
                                if (!seenNames.has(key)) {
                                    seenNames.add(key);
                                    unique.push(t);
                                }
                            });
                            resolve(unique);
                        } else {
                            resolve([]);
                        }
                    }
                );
            });
        } catch (e) {
            console.error('火车查询失败:', e);
            resolve([]);
        }
    });
}

// ========================================
// 城市选择器组件
// ========================================
class CitySelector {
    constructor(type) {
        this.type = type;
        this.selectedCity = '';
        this.selectedLng = null;
        this.selectedLat = null;
        this.isOpen = false;
        this.searchTimer = null;

        this.inputEl = document.getElementById(type + 'Input');
        this.hiddenInput = document.getElementById(type + 'City');
        this.lngInput = document.getElementById(type + 'Lng');
        this.latInput = document.getElementById(type + 'Lat');
        this.dropdownEl = document.getElementById(type + 'Dropdown');
        this.searchInput = document.getElementById(type + 'Search');
        this.searchResults = document.getElementById(type + 'SearchResults');
        this.hotCitiesEl = document.getElementById(type + 'HotCities');
        this.init();
    }

    init() {
        // 根据类型渲染不同的城市列表
        if (this.type === 'departure') {
            this.renderHotCities();
        } else {
            this.renderSupportedCities();
        }
        this.inputEl.addEventListener('click', (e) => { e.stopPropagation(); this.toggle(); });
        this.searchInput.addEventListener('input', (e) => {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(() => this.onSearch(e.target.value), 300);
        });
        document.addEventListener('click', (e) => {
            if (!this.dropdownEl.contains(e.target) && !this.inputEl.contains(e.target)) this.close();
        });
        this.dropdownEl.addEventListener('click', (e) => e.stopPropagation());
        this.searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') this.close();
            if (e.key === 'Enter') {
                var firstResult = this.searchResults.querySelector('.search-result-item');
                if (firstResult) firstResult.click();
            }
        });
    }

    toggle() { this.isOpen ? this.close() : this.open(); }

    open() {
        this.isOpen = true;
        this.dropdownEl.classList.add('show');
        this.inputEl.classList.add('active');
        this.searchInput.value = '';
        this.searchResults.classList.remove('show');
        setTimeout(() => this.searchInput.focus(), 100);
    }

    close() {
        this.isOpen = false;
        this.dropdownEl.classList.remove('show');
        this.inputEl.classList.remove('active');
    }

    selectPlace(name, lng, lat, district) {
        this.selectedCity = name;
        this.selectedLng = lng;
        this.selectedLat = lat;
        this.hiddenInput.value = name;
        this.lngInput.value = lng;
        this.latInput.value = lat;
        var display = district ? name + ' (' + district + ')' : name;
        this.inputEl.innerHTML = '<span class="city-value">' + display + '</span><svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        this.hotCitiesEl.querySelectorAll('.city-tag, .supported-city-tag').forEach(function(t) { t.classList.toggle('selected', t.dataset.city === name); });
        // 触发 change 事件让表单验证能检测到
        this.hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
        this.close();
    }

    renderHotCities() {
        this.hotCitiesEl.innerHTML = hotCityData.map(function(c) {
            return '<div class="city-tag" data-city="' + c.name + '" data-lng="' + c.lng + '" data-lat="' + c.lat + '">' + c.name + '</div>';
        }).join('');
        this.hotCitiesEl.querySelectorAll('.city-tag').forEach(function(tag) {
            tag.addEventListener('click', function() {
                this.selectPlace(tag.dataset.city, parseFloat(tag.dataset.lng), parseFloat(tag.dataset.lat), '');
            }.bind(this));
        }.bind(this));
    }

    renderSupportedCities() {
        this.hotCitiesEl.innerHTML = supportedDestinationCities.map(function(c) {
            return '<div class="supported-city-tag" data-city="' + c.name + '" data-lng="' + c.lng + '" data-lat="' + c.lat + '">' +
                '<span class="supported-city-emoji">' + c.emoji + '</span>' +
                '<span class="supported-city-name">' + c.name + '</span>' +
                '<span class="supported-city-desc">' + c.desc + '</span>' +
                '<span class="supported-city-badge">完整攻略</span>' +
            '</div>';
        }).join('');
        this.hotCitiesEl.querySelectorAll('.supported-city-tag').forEach(function(tag) {
            tag.addEventListener('click', function() {
                this.selectPlace(tag.dataset.city, parseFloat(tag.dataset.lng), parseFloat(tag.dataset.lat), '');
            }.bind(this));
        }.bind(this));
    }

    async onSearch(keyword) {
        if (!keyword || keyword.trim().length < 2) { this.searchResults.classList.remove('show'); return; }
        this.searchResults.innerHTML = '<div class="search-loading">🔍 搜索中...</div>';
        this.searchResults.classList.add('show');
        const results = await searchAmapPlaces(keyword);
        if (results.length === 0) {
            this.searchResults.innerHTML = '<div class="no-result">未找到匹配的地点，请尝试其他关键词</div>';
            return;
        }
        this.searchResults.innerHTML = results.map(item => `
            <div class="search-result-item" data-name="${item.name}" data-lng="${item.lng}" data-lat="${item.lat}" data-district="${item.district}">
                <span class="result-name">${item.name}</span>
                <span class="result-address">${item.district}</span>
                ${item.type ? `<span class="result-type">${item.type}</span>` : ''}
            </div>
        `).join('');
        this.searchResults.querySelectorAll('.search-result-item').forEach(el => {
            el.addEventListener('click', () => this.selectPlace(el.dataset.name, parseFloat(el.dataset.lng), parseFloat(el.dataset.lat), el.dataset.district));
        });
    }
}

// ========================================
// 经过验证的景点详细信息数据库（包含准确的开放时间）
const verifiedAttractionInfo = {
    '故宫': { openTime: '08:30-17:00', closedDay: '周一闭馆', duration: '半天', bestTime: '上午', tips: ['需提前1-7天在官网预约门票', '珍宝馆和钟表馆需单独购票', '中轴线必走路线', '建议请讲解员或租用讲解器'] },
    '故宫博物院': { price: 60, openTime: '08:30-17:00', closedDay: '周一闭馆', duration: '半天', bestTime: '上午', tips: ['需提前1-7天在官网预约门票', '珍宝馆和钟表馆需单独购票', '中轴线必走路线', '建议请讲解员或租用讲解器'] },
    '长城': { openTime: '07:30-17:30', duration: '半天', bestTime: '秋季', tips: ['建议选择八达岭或慕田峪', '穿舒适运动鞋', '可坐缆车上下', '冬季注意保暖'] },
    '八达岭长城': { price: 45, openTime: '07:30-17:30', duration: '半天', bestTime: '秋季', tips: ['建议选择八达岭或慕田峪', '穿舒适运动鞋', '可坐缆车上下', '冬季注意保暖'] },
    '天坛': { openTime: '08:00-18:00', duration: '2小时', bestTime: '上午', tips: ['祈年殿是标志性建筑', '回音壁和三音石很有趣', '早晨有很多人晨练'] },
    '颐和园': { openTime: '06:30-20:00', duration: '半天', bestTime: '夏季', tips: ['建议从北宫门进，东宫门出', '十七孔桥日落很美', '佛香阁可俯瞰全园'] },
    '南锣鼓巷': { price: 0, openTime: '全天开放', duration: '2小时', bestTime: '晚上', tips: ['胡同里有很多特色小店', '可品尝北京小吃', '人多注意保管财物'] },
    '天安门广场': { price: 0, openTime: '05:00-22:00', closedDay: '重大活动时可能临时封闭', duration: '1-2小时', bestTime: '早晨', tips: ['需安检进入', '升旗时间随季节变化', '周边有故宫、人民大会堂等景点'] },
    '外滩': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', tips: ['外滩夜景非常壮观', '建议从南京东路步行至外滩', '节假日人很多'] },
    '东方明珠': { price: 199, openTime: '08:00-22:00', duration: '2-3小时', bestTime: '傍晚', tips: ['太空舱体验很棒', '透明走廊很刺激', '建议提前预约'] },
    '上海迪士尼': { price: 499, openTime: '08:30-21:00', duration: '一天', bestTime: '上午', tips: ['建议早到抢快速通行证', '烟花表演必看', '记得带充电宝'] },
    '豫园': { price: 40, openTime: '08:30-17:00', duration: '2小时', bestTime: '上午', tips: ['九曲桥拍照很美', '城隍庙可以一起逛', '小吃很多'] },
    '南京路步行街': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', tips: ['杜莎夫人蜡像馆值得去', '老字号商店很多', '可以坐观光巴士'] },
    '宽窄巷子': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '傍晚', tips: ['建议傍晚前往，夜景更美', '巷子内有很多特色小吃和工艺品店', '可品尝盖碗茶体验成都慢生活'] },
    '大熊猫繁育研究基地': { price: 55, openTime: '07:30-18:00', duration: '3-4小时', bestTime: '上午', tips: ['建议早上去看熊猫吃早餐', '园区较大，建议乘坐观光车', '夏季注意防暑降温'] },
    '武侯祠': { price: 50, openTime: '08:30-18:30', duration: '2小时', bestTime: '上午', tips: ['建议请讲解员或使用语音导览', '紧邻锦里古街，可以一起游览', '红墙夹道是热门拍照点'] },
    '锦里古街': { price: 0, openTime: '全天开放', duration: '2小时', bestTime: '晚上', tips: ['晚上夜景非常漂亮', '小吃价格偏贵，可以尝鲜', '节假日人非常多'] },
    '都江堰': { price: 90, openTime: '08:00-18:00', duration: '半天', bestTime: '春季', tips: ['建议请讲解员了解水利原理', '安澜索桥值得一去', '夏季水量大，景色壮观'] },
    '西湖': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '春天/秋天', tips: ['苏堤春晓是春季必看', '雷峰夕照适合傍晚观赏', '断桥残雪冬季最美'] },
    '灵隐寺': { price: 75, openTime: '07:30-17:30', duration: '2-3小时', bestTime: '上午', tips: ['进灵隐寺需先买飞来峰门票', '建议早上去，人较少', '素面值得一试'] },
    '宋城': { price: 300, openTime: '09:00-21:00', duration: '半天', bestTime: '下午+晚上', tips: ['千古情演出必看', '园区内有很多互动表演', '建议买含演出的联票'] },
    '千岛湖': { price: 130, openTime: '08:00-17:00', duration: '一天', bestTime: '夏季', tips: ['建议乘坐游船游览', '梅峰揽胜观景台风景最好', '岛上蚊虫较多，注意防护'] },
    '雷峰塔': { price: 40, openTime: '08:00-17:30', duration: '1-2小时', bestTime: '傍晚', tips: ['登塔可俯瞰西湖全景', '塔内有电梯', '雷峰夕照是西湖十景之一'] },
    '秦始皇兵马俑': { price: 120, openTime: '08:30-18:00', duration: '半天', bestTime: '上午', tips: ['建议请讲解员', '一号坑规模最大', '铜车马展厅必看'] },
    '大雁塔': { price: 50, openTime: '08:30-17:00', duration: '2小时', bestTime: '下午', tips: ['音乐喷泉晚上有表演', '大慈恩寺值得一去', '登塔可俯瞰西安城'] },
    '古城墙': { price: 54, openTime: '08:00-22:00', duration: '2小时', bestTime: '傍晚', tips: ['建议租自行车骑行', '傍晚夕阳很美', '南门登城视野最好'] },
    '华清宫': { price: 120, openTime: '07:30-19:00', duration: '半天', bestTime: '上午', tips: ['骊山可以一起游览', '长恨歌实景演出非常震撼', '冬季可以泡温泉'] },
    '回民街': { price: 0, openTime: '全天开放', duration: '2小时', bestTime: '晚上', tips: ['羊肉泡馍必吃', '贾三灌汤包很有名', '人很多，注意保管财物'] },
    '洱海': { price: 0, openTime: '全天开放', duration: '一天', bestTime: '春天', tips: ['建议租电动车环湖', '喜洲古镇和磻溪村值得去', '海西看日出，海东看日落'] },
    '大理古城': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '晚上', tips: ['洋人街很热闹', '五华楼可以俯瞰古城', '人民路有很多文艺小店'] },
    '苍山': { openTime: '08:30-16:30', duration: '半天', bestTime: '夏季', tips: ['洗马潭索道海拔最高', '山上温度低，带外套', '玉带路风景最美'] },
    '双廊古镇': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '下午', tips: ['玉几岛和南诏风情岛值得去', '杨丽萍太阳宫很有名', '海鲜不错'] },
    '崇圣寺三塔': { price: 75, openTime: '07:30-19:30', duration: '2小时', bestTime: '上午', tips: ['倒影公园拍照最佳', '寺院很大，建议坐电瓶车', '塔本身不能登'] },
    // 重庆
    '洪崖洞': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', tips: ['晚上开灯后景色最美', '千厮门大桥拍洪崖洞全景角度好', '解放碑可以一起逛'] },
    '解放碑': { price: 0, openTime: '全天开放', duration: '1小时', bestTime: '上午', tips: ['周边美食很多', '八一好吃街就在附近', '节假日人多'] },
    '武隆天生三桥': { price: 125, openTime: '08:00-16:30', duration: '半天', bestTime: '上午', tips: ['天生三桥气势恢宏', '天龙桥下的福隆客栈很适合拍照', '雨天山路湿滑注意安全'] },
    // 三亚
    '亚龙湾': { price: 0, openTime: '全天开放', duration: '一天', bestTime: '上午', tips: ['住宿推荐亚龙湾酒店区', '海水清澈适合浮潜', '沙滩椅可以躺一天'] },
    '蜈支洲岛': { price: 144, openTime: '08:00-17:30', duration: '一天', bestTime: '上午', tips: ['建议提前一天网上订票', '岛上潜水项目多', '珊瑚酒店住宿看日出方便'] },
    '南山寺': { price: 121, openTime: '08:00-17:30', duration: '3-4小时', bestTime: '上午', tips: ['抱佛脚消灾免难', '南海观音非常壮观', '建议走佛手印拍照'] },
    // 丽江
    '丽江古城': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '晚上', tips: ['大水车拍照打卡', '木府值得一去', '晚上酒吧一条街很热闹'] },
    '玉龙雪山': { price: 130, openTime: '07:00-18:00', duration: '一天', bestTime: '上午', tips: ['一定要带氧气瓶，山上温度低多穿衣', '大索道需要提前排队，蓝月谷风景很美', '云杉坪适合徒步'] },
    '泸沽湖': { price: 100, openTime: '全天开放', duration: '一天', bestTime: '春季', tips: ['建议租车环湖一周，里格半岛拍照最美', '女神湾日落非常美', '湖水很清适合拍照'] },
    // 桂林
    '漓江': { price: 215, openTime: '全天开放', duration: '半天', bestTime: '上午', tips: ['漓江漂流一定要选竹筏，九马画山很有看头', '兴坪古镇上岸后拍照二十元人民币背景', '提前看好天气晴天风景最美'] },
    '象鼻山': { price: 55, openTime: '06:30-21:00', duration: '2小时', bestTime: '上午', tips: ['水月洞倒影很美', '拍照角度选在訾洲公园', '建议坐船体验更好'] },
    '龙脊梯田': { price: 80, openTime: '全天开放', duration: '半天', bestTime: '上午', tips: ['平安寨九龙五虎观景台拍照最好', '金坑大寨瑶族人居住，住宿一晚看日出', '夏天绿油油冬天金黄色各有风味'] },
    // 厦门
    '鼓浪屿': { price: 90, openTime: '全天开放', duration: '一天', bestTime: '上午', tips: ['提前买船票，建议留宿一晚', '日光岩顶峰风景好', '小巷子拍照很有感觉'] },
    '厦门大学': { price: 0, openTime: '校园开放需提前预约', duration: '2-3小时', bestTime: '下午', tips: ['芙蓉隧道一定要去', '芙蓉餐厅三楼吃午饭性价比高', '上弦场看海很美'] },
    '环岛路': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '下午', tips: ['建议租自行车骑行', '从白城出发到黄厝', '音乐广场适合看海'] },
    // 张家界
    '张家界国家森林公园': { price: 228, openTime: '07:30-18:00', duration: '一天', bestTime: '上午', tips: ['金鞭溪峡谷沿线徒步', '袁家界看奇峰怪石', '天子山观景台视野开阔，建议提前买好门票减少排队'] },
    '天门山': { price: 278, openTime: '08:00-18:00', duration: '半天', bestTime: '上午', tips: ['天门洞开阔雄伟，云梦仙顶俯瞰天门山', '玻璃栈道考验胆量一定要走', '建议早上去避开人流'] },
    '黄龙洞': { price: 100, openTime: '08:00-16:00', duration: '2-3小时', bestTime: '上午', tips: ['迷宫一样的世界，喀斯特岩溶地貌完美展示', '钟乳石千姿百态非常震撼', '定海神针是标志性景点值得一看'] },
    // 长沙
    '岳麓山': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '上午', tips: ['岳麓书院一定要参观，位于山脚', '鸟语花香空气好适合徒步', '东方红广场南门进东门出路线轻松'] },
    '橘子洲': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '下午', tips: ['可以坐观光小火车环游', '周五周六有烟花', '夏天注意防晒'] },
    '湖南省博物馆': { price: 0, openTime: '09:00-17:00', closedDay: '周一闭馆', duration: '3小时', bestTime: '上午', tips: ['提前三天在公众号预约', '马王堆汉墓文物是镇馆之宝', '一定要看长沙楚国漆器'] },
    // 苏州
    '拙政园': { price: 80, openTime: '07:30-17:30', duration: '2-3小时', bestTime: '上午', tips: ['建议早上去人少拍照好看', '与苏州博物馆连在一起可以一起游览', '春兰夏天荷花秋天菊花冬天山茶四季景色不同'] },
    '虎丘': { price: 70, openTime: '07:30-18:00', duration: '2-3小时', bestTime: '上午', tips: ['云岩寺塔已有一千多年历史，剑池谜团至今未解', '万景山庄看园林很不错'] },
    '周庄': { price: 100, openTime: '全天开放', duration: '半天', bestTime: '上午', tips: ['双桥拍照最经典', '清晨8点前进去人少免票', '晚上灯笼亮起夜景很美'] },
    // 青岛
    '崂山': { price: 90, openTime: '06:00-19:00', duration: '一天', bestTime: '上午', tips: ['建议太清游览区仰口景区风景最美', '棋盘石景区风景独特人也少，爬山量力而行', '仰口景区有农家宴吃海鲜'] },
    '八大关': { price: 0, openTime: '全天开放', duration: '半天', bestTime: '下午', tips: ['花石楼看海角度好', '第二海水浴场沙滩干净，公主楼拍照很上镜', '秋季落叶很美'] },
    '青岛啤酒博物馆': { price: 60, openTime: '08:30-18:30', duration: '1.5小时', bestTime: '上午', tips: ['博物馆不大但内容丰富', '原浆啤酒好喝一定要尝，啤酒豆当小吃也不错'] },
    // 南京
    '中山陵': { price: 0, openTime: '08:30-17:00', closedDay: '周一闭馆', duration: '2-3小时', bestTime: '上午', tips: ['博爱坊牌坊很气派，从牌坊到陵寝一路上去坡度缓', '提前在公众号预约', '音乐台鸽子很多适合拍照'] },
    '夫子庙': { price: 0, openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', tips: ['夜晚秦淮河夜景很漂亮', '可以坐画舫游览秦淮河', '记得尝尝鸭血粉丝汤'] },
    '明孝陵': { price: 70, openTime: '06:30-18:00', duration: '3小时', bestTime: '上午', tips: ['神道石像路拍照绝美，翁仲路神道古朴，石象路是最美的路段'] },
    '南京博物院': { price: 0, openTime: '09:00-17:00', closedDay: '周一闭馆', duration: '3-4小时', bestTime: '上午', tips: ['提前预约门票', '历史馆数字馆民国馆艺术馆特展馆值得看', '民国馆拍照很出片'] }
};

// 模拟数据 - 目的地数据库
// ========================================
const destinationData = {
    '成都': { name: '成都', features: ['history', 'food', 'instagram'],
        attractions: [
            { name: '宽窄巷子', desc: '成都最具代表性的历史文化街区，由宽巷子、窄巷子、井巷子平行排列组成，全为青黛砖瓦的仿古四合院落', rating: 4.8, price: 0, tags: ['历史人文', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '傍晚', transport: '地铁4号线宽窄巷子站', tips: ['建议傍晚前往，夜景更美', '巷子内有很多特色小吃和工艺品店', '可品尝盖碗茶体验成都慢生活'] },
            { name: '大熊猫繁育研究基地', desc: '全球最大的大熊猫迁地保护基地，在这里可以近距离观赏国宝大熊猫的日常生活', rating: 4.9, price: 55, tags: ['自然风光', '亲子游'], openTime: '07:30-18:00', duration: '3-4小时', bestTime: '上午', transport: '地铁3号线熊猫大道站转公交', tips: ['建议早上去看熊猫吃早餐', '园区较大，建议乘坐观光车', '夏季注意防暑降温'] },
            { name: '武侯祠', desc: '纪念诸葛亮和刘备的三国文化圣地，中国唯一的君臣合祀祠庙', rating: 4.6, price: 50, tags: ['历史人文'], openTime: '08:30-18:30', duration: '2小时', bestTime: '上午', transport: '地铁3号线高升桥站', tips: ['建议请讲解员或使用语音导览', '紧邻锦里古街，可以一起游览', '红墙夹道是热门拍照点'] },
            { name: '锦里古街', desc: '仿古商业街，汇聚各种成都特色小吃，是体验成都民俗文化的好去处', rating: 4.5, price: 0, tags: ['历史人文', '美食探店'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '地铁3号线高升桥站', tips: ['晚上夜景非常漂亮', '小吃价格偏贵，可以尝鲜', '节假日人非常多'] },
            { name: '都江堰', desc: '古代水利工程奇迹，世界文化遗产，至今仍在发挥防洪灌溉作用', rating: 4.7, price: 90, tags: ['历史人文', '自然风光'], openTime: '08:00-18:00', duration: '半天', bestTime: '春季', transport: '地铁2号线犀浦站乘动车', tips: ['建议请讲解员了解水利原理', '安澜索桥值得一去', '夏季水量大，景色壮观'] }
        ],
        foods: [ { name: '龙抄手', icon: '🥟', desc: '成都名小吃，皮薄馅嫩汤鲜', price: 25, specialty: '川菜小吃' }, { name: '担担面', icon: '🍜', desc: '麻辣鲜香的经典川味面食', price: 18, specialty: '川味面食' }, { name: '串串香', icon: '🍢', desc: '成都街头必吃的特色美食', price: 60, specialty: '川味串串' }, { name: '钟水饺', icon: '🥟', desc: '麻辣红油调味，馅料鲜美', price: 20, specialty: '川菜小吃' }, { name: '火锅', icon: '🍲', desc: '成都火锅，麻辣鲜香', price: 120, specialty: '川味火锅' } ],
        itineraries: { 1: [{ time: '09:00-11:30', title: '大熊猫繁育研究基地', desc: '观赏可爱的大熊猫' }, { time: '12:00-13:30', title: '午餐-火锅', desc: '品尝正宗成都火锅' }, { time: '14:30-17:00', title: '宽窄巷子', desc: '逛古街、品小吃' }, { time: '18:00-20:00', title: '锦里古街', desc: '夜景漫步' }], 2: [{ time: '08:30-11:30', title: '武侯祠', desc: '感受三国文化' }, { time: '12:00-13:30', title: '午餐-担担面', desc: '品尝地道川味面食' }, { time: '14:30-17:30', title: '都江堰', desc: '参观古代水利工程奇迹' }, { time: '18:30-20:30', title: '宽窄巷子', desc: '夜游古街' }] }
    },
    '杭州': { name: '杭州', features: ['nature', 'history', 'instagram'],
        attractions: [ { name: '西湖', desc: '世界文化遗产，中国十大风景名胜之一，西湖十景闻名天下', rating: 4.9, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '春天/秋天', transport: '地铁1号线龙翔桥站', tips: ['苏堤春晓是春季必看', '雷峰夕照适合傍晚观赏', '断桥残雪冬季最美'] }, { name: '灵隐寺', desc: '千年古刹，杭州最著名的佛教圣地，香火旺盛', rating: 4.7, price: 75, tags: ['历史人文'], openTime: '07:30-17:30', duration: '2-3小时', bestTime: '上午', transport: '公交7路灵隐站', tips: ['进灵隐寺需先买飞来峰门票', '建议早上去，人较少', '素面值得一试'] }, { name: '宋城', desc: '重现宋代都城风貌的大型主题公园，大型实景演出《宋城千古情》非常震撼', rating: 4.5, price: 300, tags: ['历史人文', '网红打卡'], openTime: '09:00-21:00', duration: '半天', bestTime: '下午+晚上', transport: '公交308路宋城站', tips: ['千古情演出必看', '园区内有很多互动表演', '建议买含演出的联票'] }, { name: '千岛湖', desc: '湖水清澈，岛屿众多，避暑度假绝佳去处', rating: 4.6, price: 130, tags: ['自然风光'], openTime: '08:00-17:00', duration: '一天', bestTime: '夏季', transport: '杭州汽车西站乘车', tips: ['建议乘坐游船游览', '梅峰揽胜观景台风景最好', '岛上蚊虫较多，注意防护'] }, { name: '雷峰塔', desc: '西湖标志性景点，传说白娘子被法海镇压于此', rating: 4.4, price: 40, tags: ['历史人文', '网红打卡'], openTime: '08:00-17:30', duration: '1-2小时', bestTime: '傍晚', transport: '公交4路净寺站', tips: ['登塔可俯瞰西湖全景', '塔内有电梯', '雷峰夕照是西湖十景之一'] } ],
        foods: [ { name: '东坡肉', icon: '🥩', desc: '杭州名菜，肥而不腻', price: 68, specialty: '杭帮菜' }, { name: '西湖醋鱼', icon: '🐟', desc: '酸甜鲜嫩，西湖特色', price: 88, specialty: '杭帮菜' }, { name: '叫化鸡', icon: '🍗', desc: '荷叶包裹，泥烤而成', price: 98, specialty: '杭帮菜' }, { name: '片儿川', icon: '🍜', desc: '杭州特色面食', price: 25, specialty: '杭帮面食' }, { name: '龙井虾仁', icon: '🦐', desc: '用龙井茶配鲜虾', price: 108, specialty: '杭帮菜' } ],
        itineraries: { 1: [{ time: '08:00-11:00', title: '西湖苏堤漫步', desc: '晨起游湖' }, { time: '11:30-13:00', title: '午餐-楼外楼', desc: '品尝正宗杭帮菜' }, { time: '14:00-17:00', title: '灵隐寺', desc: '参拜古刹' }, { time: '18:00-20:00', title: '西湖音乐喷泉', desc: '欣赏璀璨夜景' }], 2: [{ time: '08:30-11:30', title: '雷峰塔', desc: '登塔俯瞰西湖' }, { time: '12:00-13:30', title: '午餐-知味观', desc: '品尝杭州小吃' }, { time: '14:30-17:30', title: '宋城', desc: '观看千古情演出' }, { time: '18:30-20:30', title: '河坊街', desc: '逛古街，品美食' }] }
    },
    '北京': { name: '北京', features: ['history', 'instagram'],
        attractions: [ { name: '故宫', desc: '明清两代皇宫，世界最大宫殿建筑群，金碧辉煌，气势恢宏', rating: 4.9, price: 60, tags: ['历史人文', '网红打卡'], openTime: '08:30-17:00', duration: '半天', bestTime: '上午', transport: '地铁1号线天安门东站', tips: ['建议提前网上预约门票', '珍宝馆和钟表馆值得一看', '中轴线是必走路线'] }, { name: '长城', desc: '中华民族象征，世界七大奇迹之一，蜿蜒万里', rating: 4.8, price: 45, tags: ['历史人文', '自然风光'], openTime: '07:30-17:30', duration: '半天', bestTime: '秋季', transport: '八达岭高铁或旅游专线', tips: ['建议选择八达岭或慕田峪', '穿舒适的运动鞋', '可以坐缆车上下'] }, { name: '天坛', desc: '明清皇帝祭天祈谷的圣地，建筑精美，蓝瓦红墙', rating: 4.7, price: 34, tags: ['历史人文'], openTime: '08:00-18:00', duration: '2小时', bestTime: '上午', transport: '地铁5号线天坛东门站', tips: ['祈年殿是标志性建筑', '回音壁和三音石很有趣', '早晨有很多人晨练'] }, { name: '颐和园', desc: '中国现存最大的皇家园林，昆明湖与万寿山相映成趣', rating: 4.8, price: 30, tags: ['历史人文', '自然风光'], openTime: '06:30-20:00', duration: '半天', bestTime: '夏季', transport: '地铁4号线北宫门站', tips: ['建议从北宫门进，东宫门出', '十七孔桥日落很美', '佛香阁可以俯瞰全园'] }, { name: '南锣鼓巷', desc: '老北京胡同保护区，保留了传统四合院风貌', rating: 4.5, price: 0, tags: ['历史人文', '网红打卡', '美食探店'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '地铁6号线南锣鼓巷站', tips: ['胡同里有很多特色小店', '可以品尝北京小吃', '人多注意保管财物'] } ],
        foods: [ { name: '北京烤鸭', icon: '🦆', desc: '京城第一美食', price: 200, specialty: '京味名菜' }, { name: '炸酱面', icon: '🍜', desc: '老北京传统面食', price: 35, specialty: '京味面食' }, { name: '豆汁儿', icon: '🥤', desc: '北京特色小吃', price: 15, specialty: '京味小吃' }, { name: '卤煮火烧', icon: '🥘', desc: '地道的北京家常菜', price: 40, specialty: '京味小吃' }, { name: '冰糖葫芦', icon: '🍡', desc: '酸甜酥脆传统小吃', price: 15, specialty: '京味小吃' } ],
        itineraries: { 1: [{ time: '08:00-12:00', title: '故宫博物院', desc: '参观紫禁城' }, { time: '12:30-14:00', title: '午餐-全聚德', desc: '品尝正宗北京烤鸭' }, { time: '15:00-17:30', title: '天坛', desc: '祈福观景' }, { time: '18:30-20:30', title: '王府井', desc: '逛商业街，品小吃' }], 2: [{ time: '07:30-11:30', title: '八达岭长城', desc: '登长城，做好汉' }, { time: '12:00-13:30', title: '午餐', desc: '品尝当地特色' }, { time: '15:00-18:00', title: '颐和园', desc: '漫步皇家园林' }, { time: '18:30-20:30', title: '南锣鼓巷', desc: '逛胡同，品美食' }] }
    },
    '西安': { name: '西安', features: ['history', 'food'],
        attractions: [ { name: '秦始皇兵马俑', desc: '世界第八大奇迹，规模宏大的地下军团，令人震撼', rating: 4.9, price: 120, tags: ['历史人文'], openTime: '08:30-18:00', duration: '半天', bestTime: '上午', transport: '地铁9号线华清池站转公交', tips: ['建议请讲解员', '一号坑规模最大', '铜车马展厅必看'] }, { name: '大雁塔', desc: '唐代长安城遗留的佛教建筑，玄奘法师为存放经书而建', rating: 4.6, price: 50, tags: ['历史人文'], openTime: '08:30-17:00', duration: '2小时', bestTime: '下午', transport: '地铁3号线大雁塔站', tips: ['音乐喷泉晚上有表演', '大慈恩寺值得一去', '登塔可俯瞰西安城'] }, { name: '古城墙', desc: '中国现存最完整的古代城垣，可以骑行绕城一周', rating: 4.7, price: 54, tags: ['历史人文', '网红打卡'], openTime: '08:00-22:00', duration: '2小时', bestTime: '傍晚', transport: '地铁2号线永宁门站', tips: ['建议租自行车骑行', '傍晚夕阳很美', '南门登城视野最好'] }, { name: '华清宫', desc: '唐明皇与杨贵妃的故事发生地，温泉胜地', rating: 4.5, price: 120, tags: ['历史人文', '自然风光'], openTime: '07:30-19:00', duration: '半天', bestTime: '上午', transport: '地铁9号线华清池站', tips: ['骊山可以一起游览', '长恨歌实景演出非常震撼', '冬季可以泡温泉'] }, { name: '回民街', desc: '西安特色美食街，汇集各种西北特色小吃', rating: 4.4, price: 0, tags: ['美食探店', '网红打卡'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '地铁2号线钟楼站', tips: ['羊肉泡馍必吃', '贾三灌汤包很有名', '人很多，注意保管财物'] } ],
        foods: [ { name: '肉夹馍', icon: '🥙', desc: '西安第一美食', price: 15, specialty: '陕味名吃' }, { name: '羊肉泡馍', icon: '🍲', desc: '经典西安美食', price: 35, specialty: '陕味名吃' }, { name: '凉皮', icon: '🥢', desc: '酸辣爽口', price: 12, specialty: '陕味小吃' }, { name: 'biangbiang面', icon: '🍜', desc: '宽厚面条，油泼辣子', price: 25, specialty: '陕味面食' }, { name: '肉丸胡辣汤', icon: '🥣', desc: '香辣浓稠，早餐首选', price: 15, specialty: '陕味汤品' } ],
        itineraries: { 1: [{ time: '08:00-11:30', title: '秦始皇兵马俑', desc: '参观世界第八大奇迹' }, { time: '12:00-13:30', title: '午餐-回民街', desc: '品尝西安特色美食' }, { time: '14:30-17:30', title: '华清宫', desc: '了解唐玄宗杨贵妃故事' }, { time: '18:30-20:30', title: '大雁塔北广场', desc: '观看音乐喷泉表演' }], 2: [{ time: '08:30-11:30', title: '古城墙', desc: '骑行城墙' }, { time: '12:00-13:30', title: '午餐-老孙家泡馍', desc: '正宗羊肉泡馍' }, { time: '14:30-17:00', title: '大雁塔', desc: '登塔祈福' }, { time: '18:00-20:00', title: '回民街', desc: '夜市美食探险' }] }
    },
    '上海': { name: '上海', features: ['history', 'food', 'instagram'],
        attractions: [ { name: '外滩', desc: '上海标志性景点，百年万国建筑博览群，夜景璀璨', rating: 4.9, price: 0, tags: ['历史人文', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '地铁2号线南京东路站', tips: ['外滩夜景非常壮观', '建议从南京东路步行至外滩', '节假日人很多'] }, { name: '东方明珠', desc: '上海地标性建筑，亚洲第一高塔，可俯瞰全城', rating: 4.7, price: 199, tags: ['网红打卡'], openTime: '08:00-22:00', duration: '2-3小时', bestTime: '傍晚', transport: '地铁2号线陆家嘴站', tips: ['太空舱体验很棒', '透明走廊很刺激', '建议提前预约'] }, { name: '上海迪士尼', desc: '中国大陆第一座迪士尼乐园，梦幻童话世界', rating: 4.8, price: 499, tags: ['网红打卡', '亲子游'], openTime: '08:30-21:00', duration: '一天', bestTime: '上午', transport: '地铁11号线迪士尼站', tips: ['建议早到抢快速通行证', '烟花表演必看', '记得带充电宝'] }, { name: '豫园', desc: '江南古典园林，上海老城厢的标志性景点', rating: 4.6, price: 40, tags: ['历史人文', '自然风光'], openTime: '08:30-17:00', duration: '2小时', bestTime: '上午', transport: '地铁10号线豫园站', tips: ['九曲桥拍照很美', '城隍庙可以一起逛', '小吃很多'] }, { name: '南京路步行街', desc: '中华商业第一街，繁华的购物街区', rating: 4.5, price: 0, tags: ['网红打卡', '美食探店'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '地铁1/2号线人民广场站', tips: ['杜莎夫人蜡像馆值得去', '老字号商店很多', '可以坐观光巴士'] } ],
        foods: [ { name: '生煎包', icon: '🥟', desc: '上海特色小吃，皮薄馅大', price: 20, specialty: '沪味小吃' }, { name: '蟹粉小笼', icon: '🥠', desc: '鲜美汤汁，蟹香浓郁', price: 35, specialty: '沪味小吃' }, { name: '本帮菜', icon: '🍽️', desc: '浓油赤酱，经典味道', price: 120, specialty: '沪帮菜' }, { name: '葱油拌面', icon: '🍜', desc: '简单美味的上海面食', price: 18, specialty: '沪味面食' }, { name: '鲜肉月饼', icon: '🥮', desc: '酥皮肉馅，上海特色', price: 15, specialty: '沪味点心' } ],
        itineraries: { 1: [{ time: '08:30-11:30', title: '豫园', desc: '游览江南古典园林' }, { time: '12:00-13:30', title: '午餐-本帮菜', desc: '品尝上海特色美食' }, { time: '14:30-17:00', title: '南京路步行街', desc: '购物逛街' }, { time: '18:00-20:30', title: '外滩', desc: '欣赏夜景' }], 2: [{ time: '08:00-21:00', title: '上海迪士尼', desc: '全天畅游童话世界' }, { time: '21:30-22:00', title: '烟花表演', desc: '梦幻烟花秀' }] }
    },
    '重庆': { name: '重庆', features: ['nature', 'food', 'instagram'],
        attractions: [
            { name: '洪崖洞', desc: '巴渝传统建筑特色的吊脚楼建筑群，依山就势，沿江而建，夜景璀璨', rating: 4.8, price: 0, tags: ['自然风光', '美食探店', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '地铁1号线小什字站', tips: ['晚上开灯后景色最美', '千厮门大桥拍洪崖洞全景角度好', '解放碑可以一起逛'] },
            { name: '解放碑', desc: '重庆地标，抗战胜利纪念地标，周边是繁华商业区', rating: 4.4, price: 0, tags: ['历史人文', '网红打卡'], openTime: '全天开放', duration: '1小时', bestTime: '上午', transport: '地铁1号线/2号线较场口站', tips: ['周边美食很多', '八一好吃街就在附近', '节假日人多'] },
            { name: '磁器口', desc: '千年古镇，重庆市重点保护传统街，古色古香，感受老重庆韵味', rating: 4.3, price: 0, tags: ['历史人文', '美食探店'], openTime: '全天开放', duration: '2小时', bestTime: '上午', transport: '轨道交通1号线磁器口站', tips: ['陈麻花是特产', '古镇里有很多手工作坊', '节假日人挤人'] },
            { name: '武隆天生三桥', desc: '世界规模最大最高的串珠式天生桥群，满城尽带黄金甲取景地', rating: 4.9, price: 125, tags: ['自然风光'], openTime: '08:00-16:30', duration: '半天', bestTime: '上午', transport: '重庆四公里枢纽站乘车', tips: ['天生三桥气势恢宏', '天龙桥下的福隆客栈很适合拍照', '雨天山路湿滑注意安全'] },
            { name: '长江索道', desc: '重庆第二条跨江索道，已经运行三十余年，重庆天际线尽收眼底', rating: 4.5, price: 20, tags: ['自然风光', '网红打卡'], openTime: '07:30-22:30', duration: '0.5小时', bestTime: '傍晚', transport: '地铁1号线小什字站', tips: ['夜景视角好', '建议往返乘坐', '排队时间较长建议错峰'] }
        ],
        foods: [
            { name: '重庆火锅', icon: '🍲', desc: '麻辣鲜香，越煮越入味', price: 120, specialty: '川菜火锅' },
            { name: '重庆小面', icon: '🍜', desc: '麻辣够劲，重庆人的早餐最爱', price: 12, specialty: '川渝面食' },
            { name: '酸辣粉', icon: '🍝', desc: '酸麻辣开胃，越吃越想吃', price: 10, specialty: '川渝小吃' },
            { name: '毛血旺', icon: '🥘', desc: '血旺嫩而入味，麻辣过瘾', price: 45, specialty: '川菜名菜' },
            { name: '江湖菜', icon: '🍲', desc: '重口味，量大份足', price: 80, specialty: '重庆本土菜' }
        ],
        itineraries: {
            1: [{ time: '08:30-11:30', title: '解放碑', desc: '打卡地标' }, { time: '12:00-13:30', title: '午餐-解放碑火锅', desc: '正宗重庆火锅' }, { time: '14:00-17:00', title: '洪崖洞', desc: '游览滨江古镇' }, { time: '18:30-20:00', title: '千厮门大桥拍夜景', desc: '最美视角' }],
            2: [{ time: '08:00-12:00', title: '磁器口古镇', desc: '逛古镇品小吃' }, { time: '12:30-14:00', title: '午餐', desc: '品尝江湖菜' }, { time: '15:00-18:00', title: '长江索道', desc: '俯瞰山城风光' }, { time: '18:30-20:30', title: '洪崖洞看夜景', desc: '璀璨夜景' }]
        }
    },
    '三亚': { name: '三亚', features: ['nature', 'instagram'],
        attractions: [
            { name: '亚龙湾', desc: '三亚最美海湾，沙滩细腻，海水清澈，被誉为天下第一湾', rating: 4.8, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '一天', bestTime: '上午', transport: '公交27路亚龙湾站', tips: ['住宿推荐亚龙湾酒店区', '海水清澈适合浮潜', '沙滩椅可以躺一天'] },
            { name: '天涯海角', desc: '三亚标志性景点，沙滩上有天涯海角两块巨石', rating: 4.3, price: 81, tags: ['历史人文', '网红打卡'], openTime: '07:30-18:00', duration: '2-3小时', bestTime: '下午', transport: '公交16路天涯海角站', tips: ['看日落很美', '拍照打卡为主，不用太久', '周边有大小洞天可以一起玩'] },
            { name: '蜈支洲岛', desc: '中国最美海岛之一，海水清澈见底，能见度极高，潜水绝佳去处', rating: 4.8, price: 144, tags: ['自然风光', '网红打卡'], openTime: '08:00-17:30', duration: '一天', bestTime: '上午', transport: '海棠湾蜈支洲码头乘船', tips: ['建议提前一天网上订票', '岛上潜水项目多', '珊瑚酒店住宿看日出方便'] },
            { name: '南山寺', desc: '大型佛教文化园区，面朝南海，风景秀丽，108米海上观音气势恢宏', rating: 4.6, price: 121, tags: ['历史人文', '自然风光'], openTime: '08:00-17:30', duration: '3-4小时', bestTime: '上午', transport: '公交16路南山寺站', tips: ['抱佛脚消灾免难', '南海观音非常壮观', '建议走佛手印拍照'] },
            { name: '热带天堂森林公园', desc: '非诚勿扰2取景地，依山面海，俯瞰亚龙湾，热带雨林风光迷人', rating: 4.5, price: 170, tags: ['自然风光', '网红打卡'], openTime: '07:30-17:30', duration: '3小时', bestTime: '上午', transport: '公交15路热带天堂站', tips: ['过江龙索桥必打卡', '山顶观景台俯瞰亚龙湾全景很美', '鸟巢度假村住宿体验很棒'] }
        ],
        foods: [
            { name: '海鲜大排档', icon: '🦞', desc: '三亚海鲜新鲜实惠', price: 150, specialty: '海南海鲜' },
            { name: '椰子鸡', icon: '🥥', desc: '椰肉清甜，鸡肉鲜嫩，汤汁浓郁', price: 120, specialty: '海南名菜' },
            { name: '清补凉', icon: '🍧', desc: '消暑甜品，椰奶打底配料丰富', price: 20, specialty: '海南甜品' },
            { name: '抱罗粉', icon: '🍜', desc: '海南特色米粉，汤头清甜', price: 15, specialty: '海南米粉' },
            { name: '文昌鸡', icon: '🍗', desc: '海南四大名菜之首，皮嫩肉滑', price: 68, specialty: '海南名菜' }
        ],
        itineraries: {
            1: [{ time: '08:00-12:00', title: '亚龙湾', desc: '沙滩漫步游泳' }, { time: '12:30-14:00', title: '午餐-海鲜', desc: '海边餐厅吃海鲜' }, { time: '14:30-17:30', title: '蜈支洲岛', desc: '海岛畅游' }, { time: '18:00-19:30', title: '回酒店', desc: '酒店沙滩放松' }],
            2: [{ time: '08:30-11:30', title: '南山寺', desc: '礼佛观景' }, { time: '12:00-13:30', title: '午餐-椰子鸡', desc: '品尝海南特色' }, { time: '14:30-17:00', title: '热带天堂', desc: '热带雨林徒步' }, { time: '18:00-19:30', title: '三亚湾日落', desc: '欣赏绝美日落' }]
        }
    },
    '丽江': { name: '丽江', features: ['nature', 'history', 'instagram'],
        attractions: [
            { name: '丽江古城', desc: '世界文化遗产，纳西族风情古城，四方街热闹非凡，小桥流水人家', rating: 4.7, price: 50, tags: ['历史人文', '网红打卡', '美食探店'], openTime: '全天开放', duration: '半天', bestTime: '晚上', transport: '古城步行', tips: ['大水车拍照打卡', '木府值得一去', '晚上酒吧一条街很热闹'] },
            { name: '玉龙雪山', desc: '纳西族神山，雪山高耸入云，冰川地貌非常壮观', rating: 4.9, price: 100, tags: ['自然风光', '网红打卡'], openTime: '07:00-18:00', duration: '一天', bestTime: '上午', transport: '丽江古城拼车', tips: ['一定要带氧气瓶，山上温度低多穿衣', '大索道需要提前排队，蓝月谷风景很美', '云杉坪适合徒步'] },
            { name: '泸沽湖', desc: '高原明珠，湛蓝湖水透明度极高，摩梭人母系文化保留完整', rating: 4.8, price: 70, tags: ['自然风光', '历史人文'], openTime: '全天开放', duration: '一天', bestTime: '春季', transport: '丽江客运站乘车', tips: ['建议租车环湖一周，里格半岛拍照最美', '女神湾日落非常美', '湖水很清适合拍照'] },
            { name: '束河古镇', desc: '比大研古城安静，茶马古道驿站，古朴宁静，适合发呆', rating: 4.5, price: 40, tags: ['历史人文', '自然风光'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '丽江打车', tips: ['四方听音广场每晚有篝火晚会', '青龙桥拍照很美', '比丽江古城人少清净'] },
            { name: '拉市海', desc: '丽江最大的高原湖泊，水草丰美，候鸟栖息地，可以骑马划船', rating: 4.3, price: 160, tags: ['自然风光'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '丽江忠义市场拼车', tips: ['选择正规马场避免被宰', '骑马拍照不错', '可以品尝湿地烤鱼'] }
        ],
        foods: [
            { name: '腊排骨火锅', icon: '🍲', desc: '腊排骨腌制入味，锅底鲜香', price: 80, specialty: '丽江火锅' },
            { name: '鸡豆凉粉', icon: '🥗', desc: '丽江特色凉粉，凉拌口味酸辣开胃', price: 15, specialty: '丽江小吃' },
            { name: '纳西烤鱼', icon: '🐟', desc: '外酥里嫩，香料入味', price: 45, specialty: '纳西风味' },
            { name: '酥油茶', icon: '🥛', desc: '藏族特色饮品，咸香浓郁', price: 10, specialty: '高原特色' },
            { name: '丽江粑粑', icon: '🫓', desc: '金黄酥脆，香甜可口', price: 15, specialty: '丽江特色面点' }
        ],
        itineraries: {
            1: [{ time: '08:00-12:00', title: '丽江古城', desc: '逛古城体验纳西风情' }, { time: '12:30-14:00', title: '午餐-腊排骨火锅', desc: '品尝当地特色' }, { time: '14:30-17:30', title: '木府', desc: '了解纳西文化' }, { time: '18:00-20:00', title: '四方街', desc: '古城夜景' }],
            2: [{ time: '07:30-12:00', title: '玉龙雪山', desc: '登顶雪山看冰川' }, { time: '12:30-14:00', title: '蓝月谷', desc: '蓝月谷看蓝绿色湖水' }, { time: '14:30-17:00', title: '云杉坪徒步', desc: '森林徒步' }, { time: '18:00-19:30', title: '返程古城', desc: '回古城品小吃' }]
        }
    },
    '桂林': { name: '桂林', features: ['nature', 'instagram'],
        attractions: [
            { name: '漓江', desc: '桂林山水甲天下，漓江风光冠绝天下，杨堤到兴坪段风景最美', rating: 4.9, price: 215, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '桂林磨盘山码头乘船', tips: ['漓江漂流一定要选竹筏，九马画山很有看头', '兴坪古镇上岸后拍照二十元人民币背景', '提前看好天气晴天风景最美'] },
            { name: '象鼻山', desc: '桂林城徽，山形酷似一头驻足漓江边临流饮水的大象', rating: 4.4, price: 55, tags: ['自然风光', '网红打卡'], openTime: '06:30-21:00', duration: '2小时', bestTime: '上午', transport: '公交2路文昌桥站', tips: ['水月洞倒影很美', '拍照角度选在訾洲公园', '建议坐船体验更好'] },
            { name: '阳朔西街', desc: '阳朔最古老最繁华的街道，已有1400多年历史，西街夜景很美', rating: 4.4, price: 0, tags: ['美食探店', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '桂林汽车总站乘车', tips: ['啤酒鱼一定要吃', '街上店铺林立各种纪念品', '西街尽头就是漓江'] },
            { name: '龙脊梯田', desc: '规模宏大的梯田群，如链似带从山脚盘绕到山顶，线条行云流水潇洒柔畅', rating: 4.7, price: 80, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '桂林琴潭客运站乘车', tips: ['平安寨九龙五虎观景台拍照最好', '金坑大寨瑶族人居住，住宿一晚看日出', '夏天绿油油冬天金黄色各有风味'] },
            { name: '银子岩', desc: '典型的喀斯特溶洞，洞内钟乳石晶莹剔透色彩斑斓，世界溶洞奇观', rating: 4.6, price: 80, tags: ['自然风光'], openTime: '08:00-17:30', duration: '1.5小时', bestTime: '下午', transport: '阳朔专线车银子岩站', tips: ['三绝雪山飞瀑音乐石屏瑶池仙境', '不去银子岩不算游过桂林', '洞里很凉快进快出'] }
        ],
        foods: [
            { name: '桂林米粉', icon: '🍜', desc: '桂林招牌美食，卤水熬制数小时香气扑鼻', price: 8, specialty: '桂北米粉' },
            { name: '啤酒鱼', icon: '🐟', desc: '阳朔名菜，鱼肉外焦里嫩，鲜辣可口', price: 68, specialty: '阳朔名菜' },
            { name: '荔浦芋扣肉', icon: '🥩', desc: '五花肉肥而不腻，荔浦芋头粉糯香甜', price: 88, specialty: '桂林名菜' },
            { name: '马蹄糕', icon: '🍰', desc: '清甜爽口，休闲小吃', price: 15, specialty: '桂林小吃' },
            { name: '田螺酿', icon: '🥘', desc: '田螺掏空塞肉，非常入味', price: 58, specialty: '桂林特色菜' }
        ],
        itineraries: {
            1: [{ time: '08:00-12:00', title: '漓江竹筏漂流', desc: '体验漓江精华' }, { time: '12:30-14:00', title: '午餐-啤酒鱼', desc: '阳朔西街吃饭' }, { time: '14:30-17:00', title: '银子岩', desc: '溶洞探险' }, { time: '18:00-19:00', title: '西街', desc: '逛西街夜景色' }],
            2: [{ time: '08:00-11:00', title: '象鼻山', desc: '打卡桂林城徽' }, { time: '11:30-13:30', title: '午餐', desc: '品尝桂林米粉' }, { time: '14:00-17:00', title: '龙脊梯田', desc: '梯田观景' }, { time: '18:00-19:30', title: '兴坪古镇', desc: '古镇漫步' }]
        }
    },
    '厦门': { name: '厦门', features: ['nature', 'food', 'instagram'],
        attractions: [
            { name: '鼓浪屿', desc: '厦门标志性景点，文艺小岛，万国建筑博览，日光岩俯瞰全岛', rating: 4.7, price: 50, tags: ['自然风光', '历史人文', '网红打卡'], openTime: '全天开放', duration: '一天', bestTime: '上午', transport: '轮渡码头乘船', tips: ['提前买船票，建议留宿一晚', '日光岩顶峰风景好', '小巷子拍照很有感觉'] },
            { name: '厦门大学', desc: '中国最美大学之一，芙蓉隧道涂鸦有名，白城沙滩出门就是海', rating: 4.5, price: 0, tags: ['自然风光', '网红打卡'], openTime: '校园开放需提前预约', duration: '2-3小时', bestTime: '下午', transport: '公交直达', tips: ['芙蓉隧道一定要去', '芙蓉餐厅三楼吃午饭性价比高', '上弦场看海很美'] },
            { name: '南普陀寺', desc: '闽南千年名寺，寺宇巍峨范围广阔，毗邻厦门大学，背靠五老峰', rating: 4.4, price: 0, tags: ['历史人文'], openTime: '08:00-18:00', duration: '1.5小时', bestTime: '上午', transport: '公交到达', tips: ['可以免费进香，素饼值得购买带走', '天王殿很美', '建议走大悲殿到藏经阁'] },
            { name: '曾厝垵', desc: '原本是临海小渔村，现在变成文艺小清新文创村，各种小吃小店聚集', rating: 4.2, price: 0, tags: ['美食探店', '网红打卡'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '公交直达', tips: ['很多网红民宿，晚上很热闹', '小吃很多价格比市区便宜', '周末人多需要错峰'] },
            { name: '环岛路', desc: '世界最美马拉松赛道，沿海而建，风光优美骑行舒服', rating: 4.6, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '公交到达', tips: ['建议租自行车骑行', '从白城出发到黄厝', '音乐广场适合看海'] }
        ],
        foods: [
            { name: '沙茶面', icon: '🍜', desc: '闽南特色面食，沙茶酱浓香汤色浓郁', price: 25, specialty: '闽菜小吃' },
            { name: '海蛎煎', icon: '🦪', desc: '鸡蛋煎海蛎鲜香可口', price: 20, specialty: '闽南小吃' },
            { name: '姜母鸭', icon: '🦆', desc: '闽南传统名菜，香气四溢鸭肉鲜嫩', price: 88, specialty: '闽菜名菜' },
            { name: '土笋冻', icon: '🐛', desc: 'Q弹细腻，晶莹剔透，配上酱料非常好吃', price: 15, specialty: '闽南特色小吃' },
            { name: '花生汤', icon: '🥣', desc: '甜而不腻，入口即化，配油条绝配', price: 8, specialty: '闽南甜点' }
        ],
        itineraries: {
            1: [{ time: '08:00-10:00', title: '南普陀寺', desc: '拜佛游览' }, { time: '10:30-12:30', title: '厦门大学', desc: '校园漫步' }, { time: '13:00-14:30', title: '午餐-沙茶面', desc: '品尝闽南小吃' }, { time: '15:00-18:00', title: '环岛路骑行', desc: '海边骑行欣赏风景' }],
            2: [{ time: '08:00-12:00', title: '鼓浪屿', desc: '环岛小岛漫游' }, { time: '12:30-14:00', title: '龙头路', desc: '美食探店' }, { time: '14:30-17:00', title: '日光岩登顶', desc: '俯瞰全岛' }, { time: '18:00-19:30', title: '海滨散步', desc: '看夕阳西下' }]
        }
    },
    '张家界': { name: '张家界', features: ['nature', 'instagram'],
        attractions: [
            { name: '张家界国家森林公园', desc: '中国第一个国家森林公园，三千奇峰拔地而起，八百溪流蜿蜒曲折，峰峦奇特幽谷静美', rating: 4.9, price: 225, tags: ['自然风光', '网红打卡'], openTime: '07:30-18:00', duration: '一天', bestTime: '上午', transport: '张家界市区汽车站乘车', tips: ['金鞭溪峡谷沿线徒步', '袁家界看奇峰怪石', '天子山观景台视野开阔，建议提前买好门票减少排队'] },
            { name: '天门山', desc: '因天门洞开奇观得名，盘山公路99弯闻名世界，玻璃栈道惊险刺激', rating: 4.8, price: 235, tags: ['自然风光', '网红打卡'], openTime: '08:00-18:00', duration: '半天', bestTime: '上午', transport: '市区乘公交直达', tips: ['天门洞开阔雄伟，云梦仙顶俯瞰天门山', '玻璃栈道考验胆量一定要走', '建议早上去避开人流'] },
            { name: '黄龙洞', desc: '张家界地下魔宫，溶洞奇观，洞中瀑布定海神针非常壮观', rating: 4.6, price: 100, tags: ['自然风光'], openTime: '08:00-16:00', duration: '2-3小时', bestTime: '上午', transport: '武陵源汽车站乘车', tips: ['迷宫一样的世界，喀斯特岩溶地貌完美展示', '钟乳石千姿百态非常震撼', '定海神针是标志性景点值得一看'] },
            { name: '袁家界', desc: '阿凡达取景地，乾坤一柱就是在这里，石英砂岩峰林奇观', rating: 4.7, price: 0, tags: ['自然风光'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '金鞭溪徒步上游袁家界', tips: ['阿凡达取景地打卡拍照', '百龙天梯下山更快', '景色开阔奇峰怪石尽收眼底'] },
            { name: '金鞭溪', desc: '张家界最美峡谷，溪水清澈，奇峰相伴，空气清新负离子含量高', rating: 4.5, price: 0, tags: ['自然风光'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '森林公园大门进入', tips: ['沿路风景不断，全程比较费体力', '西游记取景地就在这里'] }
        ],
        foods: [
            { name: '张家界三下锅', icon: '🍲', desc: '张家界特色，干锅多味组合腊猪蹄肥肠干锅口味浓郁', price: 128, specialty: '张家界土家菜' },
            { name: '血豆腐', icon: '🥓', desc: '土家族传统美食，烟熏后风味独特', price: 35, specialty: '土家特色' },
            { name: '土家腊肉', icon: '🥓', desc: '柴火烟熏色泽金黄肥肉不腻', price: 50, specialty: '土家腊肉' },
            { name: '岩耳', icon: '🍄', desc: '张家界岩耳石耳，生长在砂岩上，炖汤味道鲜美', price: 68, specialty: '土家山珍' },
            { name: '葛根粉', icon: '🥣', desc: '湘西特产，清热降火', price: 25, specialty: '湘西特产' }
        ],
        itineraries: {
            1: [{ time: '08:00-12:00', title: '张家界国家森林公园', desc: '金鞭溪徒步袁家界观景' }, { time: '12:30-14:00', title: '午餐-三下锅', desc: '品尝土家特色' }, { time: '14:30-17:30', title: '天子山', desc: '山顶观景' }, { time: '18:00-19:00', title: '武陵源住宿', desc: '山下镇上吃饭' }],
            2: [{ time: '08:00-12:00', title: '天门山', desc: '天门洞和玻璃栈道体验' }, { time: '12:30-14:00', title: '午餐', desc: '市区吃土家菜' }, { time: '14:30-17:00', title: '黄龙洞', desc: '溶洞探秘' }, { time: '18:00-19:00', title: '回市区', desc: '返程' }]
        }
    },
    '长沙': { name: '长沙', features: ['food', 'history', 'instagram'],
        attractions: [
            { name: '岳麓山', desc: '南岳衡山72峰之一，湘江西岸，城市山岳风景名胜区，爱晚亭闻名遐迩', rating: 4.5, price: 0, tags: ['自然风光', '历史人文'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '公交东门南门站', tips: ['岳麓书院一定要参观，位于山脚', '鸟语花香空气好适合徒步', '东方红广场南门进东门出路线轻松'] },
            { name: '橘子洲', desc: '湘江下游冲积沙洲，毛主席青年艺术雕塑非常壮观', rating: 4.4, price: 0, tags: ['历史人文', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '下午', transport: '地铁2号线橘子洲站', tips: ['可以坐观光小火车环游', '周五周六有烟花', '夏天注意防晒'] },
            { name: '湖南省博物馆', desc: '馆藏马王堆汉墓文物非常丰富，辛追夫人遗体千年不腐', rating: 4.7, price: 0, tags: ['历史人文'], openTime: '09:00-17:00 周一闭馆', duration: '3小时', bestTime: '上午', transport: '地铁1号线培元桥站', tips: ['提前三天在公众号预约', '马王堆汉墓文物是镇馆之宝', '一定要看长沙楚国漆器'] },
            { name: '太平街', desc: '长沙古城保留原有街巷格局，老字号云集太平街热闹非凡', rating: 4.3, price: 0, tags: ['历史人文', '美食探店', '网红打卡'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '地铁1号线黄兴广场站', tips: ['贾谊故居就在这条街上', '黑色经典臭豆腐一定要吃', '太平老街适合散步拍照'] },
            { name: '梅溪湖', desc: '城市新区，梅溪湖国际文化艺术中心造型独特，周末散步休闲好去处', rating: 4.2, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '2小时', bestTime: '傍晚', transport: '地铁2号线梅溪湖西站', tips: ['音乐喷泉周五周六有，节假日人较多', '周边商圈配套齐全'] }
        ],
        foods: [
            { name: '臭豆腐', icon: '🥘', desc: '长沙标志性小吃，闻着臭吃着香，外焦里嫩', price: 10, specialty: '长沙小吃' },
            { name: '口味虾', icon: '🦐', desc: '麻辣鲜香，长沙夏夜必吃', price: 88, specialty: '湘味名菜' },
            { name: '剁椒鱼头', icon: '🐟', desc: '鱼头鲜嫩辣得过瘾，经典湘菜', price: 68, specialty: '湘菜名菜' },
            { name: '糖油粑粑', icon: '🍡', desc: '甜而不腻，金黄软糯，长沙街头传统小吃', price: 8, specialty: '长沙小吃' },
            { name: '茶颜悦色', icon: '🧋', desc: '长沙网红奶茶，幽兰拿铁声声乌龙不错', price: 18, specialty: '长沙网红饮品' }
        ],
        itineraries: {
            1: [{ time: '08:30-11:30', title: '岳麓山', desc: '登山徒步看爱晚亭' }, { time: '12:00-13:30', title: '美食街', desc: '品尝长沙小吃' }, { time: '14:00-17:00', title: '湖南省博物馆', desc: '参观马王堆文物' }, { time: '18:00-20:00', title: '太平街', desc: '逛街吃小吃' }],
            2: [{ time: '09:00-11:30', title: '橘子洲', desc: '看毛主席雕像' }, { time: '12:00-13:30', title: '午餐', desc: '品尝湘味' }, { time: '14:30-16:30', title: '湖南省博物馆', desc: '了解湖湘文化' }, { time: '17:00-19:00', title: '梅溪湖', desc: '城市休闲散步' }]
        }
    },
    '苏州': { name: '苏州', features: ['nature', 'history'],
        attractions: [
            { name: '拙政园', desc: '苏州园林之冠，中国四大名园，庭院错落山水萦绕别有洞天', rating: 4.8, price: 80, tags: ['历史人文', '自然风光'], openTime: '07:30-17:30', duration: '2-3小时', bestTime: '上午', transport: '公交拙政园站', tips: ['建议早上去人少拍照好看', '与苏州博物馆连在一起可以一起游览', '春兰夏天荷花秋天菊花冬天山茶四季景色不同'] },
            { name: '虎丘', desc: '吴中第一名胜，苏东坡说过到苏州不游虎丘乃是憾事', rating: 4.6, price: 70, tags: ['历史人文', '自然风光'], openTime: '07:30-18:00', duration: '2-3小时', bestTime: '上午', transport: '公交虎丘首末站', tips: ['云岩寺塔已有一千多年历史，剑池谜团至今未解', '万景山庄看园林很不错'] },
            { name: '周庄', desc: '中国第一水乡，江南六大古镇之一，水乡泽国典型的江南水乡风貌', rating: 4.5, price: 100, tags: ['历史人文', '自然风光'], openTime: '全天开放', duration: '半天', bestTime: '上午', transport: '苏州汽车站乘车', tips: ['双桥拍照最经典', '清晨8点前进去人少免票', '晚上灯笼亮起夜景很美'] },
            { name: '平江路', desc: '平江历史街区，宋代苏州城缩影，石板路两侧是老宅故居，慢品江南生活', rating: 4.3, price: 0, tags: ['历史人文', '美食探店'], openTime: '全天开放', duration: '2小时', bestTime: '晚上', transport: '公交平江路站', tips: ['听苏州评弹，吃苏式糕点，猫空书店写明信片', '沈厅值得一看，酒吧咖啡馆很多适合发呆'] },
            { name: '寒山寺', desc: '始建于南朝萧梁代，姑苏城外寒山寺夜半钟声到客船的名句让它闻名天下', rating: 4.2, price: 20, tags: ['历史人文'], openTime: '07:30-17:30', duration: '1-2小时', bestTime: '上午', transport: '公交寒山寺站', tips: ['可以听钟声拍照', '枫桥夜泊怀古，江村桥拍照很美'] }
        ],
        foods: [
            { name: '松鼠桂鱼', icon: '🐟', desc: '苏帮菜代表作，外脆里嫩，甜酸可口', price: 128, specialty: '苏帮菜' },
            { name: '阳澄湖大闸蟹', icon: '🦀', desc: '蟹肉丰满，膏腴肥美，鲜甜可口', price: 88, specialty: '苏州名菜' },
            { name: '太湖三白', icon: '🐟', desc: '太湖银鱼白鱼白虾原汁原味非常鲜美', price: 88, specialty: '太湖名菜' },
            { name: '苏式汤面', icon: '🍜', desc: '一碗好面汤底浓郁浇头多样，地道苏式风味', price: 28, specialty: '苏式面食' },
            { name: '桂花糖藕', icon: '🫓', desc: '糯米灌在莲藕中桂花香甜软糯香甜', price: 35, specialty: '苏式甜点' }
        ],
        itineraries: {
            1: [{ time: '08:00-11:00', title: '拙政园', desc: '园林漫步' }, { time: '11:30-13:00', title: '平江路', desc: '吃苏州小吃' }, { time: '13:30-16:00', title: '虎丘', desc: '登山览胜' }, { time: '16:30-18:00', title: '寒山寺', desc: '怀古寻幽' }],
            2: [{ time: '08:30-11:30', title: '周庄古镇', desc: '水乡泛舟' }, { time: '12:00-13:30', title: '古镇吃饭', desc: '万成酒家吃万三蹄' }, { time: '14:30-16:30', title: '双桥拍照', desc: '古镇闲逛' }, { time: '17:00-18:30', title: '沈厅', desc: '参观张厅' }]
        }
    },
    '青岛': { name: '青岛', features: ['nature', 'food'],
        attractions: [
            { name: '栈桥', desc: '青岛百年标志，回澜阁孤立海中，海浪堆雪景观独特', rating: 4.4, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '1-2小时', bestTime: '早上', transport: '地铁3号线青岛站步行', tips: ['旺季人很多，拍照建议退潮后去', '冬季海鸥很多可以喂', '火车站过来很近步行就能到'] },
            { name: '八大关', desc: '汇集众多欧式建筑，绿树成荫环境清幽，海滨步行道风景优美', rating: 4.6, price: 0, tags: ['自然风光', '历史人文'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '公交26路武胜关站', tips: ['花石楼看海角度好', '第二海水浴场沙滩干净，公主楼拍照很上镜', '秋季落叶很美'] },
            { name: '崂山', desc: '海上第一名山，山海相连山光海色，道教名山，海岸线蜿蜒曲折', rating: 4.7, price: 130, tags: ['自然风光', '历史人文'], openTime: '06:00-19:00', duration: '一天', bestTime: '上午', transport: '公交104路崂山站', tips: ['建议太清游览区仰口景区风景最美', '棋盘石景区风景独特人也少，爬山量力而行', '仰口景区有农家宴吃海鲜'] },
            { name: '青岛啤酒博物馆', desc: '了解青岛啤酒百年历史，品尝原浆啤酒非常新鲜好喝', rating: 4.5, price: 60, tags: ['美食探店', '网红打卡'], openTime: '08:30-18:30', duration: '1.5小时', bestTime: '上午', transport: '地铁1号线台东站', tips: ['博物馆不大但内容丰富', '原浆啤酒好喝一定要尝，啤酒豆当小吃也不错'] },
            { name: '金沙滩', desc: '水清滩平沙细如粉，号称亚洲第一滩，海水湛蓝清澈', rating: 4.5, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '公交开发区金沙滩站', tips: ['适合亲子游，周边有游乐设施', '啤酒城每年八月举办金沙滩音乐节', '夏天玩水非常舒服'] }
        ],
        foods: [
            { name: '海鲜烧烤', icon: '🍢', desc: '青岛海鲜新鲜，烤着吃香气扑鼻', price: 100, specialty: '青岛海鲜' },
            { name: '辣炒蛤蜊', icon: '🦪', desc: '辣炒鲜香，配啤酒绝了', price: 35, specialty: '青岛海鲜小吃' },
            { name: '鲅鱼水饺', icon: '🥟', desc: '鲅鱼新鲜馅料饱满，皮薄馅大非常好吃', price: 45, specialty: '青岛水饺' },
            { name: '青岛啤酒', icon: '🍺', desc: '世界闻名，泡沫丰富清爽可口', price: 8, specialty: '青岛特产' },
            { name: '海凉粉', icon: '🥗', desc: '用海带熬制做成，晶莹剔透，夏天解暑开胃', price: 15, specialty: '青岛小吃' }
        ],
        itineraries: {
            1: [{ time: '08:00-11:00', title: '栈桥', desc: '打卡青岛地标' }, { time: '11:30-13:30', title: '午餐', desc: '海鲜烧烤午餐' }, { time: '14:00-17:00', title: '八大关', desc: '欧式建筑散步' }, { time: '18:00-19:30', title: '金沙滩', desc: '海边休闲' }],
            2: [{ time: '08:00-12:00', title: '崂山', desc: '山海之间徒步' }, { time: '12:30-14:00', title: '崂山农家宴', desc: '品尝山野菜' }, { time: '14:30-16:30', title: '青岛啤酒博物馆', desc: '了解啤酒文化品原浆' }, { time: '17:00-18:30', title: '五四广场', desc: '看灯光秀' }]
        }
    },
    '南京': { name: '南京', features: ['history', 'food'],
        attractions: [
            { name: '中山陵', desc: '中国近代民主革命伟大先行者孙中山先生的陵寝及其附属纪念建筑群，依山傍水山势险峻', rating: 4.8, price: 0, tags: ['历史人文', '网红打卡'], openTime: '08:30-17:00 周一闭馆', duration: '2-3小时', bestTime: '上午', transport: '地铁2号线下马坊站', tips: ['博爱坊牌坊很气派，从牌坊到陵寝一路上去坡度缓', '提前在公众号预约', '音乐台鸽子很多适合拍照'] },
            { name: '夫子庙', desc: '夫子庙是一组规模宏大的古建筑群，中国四大文庙，秦淮河畔明清古建筑群', rating: 4.3, price: 0, tags: ['历史人文', '美食探店', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '地铁1号线三山街站', tips: ['夜晚秦淮河夜景很漂亮', '可以坐画舫游览秦淮河', '记得尝尝鸭血粉丝汤'] },
            { name: '明孝陵', desc: '明朝开国皇帝朱元璋和皇后马氏合葬于此，石像路神道很有气势，最美是秋天金黄的银杏叶', rating: 4.6, price: 65, tags: ['历史人文', '自然风光'], openTime: '06:30-18:00', duration: '3小时', bestTime: '上午', transport: '地铁2号线苜蓿园站', tips: ['神道石像路拍照绝美，翁仲路神道古朴，石象路是最美的路段'] },
            { name: '南京博物院', desc: '中国三大博物馆之一，历史悠久馆藏丰富，镇馆之宝金缕玉衣重点文物值得一看', rating: 4.7, price: 0, tags: ['历史人文'], openTime: '09:00-17:00 周一闭馆', duration: '3-4小时', bestTime: '上午', transport: '地铁2号线明故宫站', tips: ['提前预约门票', '历史馆数字馆民国馆艺术馆特展馆值得看', '民国馆拍照很出片'] },
            { name: '玄武湖', desc: '玄武门解放门进入，中国最大的皇家园林湖泊，东枕紫金山西靠明城墙，烟波浩渺钟山脚下', rating: 4.4, price: 0, tags: ['自然风光', '历史人文'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '地铁1号线玄武门站', tips: ['环湖步行很舒服', '郭璞墩莲花广场拍照很美', '夏天适合划船'] }
        ],
        foods: [
            { name: '鸭血粉丝汤', icon: '🍜', desc: '南京传统美食，鸭血细嫩鸭肝香酥油豆腐泡入味', price: 18, specialty: '南京小吃' },
            { name: '盐水鸭', icon: '🦆', desc: '皮白肉红骨头酥，香鲜味美咸香得味，金陵盐水鸭非常有名', price: 68, specialty: '南京名菜' },
            { name: '小笼包', icon: '🥟', desc: '皮薄馅大汤汁鲜美，咬一口一包汁', price: 25, specialty: '南京点心' },
            { name: '牛肉锅贴', icon: '🥟', desc: '外皮酥脆内馅鲜牛肉，咸甜上口', price: 20, specialty: '南京小吃' },
            { name: '赤豆元宵', icon: '🍡', desc: '糯韧绵软甘甜细腻，元宵节南京人必吃', price: 12, specialty: '南京甜点' }
        ],
        itineraries: {
            1: [{ time: '08:30-11:30', title: '中山陵', desc: '瞻仰革命先行者' }, { time: '12:00-13:30', title: '午餐', desc: '品尝南京小吃' }, { time: '14:00-17:00', title: '南京博物院', desc: '参观国宝' }, { time: '18:00-19:30', title: '夫子庙秦淮河', desc: '夜游秦淮河' }],
            2: [{ time: '08:30-11:00', title: '明孝陵', desc: '神道漫步欣赏石象路' }, { time: '11:30-13:00', title: '美龄宫', desc: '参观欣赏紫金山全景' }, { time: '13:30-15:30', title: '玄武湖', desc: '环湖游览' }, { time: '16:00-18:00', title: '老门东', desc: '逛古城吃小吃' }]
        }
    },
    '大理': { name: '大理', features: ['nature', 'instagram'],
        attractions: [ { name: '洱海', desc: '云南第二大淡水湖，环湖风景优美，适合骑行和拍照', rating: 4.8, price: 0, tags: ['自然风光', '网红打卡'], openTime: '全天开放', duration: '一天', bestTime: '春天', transport: '环海西路或东路', tips: ['建议租电动车环湖', '喜洲古镇和磻溪村值得去', '海西看日出，海东看日落'] }, { name: '大理古城', desc: '始建于明洪武年间，青石板路，古色古香', rating: 4.6, price: 0, tags: ['历史人文', '网红打卡'], openTime: '全天开放', duration: '半天', bestTime: '晚上', transport: '古城步行', tips: ['洋人街很热闹', '五华楼可以俯瞰古城', '人民路有很多文艺小店'] }, { name: '苍山', desc: '大理著名的雪山，可以乘坐缆车登顶', rating: 4.7, price: 40, tags: ['自然风光'], openTime: '08:30-16:30', duration: '半天', bestTime: '夏季', transport: '古城乘公交', tips: ['洗马潭索道海拔最高', '山上温度低，带外套', '玉带路风景最美'] }, { name: '双廊古镇', desc: '洱海东岸的美丽小镇，面朝洱海，背靠苍山', rating: 4.5, price: 0, tags: ['网红打卡', '美食探店'], openTime: '全天开放', duration: '半天', bestTime: '下午', transport: '环海东路', tips: ['玉几岛和南诏风情岛值得去', '杨丽萍太阳宫很有名', '海鲜不错'] }, { name: '崇圣寺三塔', desc: '大理标志性景点，千年古塔，气势恢宏', rating: 4.6, price: 75, tags: ['历史人文'], openTime: '07:30-19:30', duration: '2小时', bestTime: '上午', transport: '公交三塔专线', tips: ['倒影公园拍照最佳', '寺院很大，建议坐电瓶车', '塔本身不能登'] } ],
        foods: [ { name: '破酥粑粑', icon: '🫓', desc: '大理特色面点', price: 15, specialty: '滇味面点' }, { name: '饵丝', icon: '🍜', desc: '云南特色主食', price: 20, specialty: '滇味主食' }, { name: '酸辣鱼', icon: '🐟', desc: '洱海特色美食', price: 68, specialty: '滇味鱼鲜' }, { name: '乳扇', icon: '🧀', desc: '大理特色奶制品', price: 25, specialty: '滇味奶制' }, { name: '凉鸡米线', icon: '🍜', desc: '酸甜可口', price: 18, specialty: '滇味米线' } ],
        itineraries: { 1: [{ time: '08:00-11:00', title: '洱海环湖骑行', desc: '骑行洱海' }, { time: '11:30-13:00', title: '午餐-双廊', desc: '海边餐厅品酸辣鱼' }, { time: '14:30-17:30', title: '双廊古镇', desc: '漫步古镇' }, { time: '18:30-20:30', title: '大理古城', desc: '夜游古城' }], 2: [{ time: '08:30-11:30', title: '苍山', desc: '乘坐缆车登苍山' }, { time: '12:00-13:30', title: '午餐-大理古城', desc: '品尝当地特色' }, { time: '14:30-17:00', title: '崇圣寺三塔', desc: '参观千年古塔' }, { time: '18:00-20:00', title: '三塔倒影公园', desc: '拍摄三塔倒影美景' }] }
    }
};

const defaultDestination = { name: '目的地', features: ['nature', 'history', 'food', 'instagram'],
    attractions: [ { name: '市中心广场', desc: '城市的标志性中心区域，是市民休闲娱乐的重要场所', rating: 4.5, price: 0, tags: ['网红打卡'], openTime: '全天开放', duration: '1-2小时', bestTime: '晚上', transport: '市中心地铁', tips: ['晚上灯光很美', '周末可能有活动', '周边购物方便'] }, { name: '博物馆', desc: '了解城市历史文化的好去处，收藏丰富', rating: 4.6, price: 30, tags: ['历史人文'], openTime: '09:00-17:00', duration: '2-3小时', bestTime: '上午', transport: '地铁直达', tips: ['周一闭馆', '建议请讲解员', '拍照注意规定'] }, { name: '城市公园', desc: '市民休闲的好去处，绿树成荫', rating: 4.4, price: 0, tags: ['自然风光'], openTime: '全天开放', duration: '1-2小时', bestTime: '早晨', transport: '公交可达', tips: ['早晨空气好', '周末人较多', '有健身设施'] }, { name: '特色商业街', desc: '购物与美食的天堂，汇集各种品牌和小吃', rating: 4.3, price: 0, tags: ['美食探店', '网红打卡'], openTime: '全天开放', duration: '2-3小时', bestTime: '晚上', transport: '市中心地铁', tips: ['美食种类多', '节假日人多', '可以砍价'] }, { name: '观景台', desc: '俯瞰城市全景的最佳位置，视野开阔', rating: 4.5, price: 20, tags: ['网红打卡'], openTime: '09:00-21:00', duration: '1小时', bestTime: '傍晚', transport: '公交或步行', tips: ['日落时分最美', '可以看到夜景', '风大注意保暖'] } ],
    foods: [ { name: '当地特色菜', icon: '🍽️', desc: '具有地方特色的美味佳肴', price: 80, specialty: '地方名菜' }, { name: '街头小吃', icon: '🍢', desc: '物美价廉的本地特色小吃', price: 30, specialty: '地方小吃' }, { name: '网红餐厅', icon: '🏪', desc: '当地最受欢迎的特色餐厅', price: 100, specialty: '特色餐厅' }, { name: '夜市美食', icon: '🌙', desc: '夜晚最具烟火气的美食聚集地', price: 50, specialty: '地方夜市' }, { name: '传统老店', icon: '🏮', desc: '传承多年的老字号味道', price: 70, specialty: '地方老店' } ],
    itineraries: { 1: [{ time: '09:00-11:30', title: '城市中心游览', desc: '探索市中心标志性景点' }, { time: '12:00-13:30', title: '午餐', desc: '品尝当地特色美食' }, { time: '14:30-17:00', title: '博物馆参观', desc: '了解城市历史文化' }, { time: '18:00-20:30', title: '夜市美食', desc: '体验当地夜生活' }], 2: [{ time: '08:30-11:30', title: '自然风光游览', desc: '欣赏城市自然美景' }, { time: '12:00-13:30', title: '特色餐厅午餐', desc: '享用特色美食' }, { time: '14:30-17:00', title: '网红打卡地', desc: '拍照留念' }, { time: '18:00-20:00', title: '特色购物', desc: '购买当地特产纪念品' }] }
};

// 城市消费等级
const CITY_TIER_PRICES = {
    '北京': 'tier1', '上海': 'tier1', '广州': 'tier1', '深圳': 'tier1',
    '成都': 'new1', '杭州': 'new1', '重庆': 'new1', '武汉': 'new1', '南京': 'new1',
    '西安': 'new1', '苏州': 'new1', '天津': 'new1', '长沙': 'new1', '青岛': 'new1',
    '厦门': 'new1', '郑州': 'new1', '大连': 'new1', '宁波': 'new1', '昆明': 'new1',
    '大理': 'tier2', '丽江': 'tier2', '三亚': 'new1', '桂林': 'tier2', '张家界': 'tier2', '黄山': 'tier2',
    '拉萨': 'tier2', '珠海': 'new1', '无锡': 'new1', '东莞': 'new1', '佛山': 'new1'
};

// 人均日消费参考（元/天）
const DAILY_COST_REF = {
    tier1: { food: 150, local_transport: 30, tickets: 80, other: 50 },
    new1:  { food: 120, local_transport: 25, tickets: 60, other: 40 },
    tier2: { food: 90,  local_transport: 20, tickets: 40, other: 30 },
    tier3:  { food: 70,  local_transport: 15, tickets: 25, other: 20 }
};

// 住宿价格区间参考（元/晚）
const ACCOM_PRICE_REF = {
    economy: { tier1: [150, 280], new1: [120, 220], tier2: [80, 160], tier3: [60, 120] },
    comfort: { tier1: [350, 600], new1: [280, 480], tier2: [180, 350], tier3: [130, 260] },
    luxury:  { tier1: [700, 1500], new1: [550, 1100], tier2: [350, 800], tier3: [250, 600] }
};

// 旧的固定比例（仅作备用兜底）
const budgetAllocation = { transport: 0.25, accommodation: 0.30, food: 0.20, tickets: 0.15, other: 0.10 };

function getDestinationData(dest) {
    if (destinationData[dest]) return destinationData[dest];
    for (const k in destinationData) { if (dest.includes(k) || k.includes(dest)) return destinationData[k]; }
    return { ...defaultDestination, name: dest };
}

function filterAttractions(a, p) {
    if (!p || !p.length) return a.slice(0, 5);
    const m = { 'nature': '自然风光', 'history': '历史人文', 'food': '美食探店', 'instagram': '网红打卡' };
    const matched = [], unmatched = [];
    a.forEach(attr => { (attr.tags.some(t => p.some(pp => t.includes(m[pp]))) ? matched : unmatched).push(attr); });
    return [...matched, ...unmatched].slice(0, 5);
}


function getCityTier(city) {
    if (CITY_TIER_PRICES[city]) return CITY_TIER_PRICES[city];
    for (var k in CITY_TIER_PRICES) { if (city.includes(k) || k.includes(city)) return CITY_TIER_PRICES[k]; }
    return 'tier3'; // 默认三线
}

function getBudgetLevel(totalBudget, days) {
    var dailyBudget = totalBudget / Math.max(1, days);
    var tier = dailyBudget < 400 ? 'budget' : (dailyBudget < 1000 ? 'comfort' : 'luxury');
    return tier;
}

function getBudgetLevelLabel(level) {
    var map = { budget: '穷游省钱', comfort: '舒适自在', luxury: '品质奢华' };
    var colorMap = { budget: '#f59e0b', comfort: '#10b981', luxury: '#6366f1' };
    return { label: map[level] || '舒适自在', color: colorMap[level] || '#10b981' };
}

function calculateBudgetAllocation(totalBudget, days, destCity, transportCost, hotels, attractions) {
    var cityTier = getCityTier(destCity || '');
    var budgetLevel = getBudgetLevel(totalBudget, days);
    var nights = Math.max(0, days - 1);
    var dailyCost = DAILY_COST_REF[cityTier] || DAILY_COST_REF.tier3;

    // Step 1: 交通费用
    var actualTransportCost = transportCost || Math.round(totalBudget * 0.25);
    var remaining = totalBudget - actualTransportCost;
    var transportWarning = actualTransportCost > totalBudget * 0.5;
    if (transportWarning) {
        actualTransportCost = Math.round(totalBudget * 0.45);
        remaining = totalBudget - actualTransportCost;
    }

    // Step 2: 住宿费用 — 优先使用真实酒店数据
    var nightlyRate = 0;
    var accLevel = budgetLevel === 'budget' ? 'economy' : (budgetLevel === 'luxury' ? 'luxury' : 'comfort');
    var accRange = ACCOM_PRICE_REF[accLevel] ? ACCOM_PRICE_REF[accLevel][cityTier] || ACCOM_PRICE_REF[accLevel].tier3 : [150, 300];
    var idealNightlyRate = Math.round((accRange[0] + accRange[1]) / 2);

    if (hotels && hotels.length > 0) {
        // 使用推荐酒店的实际价格
        var recommendedHotel = hotels.find(function(h) { return h.recommended; }) || hotels[0];
        nightlyRate = recommendedHotel.pricePerNight;
    } else {
        nightlyRate = idealNightlyRate;
    }
    var accommodation = nightlyRate * nights;

    // Step 3: 门票费用 — 优先使用景点数据计算小计
    var tickets = 0;
    var ticketDetail = [];
    if (attractions && attractions.length > 0) {
        attractions.forEach(function(a) {
            var price = (typeof a.price === 'number') ? a.price : 0;
            tickets += price;
            ticketDetail.push({ name: a.name, price: price });
        });
    }
    if (tickets === 0) {
        tickets = Math.round(remaining * 0.18);
    }

    // Step 4: 剩余分配给餐饮和其他
    var afterAccomTickets = remaining - accommodation - tickets;
    var food = Math.round(afterAccomTickets * 0.55);
    var other = Math.round(afterAccomTickets * 0.45);

    // 确保最小值
    var minFood = dailyCost.food * days * 0.6;
    if (food < minFood && other > 0) {
        var transfer = Math.min(other, minFood - food);
        food += transfer;
        other -= transfer;
    }

    food = Math.max(0, food);
    other = Math.max(0, other);
    accommodation = Math.max(0, accommodation);
    tickets = Math.max(0, tickets);

    // 日均数据
    var dailyFood = days > 0 ? Math.round(food / days) : 0;
    var dailyTicket = days > 0 ? Math.round(tickets / days) : 0;
    var dailyOther = days > 0 ? Math.round(other / days) : 0;
    var dailyTotal = days > 0 ? Math.round((accommodation + food + tickets + other) / days) : 0;

    // 参考消费水平
    var refDailyTotal = dailyCost.food + dailyCost.local_transport + dailyCost.tickets + dailyCost.other;

    // 预算状态
    var budgetStatus = 'ok';
    if (remaining < refDailyTotal * days * 0.5) budgetStatus = 'tight';
    if (remaining < 0) budgetStatus = 'insufficient';

    return {
        transport: actualTransportCost,
        accommodation: accommodation,
        food: food,
        tickets: tickets,
        other: other,
        ticketDetail: ticketDetail,
        meta: {
            totalBudget: totalBudget,
            days: days,
            nights: nights,
            cityTier: cityTier,
            budgetLevel: budgetLevel,
            budgetLevelLabel: getBudgetLevelLabel(budgetLevel),
            nightlyRate: nightlyRate,
            dailyFood: dailyFood,
            dailyTicket: dailyTicket,
            dailyOther: dailyOther,
            dailyTotal: dailyTotal,
            budgetStatus: budgetStatus,
            transportWarning: transportWarning,
            refDailyTotal: refDailyTotal,
            hasHotelData: !!(hotels && hotels.length > 0),
            hasTicketData: !!(attractions && attractions.length > 0)
        }
    };
}

function getDateAfterDays(d) { const dt = new Date(); dt.setDate(dt.getDate() + d); return dt.toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' }); }

function generateItinerary(di, days, pace) {
    pace = pace || 'compact';
    var it = [];
    var maxPredef = Object.keys(di.itineraries || {}).length;
    var usedAttractions = new Set();

    for (var d = 1; d <= days; d++) {
        var schedule;
        if (d <= maxPredef && di.itineraries[d] && pace === 'compact') {
            schedule = di.itineraries[d];
            schedule.forEach(function(item) { usedAttractions.add(item.title); });
        } else {
            schedule = generateAutoDaySchedule(di, usedAttractions, d, days, pace);
        }
        it.push({ day: d, date: getDateAfterDays(d), schedule: schedule });
    }
    return it;
}

// 自动生成某一天的行程（避免与前几天重复景点）
function generateAutoDaySchedule(di, usedAttractions, dayNum, totalDays, pace) {
    pace = pace || 'compact';
    var attractions = di.attractions || [];
    var foods = di.foods || [];

    // 找出尚未使用过的景点
    var available = attractions.filter(function(a) { return !usedAttractions.has(a.name); });

    if (pace === 'comfort' || pace === 'relax') {
        // 只取1个评分最高的未使用景点
        var sorted = (available.length > 0 ? available : attractions).sort(function(a, b) { return (b.rating || 0) - (a.rating || 0); });
        var best = sorted[0];
        if (available.length > 0 && best) usedAttractions.add(best.name);
        return buildDaySchedule(best, null, foods, dayNum, null, pace);
    }

    // compact：保持现有逻辑
    if (available.length >= 2) {
        var offset = (dayNum * 2) % available.length;
        var morning = available[offset % available.length];
        var afternoon = available[(offset + 1) % available.length];
        if (morning && afternoon && morning.name === afternoon.name) {
            afternoon = available[(offset + 2) % available.length];
        }
        if (morning) usedAttractions.add(morning.name);
        if (afternoon) usedAttractions.add(afternoon.name);
        return buildDaySchedule(morning, afternoon, foods, dayNum, null, pace);
    }

    if (available.length === 1) {
        var last1 = available[0];
        var reused = attractions.filter(function(a) { return a.name !== last1.name; });
        var offset = (dayNum * 2) % Math.max(1, reused.length);
        var last2 = reused[offset % reused.length];
        if (last1) usedAttractions.add(last1.name);
        if (last2) usedAttractions.add(last2.name);
        return buildDaySchedule(last1, last2, foods, dayNum, null, pace);
    }

    // 全部景点都已去过
    var themes = ['慢游', '深度游', '经典回顾'];
    var themeIdx = (dayNum - 3) % themes.length;
    var theme = themes[themeIdx];
    var prevDayOffset = ((dayNum - 1) * 2) % Math.max(1, attractions.length);
    var offset = ((dayNum - 1) * 3 + 2) % Math.max(1, attractions.length);
    var morning = attractions[offset % attractions.length];
    var afternoon = attractions[(offset + 1) % attractions.length];
    if (morning && afternoon && morning.name === afternoon.name) {
        afternoon = attractions[(offset + 2) % attractions.length];
    }
    var prevMorning = attractions[prevDayOffset % attractions.length];
    if (morning && prevMorning && morning.name === prevMorning.name && attractions.length > 2) {
        morning = attractions[(offset + 2) % attractions.length];
    }
    if (morning) usedAttractions.add(morning.name);
    if (afternoon) usedAttractions.add(afternoon.name);
    return buildDaySchedule(morning, afternoon, foods, dayNum, theme, pace);
}

function buildDaySchedule(morning, afternoon, foods, dayNum, theme, pace) {
    pace = pace || 'compact';
    var lunchFood = foods[(dayNum - 1) % Math.max(1, foods.length)];
    var dinnerFood = foods[dayNum % Math.max(1, foods.length)];

    var schedule = [];

    if (pace === 'compact') {
        // 保持现有逻辑不变
        if (morning) {
            schedule.push({ period: 'morning', label: '☀️ 上午', time: '09:00-11:30', title: morning.name, desc: morning.desc + (theme ? '（' + theme + '）' : '') });
        }
        if (lunchFood) {
            schedule.push({ period: 'lunch', label: '🍽️ 午餐', time: '12:00-13:30', title: '午餐-' + lunchFood.name, desc: lunchFood.desc });
        }
        if (afternoon) {
            schedule.push({ period: 'afternoon', label: '🌤️ 下午', time: '14:30-17:00', title: afternoon.name, desc: afternoon.desc + (theme ? '（' + theme + '）' : '') });
        }
        if (dinnerFood) {
            schedule.push({ period: 'dinner', label: '🌙 晚上', time: '18:00-20:30', title: '晚餐-' + dinnerFood.name, desc: '品尝当地特色' + dinnerFood.name });
        }
    } else if (pace === 'comfort') {
        // 只保留上午景点 + 午餐 + 晚餐，下午换成自由探索
        if (morning) {
            schedule.push({ period: 'morning', label: '☀️ 上午', time: '09:00-11:30', title: morning.name, desc: morning.desc + (theme ? '（' + theme + '）' : '') });
        }
        if (lunchFood) {
            schedule.push({ period: 'lunch', label: '🍽️ 午餐', time: '12:00-13:30', title: '午餐-' + lunchFood.name, desc: lunchFood.desc });
        }
        schedule.push({ period: 'afternoon', label: '🌤️ 下午', time: '14:00-17:00', title: '自由探索', desc: '附近街区漫步' + (theme ? '（' + theme + '）' : '') + '，发现不期而遇的惊喜' });
        if (dinnerFood) {
            schedule.push({ period: 'dinner', label: '🌙 晚上', time: '18:00-20:30', title: '晚餐-' + dinnerFood.name, desc: '品尝当地特色' + dinnerFood.name });
        }
    } else if (pace === 'relax') {
        // 只保留上午景点 + 午餐 + 自由晚上
        if (morning) {
            schedule.push({ period: 'morning', label: '☀️ 上午', time: '09:00-11:30', title: morning.name, desc: morning.desc + (theme ? '（' + theme + '）' : '') });
        }
        if (lunchFood) {
            schedule.push({ period: 'lunch', label: '🍽️ 午餐', time: '12:00-13:30', title: '午餐-' + lunchFood.name, desc: lunchFood.desc });
        }
        schedule.push({ period: 'afternoon', label: '🌤️ 下午', time: '14:00-18:00', title: '自由探索', desc: '享受当地慢生活，泡茶馆、逛小店' + (theme ? '（' + theme + '）' : '') });
        schedule.push({ period: 'dinner', label: '🌙 晚上', time: '18:00-21:00', title: '自由探索', desc: '随兴所至，享受当地夜生活' });
    }

    return schedule;
}


// 渲染函数
function renderTransport(t) {
    document.getElementById('transportOptions').innerHTML = t.map(i => `<div class="transport-item ${i.class||''}"><div class="transport-icon">${i.icon}</div><div class="transport-info"><div class="transport-name">${i.name}</div><div class="transport-detail">约 ${i.distKm} 公里 · ${i.time}</div></div><div class="transport-price"><div class="price">¥${i.cost}</div><div class="time">预估费用</div></div></div>`).join('');
    document.getElementById('transportSection').style.display = 'block';
}

function renderBudgetChart(bd, tb) {
    var meta = bd.meta || {};
    var c = document.getElementById('budgetPieChart'), ctx = c.getContext('2d');
    c.width = 200; c.height = 200;
    var d = [
        { l: '交通', v: bd.transport, c: '#4f46e5', sub: '往返费用' },
        { l: '住宿', v: bd.accommodation, c: '#10b981', sub: meta.nightlyRate ? '\u00a5' + meta.nightlyRate + '/晚' : '' },
        { l: '餐饮', v: bd.food, c: '#f59e0b', sub: meta.dailyFood ? '\u00a5' + meta.dailyFood + '/天' : '' },
        { l: '门票', v: bd.tickets, c: '#ec4899', sub: meta.dailyTicket ? '\u00a5' + meta.dailyTicket + '/天' : '' },
        { l: '其他', v: bd.other, c: '#8b5cf6', sub: '' }
    ];
    var sa = 0;
    d.forEach(function(i) { var sl = (i.v / tb) * 2 * Math.PI; ctx.beginPath(); ctx.moveTo(100, 100); ctx.arc(100, 100, 80, sa, sa + sl); ctx.closePath(); ctx.fillStyle = i.c; ctx.fill(); sa += sl; });
    ctx.beginPath(); ctx.arc(100, 100, 50, 0, 2 * Math.PI); ctx.fillStyle = '#fff'; ctx.fill();
    ctx.fillStyle = '#1e293b'; ctx.font = 'bold 16px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('\u00a5' + tb.toLocaleString(), 100, 90);
    ctx.font = '11px Segoe UI'; ctx.fillStyle = '#64748b'; ctx.fillText('总预算', 100, 106);
    if (meta.budgetLevelLabel) {
        ctx.fillStyle = meta.budgetLevelLabel.color; ctx.font = 'bold 11px Segoe UI';
        ctx.fillText(meta.budgetLevelLabel.label, 100, 120);
    }
    document.getElementById('budgetLegend').innerHTML = d.map(function(i) {
        var pct = Math.round((i.v / tb) * 100);
        return '<div class="legend-item"><div class="legend-color" style="background:' + i.c + '"></div><div class="legend-label">' + i.l + (i.sub ? '<div class="legend-sub">' + i.sub + '</div>' : '') + '</div><div class="legend-value">\u00a5' + i.v.toLocaleString() + '</div><div class="legend-percent">' + pct + '%</div></div>';
    }).join('');

    var statusHTML = '';
    if (meta.budgetStatus === 'insufficient') {
        statusHTML = '<div class="budget-warning">\u26a0\ufe0f \u9884算提示：交通费用占比过高，建议增加预算或选择更经济的交通方式</div>';
    } else if (meta.budgetStatus === 'tight') {
        statusHTML = '<div class="budget-warning budget-tight">\u{1f4a1} \u9884算偷紧：日均可用资金较少，建议优先安排免费景点，住宿选择经济型</div>';
    }

    var tierLabel = { tier1: '一线城市', new1: '新一线城市', tier2: '二线城市', tier3: '三线城市' };
    var tierName = tierLabel[meta.cityTier] || '';

    // 每日预算明细
    var dailyBreakdownHTML = '';
    if (meta.dailyTotal) {
        var dailyItems = [
            { icon: '\u{1F3E8}', label: '住宿', value: meta.nightlyRate, unit: '/晚', color: '#10b981' },
            { icon: '\u{1F372}', label: '餐饮', value: meta.dailyFood, unit: '/天', color: '#f59e0b' },
            { icon: '\u{1F3AB}', label: '门票', value: meta.dailyTicket, unit: '/天', color: '#ec4899' },
            { icon: '\u{1F4A1}', label: '其他', value: meta.dailyOther, unit: '/天', color: '#8b5cf6' }
        ];
        dailyBreakdownHTML = '<div class="budget-daily-breakdown">' +
            '<div class="budget-daily-header">' +
                '<span class="budget-daily-title">\u{1F4C5} 每日预算明细</span>' +
                '<span class="budget-daily-total">日均 \u00a5' + meta.dailyTotal.toLocaleString() + '</span>' +
            '</div>' +
            '<div class="budget-daily-cards">' +
                dailyItems.map(function(item) {
                    return '<div class="budget-daily-card">' +
                        '<div class="budget-daily-card-icon" style="background:' + item.color + '20;color:' + item.color + '">' + item.icon + '</div>' +
                        '<div class="budget-daily-card-label">' + item.label + '</div>' +
                        '<div class="budget-daily-card-value">\u00a5' + item.value.toLocaleString() + '</div>' +
                        '<div class="budget-daily-card-unit">' + item.unit + '</div>' +
                    '</div>';
                }).join('') +
            '</div>' +
        '</div>';
    }

    // 酒店价格详情
    var hotelDetailHTML = '';
    if (meta.hasHotelData) {
        hotelDetailHTML = '<div class="budget-hotel-detail">' +
            '<span class="budget-hotel-icon">\u{1F3E8}</span>' +
            '<span class="budget-hotel-text">推荐酒店 \u00a5' + meta.nightlyRate.toLocaleString() + '/晚 \u00d7 ' + meta.nights + '晚 = \u00a5' + bd.accommodation.toLocaleString() + '</span>' +
            '<span class="budget-hotel-badge">真实价格</span>' +
        '</div>';
    }

    // 门票小计
    var ticketDetailHTML = '';
    if (meta.hasTicketData && bd.ticketDetail && bd.ticketDetail.length > 0) {
        var ticketItems = bd.ticketDetail.filter(function(t) { return t.price > 0; });
        if (ticketItems.length > 0) {
            ticketDetailHTML = '<div class="budget-ticket-detail">' +
                '<div class="budget-ticket-header">\u{1F3AB} 门票小计</div>' +
                ticketItems.map(function(t) {
                    return '<div class="budget-ticket-row"><span class="budget-ticket-name">' + t.name + '</span><span class="budget-ticket-price">\u00a5' + t.price.toLocaleString() + '</span></div>';
                }).join('') +
                '<div class="budget-ticket-row total"><span class="budget-ticket-name">合计</span><span class="budget-ticket-price">\u00a5' + bd.tickets.toLocaleString() + '</span></div>' +
            '</div>';
        }
    }

    document.getElementById('budgetDetails').innerHTML =
        '<div class="budget-meta-row">' +
            '<span class="budget-meta-tag">' + (tierName || '标准城市') + '</span>' +
            '<span class="budget-meta-tag">' + meta.days + '天' + (meta.nights > 0 ? meta.nights + '晚' : '') + '</span>' +
            (meta.refDailyTotal ? '<span class="budget-meta-tag">日均参考（不含住宿） \u00a5' + meta.refDailyTotal + '</span>' : '') +
        '</div>' +
        statusHTML +
        dailyBreakdownHTML +
        hotelDetailHTML +
        ticketDetailHTML +
        d.map(function(i) {
            return '<div class="budget-item"><div class="label">' + i.l + (i.sub ? '<div class="budget-sub">' + i.sub + '</div>' : '') + '</div><div class="amount">\u00a5' + i.v.toLocaleString() + '</div></div>';
        }).join('');

    document.getElementById('budgetSection').style.display = 'block';
}

/**
 * 获取到真实景点数据后，动态更新预算中的门票小计
 */
function updateBudgetTickets(attractions, budget, travelDays, destCity, transportCost, hotels) {
    if (!attractions || attractions.length === 0) return;
    var bd = calculateBudgetAllocation(budget, travelDays, destCity, transportCost, hotels, attractions);
    renderBudgetChart(bd, budget);
}

function searchAttractionsByAmap(city, lng, lat) {
    return new Promise(function(resolve) {
        if (!window.AMap) {
            resolve([]);
            return;
        }
        
        AMap.plugin('AMap.PlaceSearch', function() {
            var placeSearch = new AMap.PlaceSearch({
                pageSize: 15,
                pageIndex: 1,
                types: '旅游景点|风景名胜|文物古迹|主题公园|A级景区',
                city: city,
                extensions: 'all'
            });
            
            var allPois = [];
            var searchCount = 0;
            var totalSearches = 3;
            
            function finishSearch() {
                searchCount++;
                if (searchCount >= totalSearches) {
                    var poiMap = {};
                    allPois.forEach(function(poi) {
                        if (!poiMap[poi.name]) {
                            poiMap[poi.name] = poi;
                        } else if (poi.rating && poiMap[poi.name].rating && parseFloat(poi.rating) > parseFloat(poiMap[poi.name].rating)) {
                            poiMap[poi.name] = poi;
                        }
                    });
                    
                    var attractions = Object.values(poiMap).map(function(poi) {
                        var tags = [];
                        if (poi.type) {
                            if (poi.type.includes('风景') || poi.type.includes('自然')) tags.push('自然风光');
                            if (poi.type.includes('历史') || poi.type.includes('古迹')) tags.push('历史人文');
                            if (poi.type.includes('公园') || poi.type.includes('园林')) tags.push('自然风光');
                            if (poi.type.includes('文化') || poi.type.includes('博物馆')) tags.push('历史人文');
                            if (poi.type.includes('主题')) tags.push('网红打卡');
                            if (poi.type.includes('广场') || poi.type.includes('商业')) tags.push('网红打卡');
                            if (poi.type.includes('景区')) tags.push('自然风光');
                        }
                        if (poi.photos && poi.photos.length > 0) {
                            tags.push('网红打卡');
                        }
                        
                        var desc = poi.address || poi.type || '暂无介绍';
                        if (poi.tel && !desc.includes(poi.tel)) {
                            desc += ' · 电话: ' + poi.tel;
                        }
                        
                        var verifiedInfo = null;
                        for (var key in verifiedAttractionInfo) {
                            if (poi.name.includes(key) || key.includes(poi.name)) {
                                verifiedInfo = verifiedAttractionInfo[key];
                                break;
                            }
                        }
                        
                        var openTime = poi.openTime || '全天开放';
                        var closedDay = '';
                        var duration = '';
                        var bestTime = '';
                        var tips = [];
                        
                        var verifiedPrice = 0;
                        if (verifiedInfo) {
                            openTime = verifiedInfo.openTime || openTime;
                            closedDay = verifiedInfo.closedDay || '';
                            duration = verifiedInfo.duration || '';
                            bestTime = verifiedInfo.bestTime || '';
                            tips = verifiedInfo.tips || [];
                            verifiedPrice = verifiedInfo.price || 0;
                        } else {
                            if (poi.rating && parseFloat(poi.rating) >= 4.5) {
                                tips.push('该景点评分较高，建议提前预约门票');
                            }
                            if (poi.cost && parseFloat(poi.cost) > 100) {
                                tips.push('门票价格较高，可关注优惠活动');
                            }
                            tips.push('穿着舒适的运动鞋，方便长时间行走');
                            tips.push('建议提前查看天气预报');
                        }
                        
                        return {
                            name: poi.name,
                            desc: desc,
                            rating: parseFloat(poi.rating) || 4.5,
                            price: verifiedPrice || (poi.cost ? parseFloat(poi.cost.replace(/[^0-9.]/g, '')) : 0),
                            tags: tags.length > 0 ? tags : ['自然风光'],
                            lng: poi.location.lng,
                            lat: poi.location.lat,
                            image: poi.photos && poi.photos.length > 0 ? poi.photos[0].url : null,
                            openTime: openTime,
                            closedDay: closedDay,
                            duration: duration,
                            bestTime: bestTime,
                            address: poi.address || '暂无地址',
                            distance: poi.distance,
                            tips: tips
                        };
                    }).sort(function(a, b) {
                        return (b.rating || 0) - (a.rating || 0);
                    });
                    
                    resolve(attractions.slice(0, 5));
                }
            }
            
            placeSearch.search(city + '景点', function(status, result) {
                if (status === 'complete' && result.poiList && result.poiList.pois) {
                    allPois = allPois.concat(result.poiList.pois);
                }
                finishSearch();
            });
            
            placeSearch.search(city + '著名景点', function(status, result) {
                if (status === 'complete' && result.poiList && result.poiList.pois) {
                    allPois = allPois.concat(result.poiList.pois);
                }
                finishSearch();
            });
            
            placeSearch.searchNearBy('', [lng, lat], 10000, function(status, result) {
                if (status === 'complete' && result.poiList && result.poiList.pois) {
                    allPois = allPois.concat(result.poiList.pois);
                }
                finishSearch();
            });
        });
    });
}

function renderAttractions(a) {
    document.getElementById('attractionsList').innerHTML = a.map(function(at, i) {
        var imgHTML = at.image ? 
            '<div class="attraction-image"><img src="' + at.image + '" alt="' + at.name + '" onerror="this.style.display=\'none\'"></div>' : 
            '';
        var metaHTML = '';
        if (at.openTime || at.duration || at.bestTime) {
            metaHTML = '<div class="attraction-meta">';
            if (at.openTime) metaHTML += '<span class="attraction-meta-item">⏰ ' + at.openTime + '</span>';
            if (at.duration) metaHTML += '<span class="attraction-meta-item">⌛ ' + at.duration + '</span>';
            if (at.bestTime) metaHTML += '<span class="attraction-meta-item">☀️ 最佳 ' + at.bestTime + '</span>';
            metaHTML += '</div>';
        }
        var tipsHTML = '';
        if (at.tips && at.tips.length > 0) {
            tipsHTML = '<div class="attraction-tips">' + at.tips.slice(0, 2).map(function(t) { return '<span class="attraction-tip">💡 ' + t + '</span>'; }).join('') + '</div>';
        }
        return '<div class="attraction-item" onclick="openAttractionDetail(' + i + ')">' +
            imgHTML +
            '<div class="attraction-badge"><span class="rating">' + at.rating + '</span><span class="max-rating">/5</span></div>' +
            '<div class="attraction-info"><div class="attraction-name">' + (i+1) + '. ' + at.name + '</div>' +
            '<div class="attraction-desc">' + at.desc + '</div>' +
            metaHTML +
            '<div class="attraction-tags">' + at.tags.map(function(t) { return '<span class="tag">' + t + '</span>'; }).join('') + '</div>' +
            tipsHTML +
            '</div><div class="attraction-price">' + (at.price===0?'免费':'¥' + at.price) + (at.price>0?'<div class="unit">/人</div>':'') + '</div>' +
            '<div class="attraction-arrow">→</div></div>';
    }).join('');
    window._currentAttractions = a;
    document.getElementById('attractionsSection').style.display = 'block';
}

function openAttractionDetail(index) {
    var attractions = window._currentAttractions || [];
    if (!attractions[index]) return;
    var detail = attractions[index];
    localStorage.setItem('_currentAttractionDetail', JSON.stringify(detail));
    localStorage.setItem('_ad_' + index, JSON.stringify(detail));
    
    var formData = getFormData();
    if (formData) {
        localStorage.setItem('_returnFormData', JSON.stringify(formData));
    }
    
    window.open('attraction.html?i=' + index, '_blank');
}

function clearFieldErrors() {
    document.querySelectorAll('.field-error').forEach(function(el) { el.remove(); });
    document.querySelectorAll('.field-error-border').forEach(function(el) { el.classList.remove('field-error-border'); });
}

function showFieldError(fieldId, message) {
    var el = document.getElementById(fieldId);
    if (!el) {
        var selector = document.querySelector('#' + fieldId);
        if (!selector) return;
        el = selector;
    }
    if (el.classList) {
        el.classList.add('field-error-border');
    }
    var errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    el.parentNode.appendChild(errorDiv);
}


function getFormData() {
    return {
        departureCity: document.getElementById('departureCity').value.trim(),
        departureLng: document.getElementById('departureLng').value,
        departureLat: document.getElementById('departureLat').value,
        destinationCity: document.getElementById('destinationCity').value.trim(),
        destinationLng: document.getElementById('destinationLng').value,
        destinationLat: document.getElementById('destinationLat').value,
        travelDate: document.getElementById('travelDate').value,
        travelDays: parseInt(document.getElementById('travelDays').value),
        budget: parseInt(document.getElementById('budget').value),
        preferences: Array.from(document.querySelectorAll('input[name="preference"]:checked')).map(function(cb) { return cb.value; }),
        pace: (document.querySelector('input[name="pace"]:checked') || {}).value || 'compact'
    };
}

function checkReturnFromDetail() {
    var params = new URLSearchParams(window.location.search);
    if (params.get('return') === '1') {
        var savedData = localStorage.getItem('_returnFormData');
        if (savedData) {
            try {
                var formData = JSON.parse(savedData);
                fillFormData(formData);
                setTimeout(function() {
                    handleFormSubmit({ preventDefault: function() {} });
                }, 500);
            } catch (e) {
                console.error('Failed to restore form data:', e);
            } finally {
                localStorage.removeItem('_returnFormData');
            }
        }
        var newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
    }
}

function fillFormData(data) {
    var form = document.getElementById('travelForm');
    if (!form || !data) return;
    
    if (data.departureCity) {
        departureSelector.selectPlace(data.departureCity, data.departureLng, data.departureLat);
    }
    if (data.destinationCity) {
        destinationSelector.selectPlace(data.destinationCity, data.destinationLng, data.destinationLat);
    }
    if (data.travelDate) form.travelDate.value = data.travelDate;
    if (data.travelDays) form.travelDays.value = data.travelDays;
    if (data.budget) form.budget.value = data.budget;
    
    if (data.preferences && data.preferences.length > 0) {
        form.querySelectorAll('input[name="preference"]').forEach(function(cb) {
            cb.checked = data.preferences.includes(cb.value);
        });
    }
    
    window._lastDepartureLng = data.departureLng;
    window._lastDepartureLat = data.departureLat;
    window._lastDestinationLng = data.destinationLng;
    window._lastDestinationLat = data.destinationLat;
}


// ========================================
// 酒店住宿推荐数据
// ========================================

// 酒店品牌库
const HOTEL_BRANDS = {
    economy: ['汉庭酒店', '7天优品', '如家精选', '格林豪泰', '锦江之星', '速8酒店', '布丁酒店'],
    comfort: ['全季酒店', '亚朵酒店', '桔子水晶', '维也纳酒店', '麗枫酒店', '智选假日', '宜尚酒店'],
    luxury: ['希尔顿酒店', '万豪酒店', '洲际酒店', '香格里拉', '凯悦酒店', '喜来登酒店', 'W酒店']
};

// 热门商圈/区域
const CITY_DISTRICTS = {
    '成都': ['春熙路/太古里', '宽窄巷子', '锦里/武侯祠', '天府广场', '成都东站'],
    '北京': ['王府井', '三里屯', '西单', '国贸CBD', '前门/大栅栏'],
    '上海': ['外滩', '南京路', '陆家嘴', '淮海路', '静安寺'],
    '杭州': ['西湖', '武林广场', '钱江新城', '河坊街', '西溪湿地'],
    '西安': ['钟楼/回民街', '大雁塔', '小寨', '南门', '火车站'],
    '重庆': ['解放碑', '洪崖洞', '观音桥', '南坪', '沙坪坝'],
    '广州': ['天河CBD', '北京路', '上下九', '琶洲', '白云机场'],
    '深圳': ['福田CBD', '南山科技园', '罗湖', '华侨城', '宝安中心'],
    '厦门': ['中山路', '鼓浪屿', '曾厝垵', '环岛路', 'SM广场'],
    '南京': ['新街口', '夫子庙', '玄武湖', '河西CBD', '南站'],
    '武汉': ['江汉路', '光谷', '汉口江滩', '黄鹤楼', '武汉站'],
    '长沙': ['五一广场', '橘子洲', '岳麓山', '火车站', '德思勤'],
    '三亚': ['三亚湾', '亚龙湾', '海棠湾', '大东海', '市区'],
    '丽江': ['大研古城', '束河古镇', '白沙古镇', '玉龙雪山', '市区'],
    '桂林': ['漓江景区', '阳朔西街', '象山区', '七星区', '两江四湖'],
    '张家界': ['武陵源', '天门山', '永定区', '森林公园', '市区'],
    '苏州': ['观前街', '平江路', '工业园区', '虎丘区', '吴中区'],
    '青岛': ['栈桥/中山路', '八大关', '崂山区', '市北CBD', '黄岛金沙滩'],
};

// 城市级别与基础价格
const CITY_BASE_PRICES = {
    '一线城市': {economy: [220, 320], comfort: [400, 600], luxury: [800, 1500]},
    '新一线': {economy: [160, 260], comfort: [320, 480], luxury: [600, 1100]},
    '二线': {economy: [120, 200], comfort: [240, 380], luxury: [450, 800]},
    '三线': {economy: [80, 150], comfort: [180, 300], luxury: [350, 600]}
};

// 城市级别映射
const CITY_TIERS = {
    '一线城市': ['北京', '上海', '广州', '深圳'],
    '新一线': ['成都', '杭州', '重庆', '西安', '苏州', '武汉', '南京', '长沙', '天津', '郑州', '东莞', '青岛', '昆明', '宁波', '合肥'],
    '二线': ['厦门', '大连', '福州', '济南', '哈尔滨', '长春', '沈阳', '石家庄', '太原', '南宁', '贵阳', '南昌', '兰州', '乌鲁木齐', '无锡', '佛山', '温州', '常州', '南通', '烟台', '徐州', '珠海', '惠州', '嘉兴', '中山', '绍兴', '扬州', '泉州', '金华', '台州', '镇江', '海口', '三亚', '呼和浩特', '银川', '西宁', '拉萨', '桂林', '丽江', '大理'],
    '三线': [] // 其他城市默认三线
};

// 酒店特色标签
const HOTEL_TAGS = {
    economy: ['交通便利', '干净卫生', '性价比高', '近地铁', '免费WiFi'],
    comfort: ['商务出行', '品质服务', '自助早餐', '健身房', '近商圈'],
    luxury: ['高端享受', 'SPA水疗', '无边泳池', '行政酒廊', '管家服务']
};

/**
 * 根据城市名获取城市级别
 * @param {string} city - 城市名
 * @returns {string} 城市级别
 */
function getCityTier(city) {
    for (const [tier, cities] of Object.entries(CITY_TIERS)) {
        if (cities.includes(city)) {
            return tier;
        }
    }
    return '三线';
}

/**
 * 生成酒店推荐
 * @param {string} city - 目的地城市
 * @param {number} budget - 总预算
 * @param {number} days - 旅行天数
 * @returns {Array} 酒店推荐列表
 */
function generateHotelRecommendations(city, budget, days) {
    const tier = getCityTier(city);
    const basePrices = CITY_BASE_PRICES[tier];
    const districts = CITY_DISTRICTS[city] || ['市中心', '火车站', '商业街', '景区附近', '新区'];
    const results = [];

    // 计算每晚住宿预算（按总预算的25%估算住宿费用，再除以天数）
    const nightlyBudget = Math.round((budget * 0.25) / days);

    // 为每个档次生成1-2个推荐
    const tiers = ['economy', 'comfort', 'luxury'];
    const tierNames = { economy: '经济型', comfort: '舒适型', luxury: '豪华型' };
    const tierClass = { economy: 'economy', comfort: 'comfort', luxury: 'luxury' };

    tiers.forEach((t, idx) => {
        const [minPrice, maxPrice] = basePrices[t];
        const brandPool = HOTEL_BRANDS[t];
        const tagPool = HOTEL_TAGS[t];

        // 每个档次生成1-2个
        const count = idx === 1 ? 2 : 1;
        for (let i = 0; i < count; i++) {
            const brand = brandPool[(i + idx) % brandPool.length];
            const district = districts[(i + idx) % districts.length];
            // 价格在基础区间内浮动
            const pricePerNight = Math.round(minPrice + Math.random() * (maxPrice - minPrice));
            const totalPrice = pricePerNight * days;
            const rating = (4.0 + Math.random() * 1.0).toFixed(1);
            const distance = (0.5 + Math.random() * 8).toFixed(1);
            // 随机选2-3个标签
            const tags = [];
            const tagCount = 2 + Math.floor(Math.random() * 2);
            for (let j = 0; j < tagCount; j++) {
                const tag = tagPool[(j + i) % tagPool.length];
                if (!tags.includes(tag)) tags.push(tag);
            }

            results.push({
                name: brand + '（' + district + '店）',
                tier: tierNames[t],
                tierClass: tierClass[t],
                pricePerNight: pricePerNight,
                totalPrice: totalPrice,
                rating: parseFloat(rating),
                district: district,
                tags: tags,
                distance: parseFloat(distance),
                city: city
            });
        }
    });

    // 标记最符合预算的推荐
    // 找到每晚价格最接近预算的
    let bestIdx = 0;
    let bestDiff = Infinity;
    results.forEach((hotel, idx) => {
        const diff = Math.abs(hotel.pricePerNight - nightlyBudget);
        if (diff < bestDiff) {
            bestDiff = diff;
            bestIdx = idx;
        }
    });
    results[bestIdx].recommended = true;

    return results;
}

/**
 * 渲染酒店推荐
 * @param {Array} hotels - 酒店推荐列表
 */
function renderHotels(hotels) {
    const container = document.getElementById('hotelContent');
    const section = document.getElementById('hotelSection');
    if (!container || !section) return;

    // 存储酒店数据供筛选使用
    container._hotelsData = hotels;

    // 渲染筛选栏
    var filterHtml = '<div class="hotel-filter-bar">' +
        '<div class="hotel-sort-tabs">' +
            '<span class="hotel-sort-label">排序：</span>' +
            '<button class="hotel-sort-btn active" data-sort="recommend">推荐</button>' +
            '<button class="hotel-sort-btn" data-sort="price-asc">价格↑</button>' +
            '<button class="hotel-sort-btn" data-sort="price-desc">价格↓</button>' +
            '<button class="hotel-sort-btn" data-sort="rating">评分</button>' +
            '<button class="hotel-sort-btn" data-sort="distance">距离</button>' +
        '</div>' +
        '<div class="hotel-tier-filters">' +
            '<span class="hotel-tier-label">档位：</span>' +
            '<button class="hotel-tier-btn active" data-tier="all">全部</button>' +
            '<button class="hotel-tier-btn" data-tier="economy">经济型</button>' +
            '<button class="hotel-tier-btn" data-tier="comfort">舒适型</button>' +
            '<button class="hotel-tier-btn" data-tier="luxury">豪华型</button>' +
        '</div>' +
    '</div>' +
    '<div class="hotel-grid" id="hotelGrid"></div>';

    container.innerHTML = filterHtml;
    section.style.display = 'block';

    // 绑定筛选事件
    var sortBtns = container.querySelectorAll('.hotel-sort-btn');
    var tierBtns = container.querySelectorAll('.hotel-tier-btn');
    var currentSort = 'recommend';
    var currentTier = 'all';

    sortBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            sortBtns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            currentSort = btn.getAttribute('data-sort');
            renderFilteredHotels(hotels, currentSort, currentTier);
        });
    });

    tierBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            tierBtns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            currentTier = btn.getAttribute('data-tier');
            renderFilteredHotels(hotels, currentSort, currentTier);
        });
    });

    // 初始渲染
    renderFilteredHotels(hotels, 'recommend', 'all');
}

function renderFilteredHotels(hotels, sortType, tier) {
    var grid = document.getElementById('hotelGrid');
    if (!grid) return;

    var stars = function(rating) { return '★'.repeat(Math.floor(rating)) + (rating % 1 >= 0.5 ? '☆' : ''); };

    // 按档位筛选
    var filtered = hotels;
    if (tier !== 'all') {
        var tierMap = { 'economy': 'budget', 'comfort': 'comfort', 'luxury': 'luxury' };
        filtered = hotels.filter(function(h) { return h.tierClass === tierMap[tier]; });
    }

    // 排序
    var sorted = filtered.slice();
    switch (sortType) {
        case 'price-asc':
            sorted.sort(function(a, b) { return a.pricePerNight - b.pricePerNight; });
            break;
        case 'price-desc':
            sorted.sort(function(a, b) { return b.pricePerNight - a.pricePerNight; });
            break;
        case 'rating':
            sorted.sort(function(a, b) { return b.rating - a.rating; });
            break;
        case 'distance':
            sorted.sort(function(a, b) { return a.distance - b.distance; });
            break;
        case 'recommend':
        default:
            sorted.sort(function(a, b) { return (b.recommended ? 1 : 0) - (a.recommended ? 1 : 0) || b.rating - a.rating; });
            break;
    }

    if (sorted.length === 0) {
        grid.innerHTML = '<div class="hotel-empty">没有匹配的酒店，请尝试其他筛选条件</div>';
        return;
    }

    grid.innerHTML = sorted.map(function(hotel) {
        var mapUrl = 'https://ditu.amap.com/search?query=' + encodeURIComponent(hotel.city + ' ' + hotel.name);
        var bookUrl = 'https://www.ctrip.com';
        var recBadge = hotel.recommended ? '<div style="position:absolute;top:-1px;right:-1px;background:#f59e0b;color:#fff;font-size:12px;padding:4px 12px;border-radius:0 12px 0 12px;font-weight:600;">推荐</div>' : '';
        var recClass = hotel.recommended ? 'recommended' : '';

        return '<div class="hotel-card ' + recClass + '" style="position:relative;">' +
            recBadge +
            '<div class="hotel-name">' + hotel.name + '</div>' +
            '<span class="hotel-tier ' + hotel.tierClass + '">' + hotel.tier + '</span>' +
            '<div class="hotel-price">' +
                '¥' + hotel.pricePerNight +
                '<span class="per-night">/晚 · 共¥' + hotel.totalPrice + '（' + hotel.city + ' ' + hotel.district + '）</span>' +
            '</div>' +
            '<div class="hotel-rating">' + stars(hotel.rating) + ' ' + hotel.rating + '分</div>' +
            '<div class="hotel-location">📍 距市中心约' + hotel.distance + '公里 · ' + hotel.district + '</div>' +
            '<div class="hotel-tags">' +
                hotel.tags.map(function(tag) { return '<span class="hotel-tag">' + tag + '</span>'; }).join('') +
            '</div>' +
            '<div class="hotel-actions">' +
                '<a href="' + mapUrl + '" target="_blank" class="btn-map">🗺️ 高德地图</a>' +
                '<a href="' + bookUrl + '" target="_blank" class="btn-book">🏨 打开携程</a>' +
            '</div>' +
        '</div>';
    }).join('');
}

// 美食地图相关变量
var foodMapOverlay = null;
var foodMapInstance = null;
var foodMapMarkers = [];
var foodMapInfoWindow = null;
var foodNavRouteLine = null;
var foodNavRouteMarkers = [];
var foodMapDestLng = null;
var foodMapDestLat = null;

function renderFoods(f, destCity, destLng, destLat) {
    document.getElementById('foodList').innerHTML = f.map(function(i) {
        var specialtyTag = i.specialty ? '<span class="food-specialty-tag">' + i.specialty + '</span>' : '';
        return '<div class="food-item" data-food="' + i.name + '">' +
            '<div class="food-icon">' + i.icon + '</div>' +
            '<div class="food-info-wrap">' +
                '<div class="food-name">' + i.name + specialtyTag + '</div>' +
                '<div class="food-desc">' + i.desc + '</div>' +
            '</div>' +
            '<div class="food-bottom">' +
                '<div class="food-price">\u00a5' + i.price + '/\u4eba</div>' +
                '<button class="food-map-btn" onclick="showFoodOnMap(\'' + i.name.replace(/'/g, "\\'") + '\', ' +
                "'" + (destCity || '') + "'" + ', ' +
                "'" + (destLng || '') + "'" + ', ' +
                "'" + (destLat || '') + "'" +
                ')" title="\u5728\u5730\u56fe\u4e0a\u67e5\u770b\u9644\u8fd1\u5e97\u94fa">\u{1f4cd} \u9644\u8fd1\u5e97\u94fa</button>' +
            '</div>' +
        '</div>';
    }).join('');
    document.getElementById('foodSection').style.display = 'block';

    // 搜索并渲染推荐餐厅
    loadRestaurantRecommendations(destCity, destLng, destLat, f);
}

// 搜索推荐餐厅
function loadRestaurantRecommendations(city, lng, lat, localFoods) {
    if (!lng || !lat || !city) return;

    var restContainer = document.getElementById('restaurantList');
    if (!restContainer) return;
    restContainer.innerHTML = '<div class="restaurant-loading">\u{1f50d} \u6b63\u5728\u641c\u7d22' + city + '\u70ed\u95e8\u9910\u5385...</div>';
    restContainer.style.display = 'block';

    var foodNames = localFoods.map(function(f) { return f.name; });
    var promises = foodNames.map(function(name) {
        return searchNearbyFood(name, city, lng, lat);
    });

    Promise.all(promises).then(function(allResults) {
        var poisMap = {};
        allResults.forEach(function(results) {
            results.forEach(function(p) {
                if (!poisMap[p.name]) poisMap[p.name] = p;
            });
        });
        var allPois = Object.values(poisMap);

        allPois.sort(function(a, b) {
            var sA = a.rating ? parseFloat(a.rating) : 0;
            var sB = b.rating ? parseFloat(b.rating) : 0;
            if (sA > 0 && sB > 0) return sB - sA;
            if (sA > 0) return -1;
            if (sB > 0) return 1;
            return a.dist - b.dist;
        });
        var topRestaurants = allPois.slice(0, 8);

        topRestaurants.forEach(function(shop) {
            shop.matchedFoods = [];
            localFoods.forEach(function(food) {
                if (shop.name.indexOf(food.name) >= 0 ||
                    (food.specialty && shop.name.indexOf(food.specialty) >= 0) ||
                    (food.specialty && shop.type && shop.type.indexOf(food.specialty) >= 0)) {
                    shop.matchedFoods.push({ name: food.name, icon: food.icon, specialty: food.specialty });
                }
            });
        });

        renderRestaurants(topRestaurants, city, lng, lat);
    });
}

// 渲染推荐餐厅卡片
function renderRestaurants(restaurants, city, lng, lat) {
    var container = document.getElementById('restaurantList');
    if (!container) return;

    if (restaurants.length === 0) {
        container.innerHTML = '<div class="restaurant-empty">\u{1f614} 暂未找到推荐餐厅</div>';
        return;
    }

    container.innerHTML = restaurants.map(function(r, idx) {
        var ratingStr = r.rating ? '<span class="rest-rating">' + r.rating + ' \u2605</span>' : '';
        var costStr = r.cost ? '<span class="rest-cost">\u00a5' + r.cost + '/\u4eba</span>' : '';
        var distStr = r.dist > 1000 ? (r.dist / 1000).toFixed(1) + 'km' : r.dist + 'm';

        // 特色美食标签
        var foodsHTML = '';
        if (r.matchedFoods && r.matchedFoods.length > 0) {
            foodsHTML = '<div class="rest-foods">' +
                r.matchedFoods.slice(0, 4).map(function(f) {
                    return '<span class="rest-food-tag">' + f.icon + ' ' + f.name + '</span>';
                }).join('') +
            '</div>';
        }

        return '<div class="rest-card" onclick="showFoodOnMap(\'' + r.name.replace(/'/g, "\\'") + '\', ' +
            "'" + city + "'" + ', ' +
            "'" + lng + "'" + ', ' +
            "'" + lat + "'" +
            ')">' +
            '<div class="rest-card-header">' +
                '<div class="rest-card-num">' + (idx + 1) + '</div>' +
                '<div class="rest-card-info">' +
                    '<div class="rest-card-name">' + r.name + '</div>' +
                    '<div class="rest-card-addr">' + (r.address || '') + '</div>' +
                '</div>' +
                '<button class="rest-nav-btn" onclick="event.stopPropagation();navigateToShop(' +
                    r.lng + ',' + r.lat + ',\'' + r.name.replace(/'/g, "\\'") + '\')" title="\u5bfc\u822a\u5230\u8fd9\u91cc">\u{1f697}</button>' +
            '</div>' +
            foodsHTML +
            '<div class="rest-card-footer">' +
                ratingStr + costStr +
                '<span class="rest-dist">' + distStr + '</span>' +
            '</div>' +
        '</div>';
    }).join('');
}

// 在地图上展示附近美食店铺
function showFoodOnMap(foodName, city, lng, lat) {
    if (!lng || !lat) { alert('\u8bf7\u5148\u9009\u62e9\u76ee\u7684\u5730'); return; }
    
    foodMapDestLng = lng;
    foodMapDestLat = lat;

    if (!foodMapOverlay) {
        foodMapOverlay = document.createElement('div');
        foodMapOverlay.id = 'foodMapOverlay';
        foodMapOverlay.className = 'food-map-overlay';
        foodMapOverlay.innerHTML =
            '<div class="food-map-panel">' +
                '<div class="food-map-header">' +
                    '<div class="food-map-title" id="foodMapTitle"></div>' +
                    '<button class="food-map-close" onclick="closeFoodMap()">\u00d7</button>' +
                '</div>' +
                '<div class="food-map-body">' +
                    '<div class="food-map-container" id="foodMapContainer"></div>' +
                    '<div class="food-shop-list" id="foodShopList"></div>' +
                '</div>' +
            '</div>';
        document.body.appendChild(foodMapOverlay);
    }

    document.getElementById('foodMapTitle').innerHTML = '\u{1f4cd} \u201c' + foodName + '\u201d \u9644\u8fd1\u5e97\u94fa';
    foodMapOverlay.style.display = 'flex';
    document.getElementById('foodShopList').innerHTML = '<div class="food-shop-loading">\u{1f50d} \u6b63\u5728\u641c\u7d22\u9644\u8fd1\u5e97\u94fa...</div>';

    setTimeout(function() {
        if (!foodMapInstance) {
            foodMapInstance = new AMap.Map('foodMapContainer', {
                zoom: 14,
                center: [parseFloat(lng), parseFloat(lat)],
                mapStyle: 'amap://styles/whitesmoke'
            });
        } else {
            foodMapInstance.setZoomAndCenter(14, [parseFloat(lng), parseFloat(lat)]);
            foodMapInstance.resize();
        }

        if (foodMapInfoWindow) { foodMapInfoWindow.close(); foodMapInfoWindow = null; }
        foodMapMarkers.forEach(function(m) { foodMapInstance.remove(m); });
        foodMapMarkers = [];

        var centerMarker = new AMap.Marker({
            position: [parseFloat(lng), parseFloat(lat)],
            icon: new AMap.Icon({ size: new AMap.Size(24, 24), image: 'https://webapi.amap.com/theme/v1.3/markers/n/loc.png', imageSize: new AMap.Size(24, 24) }),
            title: city,
            zIndex: 100
        });
        foodMapInstance.add(centerMarker);
        foodMapMarkers.push(centerMarker);

        // 搜索该城市所有特色美食关键词
        var destData = getDestinationData(city);
        var destFoods = destData.foods || [];
        var searchPromises = [searchNearbyFood(foodName, city, lng, lat)];
        destFoods.forEach(function(df) {
            if (df.specialty && df.name !== foodName && df.name.indexOf(foodName) < 0) {
                searchPromises.push(searchNearbyFood(df.specialty, city, lng, lat));
            }
        });
        Promise.all(searchPromises).then(function(allResults) {
            var poisMap = {};
            allResults.forEach(function(results) {
                results.forEach(function(poi) {
                    if (!poisMap[poi.name]) poisMap[poi.name] = poi;
                });
            });
            var pois = Object.values(poisMap);
            var shopHTML = '';
            if (pois.length === 0) {
                shopHTML = '<div class="food-shop-empty">\u{1f614} \u672a\u627e\u5230\u76f8\u5173\u5e97\u94fa\uff0c\u8bd5\u8bd5\u66f4\u6362\u5173\u952e\u8bcd</div>';
            } else {
                pois.forEach(function(poi, idx) {
                    poi.matchedSpecialties = [];
                    destFoods.forEach(function(df) {
                        if (poi.name.indexOf(df.name) >= 0 || (df.specialty && poi.name.indexOf(df.specialty) >= 0)) {
                            if (poi.matchedSpecialties.indexOf(df.name) < 0) poi.matchedSpecialties.push(df.name);
                        }
                    });
                    var markerContent = '<div class="food-poi-marker"><span class="food-poi-num">' + (idx + 1) + '</span></div>';
                    var marker = new AMap.Marker({
                        position: [poi.lng, poi.lat],
                        content: markerContent,
                        offset: new AMap.Pixel(-15, -15),
                        zIndex: 50
                    });
                    foodMapInstance.add(marker);
                    foodMapMarkers.push(marker);
                    marker.on('click', function() { openFoodShopInfo(poi, idx); });

                    var distStr = poi.dist > 1000 ? (poi.dist / 1000).toFixed(1) + 'km' : poi.dist + 'm';
                    var ratingStr = poi.rating ? '<span class="shop-rating">' + poi.rating + '\u2605</span>' : '';
                    var costStr = poi.cost ? '<span class="shop-cost">\u00a5' + poi.cost + '/\u4eba</span>' : '';
                    var specialtyHTML = '';
                    if (poi.matchedSpecialties && poi.matchedSpecialties.length > 0) {
                        specialtyHTML = '<div class="shop-specialties">' +
                            poi.matchedSpecialties.map(function(s) { return '<span class="shop-specialty-tag">' + s + '</span>'; }).join('') +
                        '</div>';
                    }
                    shopHTML += '<div class="food-shop-item" data-idx="' + idx + '" onclick="focusFoodShop(' + idx + ')">' +
                        '<div class="shop-num">' + (idx + 1) + '</div>' +
                        '<div class="shop-info">' +
                            '<div class="shop-name">' + poi.name + '</div>' +
                            '<div class="shop-address">' + poi.address + '</div>' +
                            specialtyHTML +
                            '<div class="shop-meta">' + ratingStr + costStr + '<span class="shop-dist">' + distStr + '</span></div>' +
                        '</div>' +
                        '<button class="shop-nav-btn" onclick="event.stopPropagation();navigateToShop(' + poi.lng + ',' + poi.lat + ',\'' + poi.name.replace(/'/g, "\\'") + '\')" title="\u5bfc\u822a">\u{1fa9}\ufe0f</button>' +
                    '</div>';
                });
                foodMapInstance.setFitView(foodMapMarkers, false, [60, 60, 60, 60]);
            }
            document.getElementById('foodShopList').innerHTML = shopHTML;
            window._foodShopPois = pois;
        });
    }, 150);
}

function focusFoodShop(idx) {
    var pois = window._foodShopPois || [];
    if (pois[idx] && foodMapInstance) {
        foodMapInstance.setZoomAndCenter(16, [pois[idx].lng, pois[idx].lat]);
        openFoodShopInfo(pois[idx], idx);
    }
}

function openFoodShopInfo(poi, idx) {
    if (!foodMapInstance) return;
    var distStr = poi.dist > 1000 ? (poi.dist / 1000).toFixed(1) + 'km' : poi.dist + 'm';
    var ratingStr = poi.rating ? '\u8bc4\u5206 ' + poi.rating + ' \u2605' : '';
    var costStr = poi.cost ? '\u4eba\u5747 \u00a5' + poi.cost : '';
    var telStr = poi.tel ? '<br>\u7535\u8bdd: ' + poi.tel : '';
    var navLink = '<button onclick="navigateToShop(' + poi.lng + ',' + poi.lat + ',\'' + poi.name.replace(/'/g, "\\'") + '\')" style="background:#6366f1;color:#fff;border:none;padding:5px 14px;border-radius:6px;font-size:12px;cursor:pointer;">\u{1f697} \u7acb\u5373\u5bfc\u822a</button>';
    var content = '<div style="padding:8px;min-width:200px;">' +
        '<div style="font-weight:600;font-size:14px;margin-bottom:4px;">' + poi.name + '</div>' +
        '<div style="font-size:12px;color:#666;margin-bottom:4px;">' + poi.address + '</div>' +
        '<div style="font-size:12px;">' + ratingStr + (costStr ? ' | ' + costStr : '') + ' | ' + distStr + telStr + '</div>' +
        '<div style="margin-top:8px;">' + navLink + '</div>' +
    '</div>';
    if (foodMapInfoWindow) foodMapInfoWindow.close();
    foodMapInfoWindow = new AMap.InfoWindow({ content: content, offset: new AMap.Pixel(0, -20) });
    foodMapInfoWindow.open(foodMapInstance, [poi.lng, poi.lat]);
}

function navigateToShop(lng, lat, name) {
    if (!foodMapInstance) return;
    clearFoodNavRoute();

    var startLng = foodMapDestLng || foodMapInstance.getCenter().lng;
    var startLat = foodMapDestLat || foodMapInstance.getCenter().lat;

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(pos) {
            startLng = pos.coords.longitude;
            startLat = pos.coords.latitude;
            drawFoodNavRoute(startLng, startLat, lng, lat, name);
        }, function() {
            drawFoodNavRoute(startLng, startLat, lng, lat, name);
        }, { timeout: 3000 });
    } else {
        drawFoodNavRoute(startLng, startLat, lng, lat, name);
    }
}

function drawFoodNavRoute(startLng, startLat, endLng, endLat, name) {
    if (!foodMapInstance) return;
    try {
        AMap.plugin('AMap.Driving', function() {
            var driving = new AMap.Driving({
                policy: AMap.DrivingPolicy.LEAST_TIME,
                panel: false,
                hideMarkers: true
            });
            driving.search(
                new AMap.LngLat(startLng, startLat),
                new AMap.LngLat(endLng, endLat),
                function(status, result) {
                    if (status === 'complete' && result.routes && result.routes.length > 0) {
                        var route = result.routes[0];
                        var path = [];
                        route.steps.forEach(function(step) { path = path.concat(step.path); });

                        foodNavRouteLine = new AMap.Polyline({
                            path: path,
                            strokeColor: '#6366f1',
                            strokeWeight: 5,
                            strokeOpacity: 0.85,
                            showDir: true,
                            lineJoin: 'round'
                        });
                        foodMapInstance.add(foodNavRouteLine);

                        var startMarker = new AMap.Marker({
                            position: [startLng, startLat],
                            content: '<div style="width:10px;height:10px;background:#10b981;border:2px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,0.3);"></div>',
                            offset: new AMap.Pixel(-5, -5),
                            zIndex: 60,
                            title: '起点'
                        });
                        foodMapInstance.add(startMarker);
                        foodNavRouteMarkers.push(startMarker);

                        var endMarker = new AMap.Marker({
                            position: [endLng, endLat],
                            content: '<div style="padding:3px 8px;background:#ef4444;color:#fff;font-size:11px;border-radius:4px;font-weight:600;white-space:nowrap;">' + name + '</div>',
                            offset: new AMap.Pixel(0, -20),
                            zIndex: 61
                        });
                        foodMapInstance.add(endMarker);
                        foodNavRouteMarkers.push(endMarker);

                        foodMapInstance.setFitView([foodNavRouteLine, startMarker, endMarker], false, [80, 80, 80, 80]);

                        var timeMin = Math.round(route.time / 60);
                        var distKm = (route.distance / 1000).toFixed(1);
                        var info = document.createElement('div');
                        info.id = 'foodNavInfo';
                        info.className = 'food-nav-info';
                        info.innerHTML = '<span>\u{1f697} \u7ea6' + timeMin + '\u5206\u949f</span><span>' + distKm + 'km</span><button onclick="clearFoodNavRoute()">\u5173\u95ed\u8def\u7ebf</button>';
                        var container = document.getElementById('foodMapContainer');
                        var oldInfo = document.getElementById('foodNavInfo');
                        if (oldInfo) oldInfo.remove();
                        container.appendChild(info);
                        setTimeout(function() { info.style.opacity = '1'; }, 50);
                    } else {
                        alert('\u8def\u7ebf\u89c4\u5212\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5');
                    }
                }
            );
        });
    } catch (e) {
        console.error('\u5bfc\u822a\u8def\u7ebf\u7ed8\u5236\u5931\u8d25:', e);
    }
}

function clearFoodNavRoute() {
    if (foodNavRouteLine) { foodMapInstance.remove(foodNavRouteLine); foodNavRouteLine = null; }
    foodNavRouteMarkers.forEach(function(m) { foodMapInstance.remove(m); });
    foodNavRouteMarkers = [];
    var info = document.getElementById('foodNavInfo');
    if (info) info.remove();
}

function closeFoodMap() {
    if (foodMapOverlay) foodMapOverlay.style.display = 'none';
    if (foodMapInfoWindow) { foodMapInfoWindow.close(); foodMapInfoWindow = null; }
    clearFoodNavRoute();
    foodMapDestLng = null;
    foodMapDestLat = null;
}

function renderItinerary(it) {
    // 存储行程数据供编辑使用
    var itineraryData = JSON.parse(JSON.stringify(it));
    var itinerarySection = document.getElementById('itinerarySection');
    var itineraryList = document.getElementById('itineraryList');
    if (!itinerarySection || !itineraryList) return;

    var isEditing = false;
    var pace = (document.querySelector('input[name="pace"]:checked') || {}).value || 'compact';
    var paceLabel = { compact: '', comfort: '⏳ 舒适', relax: '🧘 躺平' };
    var paceHtml = pace !== 'compact' ? '<span class="day-pace-badge">' + paceLabel[pace] + '</span>' : '';

    function renderViewMode() {
        itineraryList.innerHTML = itineraryData.map(function(d) {
            return '<div class="itinerary-day">' +
                '<div class="day-header">第 ' + d.day + ' 天 · ' + d.date + paceHtml + '</div>' +
                '<div class="day-content">' +
                    '<div class="day-schedule">' +
                        d.schedule.map(function(s, idx) {
                            var transitHtml = '';
                            if (idx > 0 && d.schedule[idx - 1]) {
                                var prevTitle = d.schedule[idx - 1].title;
                                transitHtml = '<div class="schedule-transit">' +
                                    '<span class="transit-icon">🚗</span>' +
                                    '<span class="transit-text">从「' + prevTitle + '」前往「' + s.title + '」— 建议预留30-60分钟</span>' +
                                    '<a href="https://ditu.amap.com/dir?from=' + encodeURIComponent(prevTitle) + '&to=' + encodeURIComponent(s.title) + '" target="_blank" class="transit-link">查看路线</a>' +
                                '</div>';
                            }
                            return transitHtml +
                                '<div class="schedule-item">' +
                                    '<div class="schedule-time">' + s.time.split('-')[0] + '</div>' +
                                    '<div class="schedule-content">' +
                                        '<div class="schedule-title">' + s.title + '</div>' +
                                        '<div class="schedule-desc">' + s.desc + '</div>' +
                                    '</div>' +
                                '</div>';
                        }).join('') +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    function renderEditMode() {
        itineraryList.innerHTML = '<div class="itinerary-edit-toolbar">' +
            '<button class="itinerary-edit-btn add-day-btn" onclick="window._itineraryAddDay()">+ 添加一天</button>' +
            '<span class="itinerary-edit-hint">拖拽调整顺序功能开发中，请使用按钮操作</span>' +
        '</div>' +
        itineraryData.map(function(d, dayIdx) {
            return '<div class="itinerary-day editing">' +
                '<div class="day-header">' +
                    '<span>第 ' + d.day + ' 天 · ' + d.date + '</span>' +
                    '<div class="day-header-actions">' +
                        '<button class="itinerary-edit-btn add-item-btn" onclick="window._itineraryAddItem(' + dayIdx + ')">+ 添加活动</button>' +
                        (itineraryData.length > 1 ? '<button class="itinerary-edit-btn delete-day-btn" onclick="window._itineraryDeleteDay(' + dayIdx + ')">🗑 删除此日</button>' : '') +
                    '</div>' +
                '</div>' +
                '<div class="day-content">' +
                    '<div class="day-schedule">' +
                        d.schedule.map(function(s, itemIdx) {
                            return '<div class="schedule-item editing">' +
                                '<div class="schedule-time">' +
                                    '<input type="text" class="schedule-time-input" value="' + s.time.split('-')[0] + '" onchange="window._itineraryUpdateItem(' + dayIdx + ',' + itemIdx + ',this)" data-field="time">' +
                                '</div>' +
                                '<div class="schedule-content">' +
                                    '<input type="text" class="schedule-title-input" value="' + s.title.replace(/"/g, '&quot;') + '" onchange="window._itineraryUpdateItem(' + dayIdx + ',' + itemIdx + ',this)" data-field="title">' +
                                    '<input type="text" class="schedule-desc-input" value="' + s.desc.replace(/"/g, '&quot;') + '" onchange="window._itineraryUpdateItem(' + dayIdx + ',' + itemIdx + ',this)" data-field="desc">' +
                                '</div>' +
                                '<button class="itinerary-edit-btn delete-item-btn" onclick="window._itineraryDeleteItem(' + dayIdx + ',' + itemIdx + ')">✕</button>' +
                            '</div>';
                        }).join('') +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    // 全局编辑函数
    window._itineraryData = itineraryData;
    window._itineraryRefresh = function() {
        renderEditMode();
    };
    window._itineraryAddItem = function(dayIdx) {
        if (dayIdx >= 0 && dayIdx < itineraryData.length) {
            itineraryData[dayIdx].schedule.push({ time: '09:00-10:00', title: '新活动', desc: '活动描述' });
        }
        renderEditMode();
    };
    window._itineraryDeleteItem = function(dayIdx, itemIdx) {
        if (dayIdx >= 0 && dayIdx < itineraryData.length && itineraryData[dayIdx].schedule.length > 1) {
            itineraryData[dayIdx].schedule.splice(itemIdx, 1);
        }
        renderEditMode();
    };
    window._itineraryAddDay = function() {
        var lastDay = itineraryData[itineraryData.length - 1];
        var newDate = new Date(lastDay.date);
        newDate.setDate(newDate.getDate() + 1);
        var dateStr = newDate.toISOString().split('T')[0];
        itineraryData.push({
            day: itineraryData.length + 1,
            date: dateStr,
            schedule: [{ time: '09:00-10:00', title: '新活动', desc: '活动描述' }]
        });
        renderEditMode();
    };
    window._itineraryDeleteDay = function(dayIdx) {
        if (itineraryData.length > 1 && dayIdx >= 0 && dayIdx < itineraryData.length) {
            itineraryData.splice(dayIdx, 1);
            // 重新编号
            itineraryData.forEach(function(d, i) { d.day = i + 1; });
        }
        renderEditMode();
    };
    window._itineraryUpdateItem = function(dayIdx, itemIdx, inputEl) {
        if (dayIdx >= 0 && dayIdx < itineraryData.length && itemIdx >= 0 && itemIdx < itineraryData[dayIdx].schedule.length) {
            var field = inputEl.getAttribute('data-field');
            var item = itineraryData[dayIdx].schedule[itemIdx];
            if (field === 'time') {
                item.time = inputEl.value + '-00:00';
            } else if (field === 'title') {
                item.title = inputEl.value;
            } else if (field === 'desc') {
                item.desc = inputEl.value;
            }
        }
    };

    // 渲染查看模式
    renderViewMode();

    // 添加编辑/保存按钮到 section 标题区
    var existingToggle = document.getElementById('itineraryEditToggle');
    if (existingToggle) existingToggle.remove();

    var toggleBtn = document.createElement('button');
    toggleBtn.id = 'itineraryEditToggle';
    toggleBtn.className = 'itinerary-toggle-btn';
    toggleBtn.textContent = '✏️ 编辑行程';
    toggleBtn.onclick = function() {
        isEditing = !isEditing;
        if (isEditing) {
            toggleBtn.textContent = '💾 保存修改';
            toggleBtn.classList.add('saving');
            renderEditMode();
        } else {
            toggleBtn.textContent = '✏️ 编辑行程';
            toggleBtn.classList.remove('saving');
            renderViewMode();
            // 更新导出按钮可见
            var exportSection = document.getElementById('exportSection');
            if (exportSection) exportSection.style.display = 'block';
        }
    };

    var itineraryHeader = itinerarySection.querySelector('h3');
    if (itineraryHeader && !document.getElementById('itineraryEditToggle')) {
        itineraryHeader.appendChild(toggleBtn);
    }

    itinerarySection.style.display = 'block';
}

function hideWelcomeTip() { document.getElementById('welcomeTip').style.display = 'none'; }

// 表单处理
function clearFieldErrors() {
    document.querySelectorAll('.field-error').forEach(function(el) { el.remove(); });
    document.querySelectorAll('.field-error-border').forEach(function(el) { el.classList.remove('field-error-border'); });
}

function showFieldError(fieldId, message) {
    var el = document.getElementById(fieldId);
    if (!el) {
        var selector = document.querySelector('#' + fieldId);
        if (!selector) return;
        el = selector;
    }
    if (el.classList) {
        el.classList.add('field-error-border');
    }
    var errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    el.parentNode.appendChild(errorDiv);
}


// ========================================
// 用户偏好记忆
// ========================================
var PREF_KEY = 'travel_planner_prefs_v1';

function savePreferences() {
    var prefs = {};
    document.querySelectorAll('input[name="preference"]').forEach(function(cb) {
        prefs[cb.value] = cb.checked;
    });
    prefs.budget = document.getElementById('budget').value;
    prefs.travelDays = document.getElementById('travelDays').value;
    try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch(e) {}
}

function restorePreferences() {
    try {
        var prefs = JSON.parse(localStorage.getItem(PREF_KEY));
        if (!prefs) return;
        document.querySelectorAll('input[name="preference"]').forEach(function(cb) {
            if (prefs[cb.value] !== undefined) cb.checked = prefs[cb.value];
        });
        if (prefs.budget && !document.getElementById('budget').value) {
            document.getElementById('budget').value = prefs.budget;
        }
        if (prefs.travelDays && !document.getElementById('travelDays').value) {
            document.getElementById('travelDays').value = prefs.travelDays;
        }
    } catch(e) {}
}

async function handleFormSubmit(e) {
    e.preventDefault();
    const data = getFormData();
    var errors = [];
    if (!data.departureCity) errors.push({ field: 'departureInput', msg: '请选择出发城市' });
    if (!data.destinationCity) errors.push({ field: 'destinationInput', msg: '请选择目的地' });
    if (!data.travelDate) errors.push({ field: 'travelDate', msg: '请选择出发日期' });
    if (!data.travelDays || data.travelDays < 1) errors.push({ field: 'travelDays', msg: '请输入有效的旅行天数' });
    if (!data.budget || data.budget < 100) errors.push({ field: 'budget', msg: '请输入有效的预算（最低100元）' });
    clearFieldErrors();
    if (errors.length > 0) {
        errors.forEach(function(err) {
            showFieldError(err.field, err.msg);
        });
        return;
    }
    hideWelcomeTip();

    // 0. 获取并渲染天气（异步，不阻塞其他渲染）
    (function() {
        const weatherSection = document.getElementById('weatherSection');
        const weatherContent = document.getElementById('weatherContent');
        weatherSection.style.display = 'none';
        weatherContent.innerHTML = `
            <div class="weather-loading">
                <div class="loading-icon">🌤️</div>
                <div>正在获取${data.destinationCity}的天气数据...</div>
            </div>
        `;
        weatherSection.style.display = 'block';

        fetchWeather(data.destinationCity, data.destinationLng, data.destinationLat, data.travelDays)
            .then(weatherData => { window._lastWeatherData = weatherData; renderWeather(weatherData, data.travelDays, data.destinationCity);
            })
            .catch(err => {
                console.error('获取天气失败:', err);
                weatherContent.innerHTML = `
                    <div class="weather-error">
                        <div class="error-icon">😔</div>
                        <div class="error-text">获取天气数据失败</div><button class="retry-btn" onclick="location.reload()">↻ 重试</button>
                    </div>
                `;
            });
    })();

    // 1. 交通建议（高德驾车 + 火车真实班次 + 飞机预估）
    let drivingResult = null;
    let distKm = 0;
    let trainRoutes = [];
    if (data.departureLng && data.departureLat && data.destinationLng && data.destinationLat) {
        try {
            // 并行请求驾车路线和火车班次
            const [driveData, trainData] = await Promise.allSettled([
                getDrivingRoute(data.departureLng, data.departureLat, data.destinationLng, data.destinationLat),
                getTrainRoutes(data.departureCity, data.destinationCity, data.departureLng, data.departureLat, data.destinationLng, data.destinationLat)
            ]);
            if (driveData.status === 'fulfilled') {
                drivingResult = driveData.value;
                distKm = Math.round(drivingResult.distance / 1000);
            }
            if (trainData.status === 'fulfilled') {
                trainRoutes = trainData.value;
            }
        } catch (err) {
            console.error('路线规划失败:', err);
        }
        // 兜底：直线距离估算
        if (distKm === 0) {
            const oLng = parseFloat(data.departureLng), oLat = parseFloat(data.departureLat);
            const dLng = parseFloat(data.destinationLng), dLat = parseFloat(data.destinationLat);
            distKm = Math.round(Math.sqrt(Math.pow((dLng - oLng) * 111 * Math.cos((oLat + dLat) / 2 * Math.PI / 180), 2) + Math.pow((dLat - oLat) * 111, 2)));
        }
    }
    if (distKm > 0) {
        // 存储路线坐标和城市名，供地图路线绘制使用
        window._routeStartLng = parseFloat(data.departureLng);
        window._routeStartLat = parseFloat(data.departureLat);
        window._routeEndLng = parseFloat(data.destinationLng);
        window._routeEndLat = parseFloat(data.destinationLat);
        window._routeDepCity = data.departureCity;
        window._routeDestCity = data.destinationCity;
        const transportPlans = calculateTransportPlans(drivingResult, distKm, trainRoutes, data.departureCity, data.destinationCity, data.departureLng, data.departureLat, data.destinationLng, data.destinationLat);
        renderTransportNew(transportPlans);
        window._lastTransportData = { plans: transportPlans, departureCity: data.departureCity, destinationCity: data.destinationCity };
    }

    // 2-5. 预算、景点、美食、行程
    // 获取推荐交通方案的费用，用于预算分配
    var recommendTransportCost = null;
    if (window._lastTransportData && window._lastTransportData.plans && window._lastTransportData.plans.length > 0) {
        var recommendPlan = window._lastTransportData.plans.find(function(p) { return p.recommend; }) || window._lastTransportData.plans[0];
        recommendTransportCost = recommendPlan.cost;
    }
    const di = getDestinationData(data.destinationCity);

    // 酒店住宿推荐（先生成，供预算计算使用真实价格）
    const hotelRecommendations = generateHotelRecommendations(data.destinationCity, data.budget, data.travelDays);
    renderHotels(hotelRecommendations);
    window._lastHotelsData = hotelRecommendations;

    // 预算（传入真实酒店数据）
    renderBudgetChart(calculateBudgetAllocation(data.budget, data.travelDays, data.destinationCity, recommendTransportCost, hotelRecommendations), data.budget);
    renderFoods(di.foods.slice(0, 5), data.destinationCity, data.destinationLng, data.destinationLat);

    renderItinerary(generateItinerary(di, data.travelDays, data.pace));

    // 折叠左侧表单为摘要
    collapseFormToSummary(data);

    // 重置卡片折叠状态：只展开行程和预算
    resetCollapsibleCards();

    // 移动端：自动切换到行程标签
    if (window.matchMedia('(max-width: 640px)').matches && window._switchMobileTab) {
        window._switchMobileTab('itinerarySection');
    }

    // 使用高德地图获取真实景点数据
    if (data.destinationLng && data.destinationLat) {
        searchAttractionsByAmap(data.destinationCity, data.destinationLng, data.destinationLat).then(function(realAttractions) {
            if (realAttractions && realAttractions.length > 0) {
                window._lastAttractionsData = realAttractions;
                renderAttractions(realAttractions);
                // 用真实景点数据更新预算门票小计
                updateBudgetTickets(realAttractions, data.budget, data.travelDays, data.destinationCity, recommendTransportCost, hotelRecommendations);
            } else {
                renderAttractions(filterAttractions(di.attractions, data.preferences));
            }
        }).catch(function() {
            renderAttractions(filterAttractions(di.attractions, data.preferences));
        });
    } else {
        renderAttractions(filterAttractions(di.attractions, data.preferences));
    }

    // 保存到历史记录
    // 延迟保存，等待异步内容（天气、地图等）渲染完成
    setTimeout(function() { savePlanToHistory(data);
            savePreferences(); }, 3000);

    var rs = document.getElementById('resultSection');
    // 滚动右侧到天气/结果区域（跳过地图）
    var ws = document.getElementById('weatherSection');
    if (ws && ws.style.display !== 'none') { ws.scrollIntoView({behavior: 'smooth', block: 'start'}); }
    else if (rs) { rs.scrollTop = 500; }
}

// 初始化
var departureSelector, destinationSelector;
function setMinDate() { var d = document.getElementById('travelDate'); d.min = new Date().toISOString().split('T')[0]; d.value = d.min; }
function initApp() { setMinDate(); restorePreferences(); initTheme(); departureSelector = new CitySelector('departure'); destinationSelector = new CitySelector('destination'); document.getElementById('travelForm').addEventListener('submit', handleFormSubmit); initMapPicker(); locateUser(); initImageLazyLoad(); cleanupLocalStorage(); checkReturnFromDetail(); initPhosphorIcons(); initVoiceInput(); initPaceSelector(); initCollapsibleCards(); initMobileTabs(); checkLLMAvailability(); }

function checkLLMAvailability() {
    fetch('/api/health').then(function(r) { return r.json(); }).then(function(d) {
        if (!d.llm || d.llm === 'not configured') {
            llmAvailable = false;
            var reviewSection = document.getElementById('reviewSection');
            if (reviewSection) reviewSection.style.display = 'none';
        } else {
            llmAvailable = true;
        }
    }).catch(function() {
        llmAvailable = false;
        var reviewSection = document.getElementById('reviewSection');
        if (reviewSection) reviewSection.style.display = 'none';
    });
}

function initPaceSelector() {
    var paceOptions = document.getElementById('paceOptions');
    if (!paceOptions) return;
    paceOptions.addEventListener('click', function(e) {
        var label = e.target.closest('.pace-label');
        if (!label) return;
        var radio = label.querySelector('input[type="radio"]');
        if (!radio) return;
        radio.checked = true;
        document.querySelectorAll('.pace-label').forEach(function(l) { l.classList.remove('active'); });
        label.classList.add('active');
    });
}

var COLLAPSIBLE_DEFAULTS = {
    'itinerarySection': true,
    'budgetSection': true,
    'weatherSection': false,
    'transportSection': false,
    'attractionsSection': false,
    'foodSection': false,
    'hotelSection': false,
    'expenseSection': false,
    'reviewSection': false,
    'packingSection': false,
    'exportSection': false
};

var cardCollapsedState = {};

function initCollapsibleCards() {
    var cardIds = Object.keys(COLLAPSIBLE_DEFAULTS);

    cardIds.forEach(function(id) {
        var card = document.getElementById(id);
        if (!card) return;

        card.classList.add('collapsible');

        var h3 = card.querySelector('h3');
        if (!h3) return;

        var toggleIcon = document.createElement('span');
        toggleIcon.className = 'card-toggle-icon';
        toggleIcon.textContent = '▼';
        h3.appendChild(toggleIcon);

        var body = document.createElement('div');
        body.className = 'collapsible-body';
        var nextEl = h3.nextElementSibling;
        while (nextEl) {
            var toMove = nextEl;
            nextEl = nextEl.nextElementSibling;
            body.appendChild(toMove);
        }
        card.appendChild(body);

        var shouldExpand = COLLAPSIBLE_DEFAULTS[id] !== false;
        cardCollapsedState[id] = !shouldExpand;

        if (!shouldExpand) {
            body.classList.add('collapsed');
            body.style.maxHeight = '0px';
            toggleIcon.classList.add('collapsed');
        }

        h3.addEventListener('click', function() {
            toggleCardCollapse(id);
        });
    });
}

function toggleCardCollapse(id) {
    var card = document.getElementById(id);
    if (!card) return;

    var body = card.querySelector('.collapsible-body');
    var icon = card.querySelector('.card-toggle-icon');
    if (!body || !icon) return;

    var isCollapsed = body.classList.contains('collapsed');

    if (isCollapsed) {
        body.classList.remove('collapsed');
        body.style.overflow = 'hidden';
        body.style.maxHeight = body.scrollHeight + 'px';
        setTimeout(function() { body.style.maxHeight = 'none'; body.style.overflow = ''; }, 350);
        icon.classList.remove('collapsed');
        cardCollapsedState[id] = false;
    } else {
        body.style.overflow = 'hidden';
        body.style.maxHeight = body.scrollHeight + 'px';
        body.offsetHeight;
        body.classList.add('collapsed');
        body.style.maxHeight = '0px';
        icon.classList.add('collapsed');
        cardCollapsedState[id] = true;
    }
}

function applyCardState(id, collapsed) {
    var card = document.getElementById(id);
    if (!card) return;
    var body = card.querySelector('.collapsible-body');
    var icon = card.querySelector('.card-toggle-icon');
    if (!body || !icon) return;

    if (collapsed) {
        if (!body.classList.contains('collapsed')) {
            body.style.overflow = 'hidden';
            body.style.maxHeight = body.scrollHeight + 'px';
            body.offsetHeight;
            body.classList.add('collapsed');
            body.style.maxHeight = '0px';
            icon.classList.add('collapsed');
            cardCollapsedState[id] = true;
        }
    } else {
        if (body.classList.contains('collapsed')) {
            body.classList.remove('collapsed');
            body.style.overflow = 'hidden';
            body.style.maxHeight = body.scrollHeight + 'px';
            setTimeout(function() { body.style.maxHeight = 'none'; body.style.overflow = ''; }, 350);
            icon.classList.remove('collapsed');
            cardCollapsedState[id] = false;
        }
    }
}

function resetCollapsibleCards() {
    // 先全部折叠
    Object.keys(COLLAPSIBLE_DEFAULTS).forEach(function(id) {
        applyCardState(id, true);
    });
    // 展开行程和预算
    ['itinerarySection', 'budgetSection'].forEach(function(id) {
        applyCardState(id, false);
    });
}

function initMobileTabs() {
    var tabs = document.querySelectorAll('.mobile-tab');
    if (tabs.length === 0) return;

    // 初始隐藏所有非地图/欢迎卡片
    document.querySelectorAll('.result-card').forEach(function(card) {
        var id = card.id;
        if (!id) return;
        if (id === 'mapPickerCard' || id === 'welcomeTip') return;
        if (id === 'itinerarySection') return;
        card.classList.add('mobile-hidden');
    });

    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            tabs.forEach(function(t) { t.classList.remove('active'); });
            tab.classList.add('active');

            var targetId = tab.dataset.tab;
            document.querySelectorAll('.result-card').forEach(function(card) {
                var id = card.id;
                if (!id) return;
                if (id === 'mapPickerCard' || id === 'welcomeTip') return;
                if (id === targetId) {
                    card.classList.remove('mobile-hidden');
                    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else {
                    card.classList.add('mobile-hidden');
                }
            });
        });
    });

    window._switchMobileTab = function(tabId) {
        var targetTab = document.querySelector('.mobile-tab[data-tab="' + tabId + '"]');
        if (targetTab) { targetTab.click(); }
    };
}

function initTheme() {
    var theme = localStorage.getItem('travel_planner_theme');
    if (!theme) {
        theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    applyTheme(theme);
    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        if (!localStorage.getItem('travel_planner_theme')) {
            applyTheme(e.matches ? 'dark' : 'light');
        }
    });
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('travel_planner_theme', theme);
    var toggle = document.getElementById('themeToggle');
    if (toggle) {
        toggle.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
}

function toggleTheme() {
    var current = document.documentElement.getAttribute('data-theme');
    applyTheme(current === 'dark' ? 'light' : 'dark');
}

function initPhosphorIcons() {
    if (window.PhosphorIcons) {
        PhosphorIcons.render();
    }
}
// plannerView 存在时由 goToPlanner 负责初始化，否则独立使用时自动初始化
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('plannerView')) return;
    initApp();
});


// ========================================
// 交通方案计算和渲染（新版本）
// ========================================

function formatHours(hours) {
    let totalMin = Math.round(hours * 60);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (h === 0) return m + '分钟';
    if (m === 0) return h + '小时';
    return h + '小时' + m + '分钟';
}

function calculateTransportPlans(drivingResult, distKm, trainRoutes, depCity, destCity, depLng, depLat, destLng, destLat) {
    const plans = [];

    // 方案1：飞机（仅当出发地和目的地都有机场时显示）
    if (depCity && destCity && hasAirport(depCity) && hasAirport(destCity)) {
        const depAirports = getAirportInfo(depCity);
        const destAirports = getAirportInfo(destCity);
        const depAirportStr = depAirports ? depAirports.map(a => a.name).join('/') : '';
        const destAirportStr = destAirports ? destAirports.map(a => a.name).join('/') : '';
        const flightTime = distKm * 1.3 / 800;
        const flightTotalTime = 2 + flightTime + 1;
        plans.push({
            id: 'flight', icon: '✈️', name: '飞机', type: 'flight',
            totalTime: flightTotalTime,
            totalTimeStr: formatHours(flightTotalTime),
            cost: Math.round(distKm * 1.2),
            distance: Math.round(distKm * 1.3),
            comfort: 90,
            isEstimate: true,
            depAirports: depAirportStr,
            destAirports: destAirportStr,
        steps: [
            { title: '前往机场', desc: '乘坐地铁/打车前往出发城市机场', duration: '约1-1.5小时' },
            { title: '值机安检', desc: '办理登机牌、过安检、候机', duration: '约1-1.5小时' },
            { title: '飞行', desc: '空中飞行，航程约' + Math.round(distKm * 1.3) + '公里', duration: '约' + Math.round(flightTime * 60) + '分钟' },
            { title: '到达取行李', desc: '下机、提取行李、出机场', duration: '约30-45分钟' },
            { title: '前往目的地', desc: '乘坐机场大巴/地铁/打车前往目的地', duration: '约30-60分钟' }
        ],
        tips: [
            '提前2小时到达机场，预留值机安检时间',
            '行李较多建议选择托运，轻装出行可带登机箱',
            '关注航空公司APP，可提前选座和办理值机',
            '到达后可选择机场大巴或地铁，性价比更高',
            '出发机场：' + (depAirportStr || depCity) + '，到达机场：' + (destAirportStr || destCity),
            '💡 票价为预估参考价，实际价格请以购票平台为准'
        ]
    });
    }

    // 方案2-3：真实火车班次（从高德Transfer获取）
    if (trainRoutes && trainRoutes.length > 0) {
        trainRoutes.forEach((train, idx) => {
            const trainHours = train.duration / 3600;
            const isG = train.type.includes('G');
            const isD = train.type.includes('D');
            const isZ = train.type.includes('Z');
            const isK = train.type.includes('K');
            const trainLabel = isG ? '高铁' : (isD ? '动车' : (isZ ? '直达特快' : (isK ? '快速' : '火车')));
            const comfort = isG ? 88 : (isD ? 82 : (isZ ? 65 : (isK ? 50 : 55)));
            const icon = isG ? '🚄' : (isD ? '🚅' : '🚂');

            // 格式化时间
            const depStr = train.depTime ? train.depTime.substring(0,2) + ':' + train.depTime.substring(2) : '';
            const arrStr = train.arrTime ? train.arrTime.substring(0,2) + ':' + train.arrTime.substring(2) : '';
            const isNextDay = train.duration > 86400; // 超过24小时算次日到达

            plans.push({
                id: 'train_' + idx, icon: icon, name: trainLabel, type: 'train',
                trainName: train.name,
                trainType: train.type,
                depStation: train.depStation,
                arrStation: train.arrStation,
                depTime: depStr,
                arrTime: arrStr,
                isNextDay: isNextDay,
                totalTime: trainHours,
                totalTimeStr: formatHours(trainHours),
                cost: train.cost,
                priceLabel: train.priceLabel,
                allSpaces: train.allSpaces,
                distance: distKm,
                comfort: comfort,
                isEstimate: false,
                steps: [
                    { title: '前往车站', desc: '乘坐地铁/打车前往' + train.depStation, duration: '约30-60分钟' },
                    { title: train.name, desc: train.depStation + ' → ' + train.arrStation + (isNextDay ? '（次日到达）' : ''), duration: depStr + ' - ' + arrStr + '，约' + formatHours(trainHours) },
                    { title: '到达出站', desc: '到达' + train.arrStation + '，出站', duration: '约10-15分钟' },
                    { title: '前往目的地', desc: '乘坐地铁/公交/打车前往目的地', duration: '约20-40分钟' }
                ],
                tips: [
                    '车次：' + train.name + '（' + train.type + '）',
                    '出发：' + train.depStation + ' ' + depStr + (isNextDay ? '，次日' + arrStr + '到达' : ' → ' + arrStr + '到达'),
                    train.priceLabel + '：¥' + train.cost,
                    '提前在12306 APP购票，可选择座位'
                ]
            });
        });
    } else {
        // 无真实数据时用估算
        const trainTime = distKm / 250;
        const trainTotalTime = 1 + trainTime + 0.5;
        plans.push({
            id: 'train', icon: '🚄', name: '高铁', type: 'train',
            totalTime: trainTotalTime,
            totalTimeStr: formatHours(trainTotalTime),
            cost: Math.round(distKm * 0.45),
            distance: distKm,
            comfort: 85,
            isEstimate: true,
            steps: [
                { title: '前往高铁站', desc: '乘坐地铁/打车前往出发城市高铁站', duration: '约30-60分钟' },
                { title: '进站候车', desc: '刷身份证进站、安检、候车', duration: '约20-30分钟' },
                { title: '高铁行驶', desc: '高铁行驶，途经多个站点', duration: '约' + Math.round(trainTime * 60) + '分钟' },
                { title: '到达出站', desc: '下高铁、出站', duration: '约10-15分钟' },
                { title: '前往目的地', desc: '乘坐地铁/公交/打车前往目的地', duration: '约20-40分钟' }
            ],
            tips: [
                '提前在12306 APP购票，可选择靠窗/靠走道座位',
                '高铁站一般比机场更近市区，交通更便捷',
                '二等座性价比最高，一等座更舒适',
                '💡 票价为预估参考价，实际价格请以12306为准'
            ]
        });
    }

    // 中转联程方案：目的地无机场时，飞到最近机场再转火车
    if (depCity && destCity && hasAirport(depCity) && !hasAirport(destCity) && destLng && destLat) {
        const nearest = findNearestAirportCity(parseFloat(destLng), parseFloat(destLat), destCity, 400);
        if (nearest) {
            const flightDist = Math.sqrt(Math.pow((parseFloat(destLng) - parseFloat(depLng || 0)) * 111, 2) + Math.pow((parseFloat(destLat) - parseFloat(depLat || 0)) * 111, 2));
            const flightTime = flightDist * 1.3 / 800;
            const flightTotalTime = 2 + flightTime + 1;
            const flightCost = Math.round(flightDist * 1.2);
            // 中转火车时间估算
            const transferTrainDist = nearest.distKm;
            const transferTrainTime = transferTrainDist / 200 + 1; // 动车+接驳
            const transferTrainCost = Math.round(transferTrainDist * 0.5);
            const totalTransferTime = flightTotalTime + transferTrainTime;
            const totalTransferCost = flightCost + transferTrainCost;

            plans.push({
                id: 'transfer', icon: '🔄', name: '中转联程', type: 'transfer',
                totalTime: totalTransferTime,
                totalTimeStr: formatHours(totalTransferTime),
                cost: totalTransferCost,
                distance: Math.round(flightDist * 1.3) + transferTrainDist,
                comfort: 70,
                isEstimate: true,
                transferCity: nearest.city,
                transferAirport: nearest.airport.name,
                transferDist: nearest.distKm,
                steps: [
                    { title: '前往出发机场', desc: '前往' + (getAirportInfo(depCity) || [{}])[0].name || depCity + '机场', duration: '约1-1.5小时' },
                    { title: '✈️ 飞往' + nearest.city, desc: depCity + ' → ' + nearest.city + '，' + nearest.airport.name, duration: '约' + formatHours(flightTotalTime) },
                    { title: '到达' + nearest.city + '机场', desc: '下机、取行李、出机场', duration: '约30-45分钟' },
                    { title: '🚄 转乘火车/大巴前往' + destCity, desc: nearest.city + ' → ' + destCity + '，约' + nearest.distKm + '公里', duration: '约' + formatHours(transferTrainTime) },
                    { title: '到达' + destCity, desc: '抵达最终目的地', duration: '' }
                ],
                tips: [
                    '推荐路线：' + depCity + ' ✈️ ' + nearest.city + ' 🚄 ' + destCity,
                    nearest.city + '机场距' + destCity + '约' + nearest.distKm + '公里',
                    '飞机+火车总费用约¥' + totalTransferCost + '（预估）',
                    '💡 建议提前在12306查询' + nearest.city + '→' + destCity + '的火车班次'
                ]
            });
        }
    }

    // 自驾
    if (drivingResult) {
        const drivingHours = drivingResult.time / 3600;
        const restTime = Math.floor(drivingHours / 4) * 0.5;
        plans.push({
            id: 'drive', icon: '🚗', name: '自驾', type: 'drive',
            totalTime: drivingHours + restTime,
            totalTimeStr: formatHours(drivingHours + restTime),
            cost: Math.round(distKm * 0.8 + drivingResult.tolls),
            distance: drivingResult.distance / 1000,
            comfort: 60,
            isEstimate: false,
            steps: [
                { title: '出发', desc: '从出发城市出发，导航设置目的地', duration: '即刻出发' },
                { title: '高速行驶', desc: '途经高速公路，全程约' + Math.round(drivingResult.distance/1000) + '公里', duration: '约' + Math.round(drivingHours) + '小时' },
                { title: '服务区休息', desc: '每4小时建议休息30分钟，补充食物和水', duration: '约' + Math.round(restTime*60) + '分钟' },
                { title: '到达目的地', desc: '下高速，导航至目的地', duration: '约20-30分钟' }
            ],
            tips: [
                '全程约' + Math.round(drivingResult.distance/1000) + '公里，高速费约¥' + drivingResult.tolls,
                '油费预估约¥' + Math.round(distKm * 0.8) + '（按0.8元/公里计算）',
                '建议提前下载离线地图，防止山区无信号',
                '长途自驾建议两人轮流驾驶，安全第一'
            ]
        });
    }

    return plans;
}

function renderTransportNew(plans) {
    const container = document.getElementById('transportOptions');
    const summary = document.getElementById('transportSummary');
    document.getElementById('transportSection').style.display = 'block';

    // 排序方案
    const sortedPlans = {
        recommend: [...plans].sort((a, b) => {
            const scoreA = (100 - a.comfort) * 0.3 + (a.totalTime / 24) * 40 + (a.cost / 5000) * 30;
            const scoreB = (100 - b.comfort) * 0.3 + (b.totalTime / 24) * 40 + (b.cost / 5000) * 30;
            return scoreA - scoreB;
        }),
        fastest: [...plans].sort((a, b) => a.totalTime - b.totalTime),
        cheapest: [...plans].sort((a, b) => a.cost - b.cost)
    };

    const fastestPlan = sortedPlans.fastest[0];
    const cheapestPlan = sortedPlans.cheapest[0];
    const bestComfortPlan = [...plans].sort((a, b) => b.comfort - a.comfort)[0];

    const recommended = sortedPlans.recommend[0];
    summary.innerHTML = '<div class="summary-icon">💡</div>' +
        '<div class="summary-text">综合考虑时间、费用和舒适度，推荐您选择' +
        '<span class="summary-highlight">' + recommended.name + '</span>方案，全程约' +
        '<span class="summary-highlight">' + recommended.totalTimeStr + '</span>，费用约' +
        '<span class="summary-highlight">¥' + recommended.cost + '</span>' +
        '<div class="summary-compare"><span>⚡最快：' + fastestPlan.name + ' ' + fastestPlan.totalTimeStr + '</span><span>💰最省：' + cheapestPlan.name + ' ¥' + cheapestPlan.cost + '</span></div></div>'

    window._sortedPlans = sortedPlans;
    window._fastestId = fastestPlan.id;
    window._cheapestId = cheapestPlan.id;
    window._bestComfortId = bestComfortPlan.id;

    renderPlanList('recommend');

    // 默认自动绘制推荐方案的路线
    var recommendPlan = sortedPlans.recommend[0];
    if (recommendPlan && window._routeStartLng && window._routeStartLat && window._routeEndLng && window._routeEndLat) {
        setTimeout(function() {
            drawRouteByType(recommendPlan.type === 'drive' ? 'driving' : recommendPlan.type, [window._routeStartLng, window._routeStartLat], [window._routeEndLng, window._routeEndLat]);
        }, 500);
    }
}

function renderPlanList(sortType) {
    const container = document.getElementById('transportOptions');
    const plans = window._sortedPlans[sortType];
    const fastestId = window._fastestId;
    const cheapestId = window._cheapestId;
    const bestComfortId = window._bestComfortId;
    const allPlans = window._sortedPlans.recommend;

    const maxTime = Math.max(...allPlans.map(p => p.totalTime));
    const maxCost = Math.max(...allPlans.map(p => p.cost));

    container.innerHTML = plans.map((plan, index) => {
        const isRecommended = sortType === 'recommend' && index === 0;
        const isFastest = plan.id === fastestId;
        const isCheapest = plan.id === cheapestId;
        const isBestComfort = plan.id === bestComfortId;

        let tags = '';
        if (isFastest) tags += '<span class="recommend-tag tag-fast">最快</span>';
        if (isCheapest) tags += '<span class="recommend-tag tag-cheap">最省</span>';
        if (isBestComfort) tags += '<span class="recommend-tag tag-best">最舒适</span>';
        if (plan.type === 'transfer') tags += '<span class="recommend-tag tag-transfer">中转</span>';

        const timePercent = (plan.totalTime / maxTime * 100).toFixed(0);
        const costPercent = (plan.cost / maxCost * 100).toFixed(0);
        const comfortPercent = plan.comfort;
        const routeType = plan.type === 'drive' ? 'driving' : plan.type;
        const startLng = window._routeStartLng || '';
        const startLat = window._routeStartLat || '';
        const endLng = window._routeEndLng || '';
        const endLat = window._routeEndLat || '';

        return '<div class="transport-plan ' + (isRecommended ? 'recommended' : '') + ' transport-option-card' + (isRecommended ? ' active' : '') + '" data-plan-id="' + plan.id + '" data-route-type="' + routeType + '" data-start-lng="' + startLng + '" data-start-lat="' + startLat + '" data-end-lng="' + endLng + '" data-end-lat="' + endLat + '" onclick="selectTransportPlan(this)">' +
            '<div class="plan-header" onclick="event.stopPropagation(); togglePlanDetail(\'' + plan.id + '\')">' +
                '<div class="plan-badge"><span class="badge-icon">' + plan.icon + '</span><span class="badge-label">' + plan.name + '</span></div>' +
                '<div class="plan-info">' +
                    '<div class="plan-title">' + plan.name + '方案' + (plan.trainName ? ' <span class="train-name">' + plan.trainName + '</span>' : '') + (isRecommended ? ' <span class="recommend-tag tag-best">推荐</span>' : '') + tags + (plan.isEstimate ? ' <span class="estimate-tag">预估</span>' : '') + '</div>' +
                    '<div class="plan-metrics">' +
                        '<div class="plan-metric"><span class="metric-icon">⏱️</span><span class="metric-value">' + (plan.depTime ? plan.depTime + '→' + plan.arrTime + (plan.isNextDay ? '+1' : '') : plan.totalTimeStr) + '</span></div>' +
                        '<div class="plan-metric"><span class="metric-icon">📏</span><span class="metric-value">' + Math.round(plan.distance) + '公里</span></div>' +
                    '</div>' +
                '</div>' +
                '<div class="plan-price"><div class="price-value">¥' + plan.cost + '</div><div class="price-unit">' + (plan.priceLabel ? plan.priceLabel : '预估总费用') + '</div></div>' +
                '<div class="plan-toggle" id="toggle-' + plan.id + '">▼</div>' +
            '</div>' +
            '<div class="plan-detail" id="detail-' + plan.id + '">' +
                '<div class="detail-steps">' +
                    plan.steps.map((step, i) =>
                        '<div class="detail-step"><div class="step-number">' + (i+1) + '</div>' +
                        '<div class="step-content"><div class="step-title">' + step.title + '</div>' +
                        '<div class="step-desc">' + step.desc + '</div>' +
                        '<div class="step-duration">' + step.duration + '</div></div></div>'
                    ).join('') +
                '</div>' +
                (plan.tips && plan.tips.length > 0 ?
                    '<div class="detail-tips"><div class="tips-title">💡 贴心提示</div>' +
                    '<div class="tips-content">' + plan.tips.map(tip => '• ' + tip).join('<br>') + '</div></div>' : '') +
                '<div class="plan-comparison"><div class="comparison-title">方案对比</div>' +
                '<div class="comparison-bars">' +
                    '<div class="comparison-bar"><span class="bar-label">时间</span><div class="bar-track"><div class="bar-fill time" style="width:' + timePercent + '%"></div></div><span class="bar-value">' + plan.totalTimeStr + '</span></div>' +
                    '<div class="comparison-bar"><span class="bar-label">费用</span><div class="bar-track"><div class="bar-fill cost" style="width:' + costPercent + '%"></div></div><span class="bar-value">¥' + plan.cost + '</span></div>' +
                    '<div class="comparison-bar"><span class="bar-label">舒适度</span><div class="bar-track"><div class="bar-fill comfort" style="width:' + comfortPercent + '%"></div></div><span class="bar-value">' + comfortPercent + '%</span></div>' +
                '</div></div>' +
            '</div>' +
        '</div>';
    }).join('');

    // 绑定标签切换事件
    document.querySelectorAll('.transport-tab').forEach(tab => {
        tab.onclick = function() {
            document.querySelectorAll('.transport-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            renderPlanList(this.dataset.sort);
        };
    });
}

function togglePlanDetail(planId) {
    const detail = document.getElementById('detail-' + planId);
    const toggle = document.getElementById('toggle-' + planId);
    if (detail.classList.contains('show')) {
        detail.classList.remove('show');
        toggle.classList.remove('expanded');
    } else {
        detail.classList.add('show');
        toggle.classList.add('expanded');
    }
}


// ========================================
// 浏览器卫星定位（locateUser）
// ========================================

/**
 * 使用浏览器 Geolocation API 获取用户当前位置
 * 定位成功后通过高德逆地理编码获取具体地址
 * 用户可随时手动修改出发城市
 */
function locateUser() {
    var inputEl = document.getElementById('departureInput');
    if (!inputEl) return;

    // 显示定位中状态
    inputEl.innerHTML = '<span class="city-value locating"><span class="locate-icon">📡</span> 正在定位...</span>' +
        '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

    if (!navigator.geolocation) {
        inputEl.innerHTML = '<span class="city-value"><span class="locate-icon">📍</span> 定位不可用，请手动选择</span>' +
            '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        return;
    }

    navigator.geolocation.getCurrentPosition(
        function(position) {
            var lng = position.coords.longitude;
            var lat = position.coords.latitude;

            // 使用高德逆地理编码获取具体地址
            if (typeof AMap !== 'undefined') {
                var geo = new AMap.Geocoder({ radius: 1000, extensions: 'base' });
                geo.getAddress(new AMap.LngLat(lng, lat), function(status, result) {
                    if (status === 'complete' && result.regeocode) {
                        var ac = result.regeocode.addressComponent || {};
                        // 提取简短地址：优先显示具体位置
                        var shortAddr = '';
                        if (ac.street || ac.streetNumber) {
                            shortAddr = (ac.street || '') + (ac.streetNumber || '');
                        }
                        if (ac.district) {
                            shortAddr = ac.district + (shortAddr ? ' ' + shortAddr : '');
                        }
                        if (ac.city && typeof ac.city === 'string' && ac.city) {
                            shortAddr = ac.city + ' ' + shortAddr;
                        } else if (ac.city && Array.isArray(ac.city) && ac.city.length > 0) {
                            shortAddr = ac.city[0] + ' ' + shortAddr;
                        } else if (ac.province) {
                            shortAddr = ac.province + ' ' + shortAddr;
                        }
                        // 截断过长的地址
                        if (shortAddr.length > 30) shortAddr = shortAddr.substring(0, 30) + '...';

                        // 更新出发城市信息
                        var cityName = (ac.city && typeof ac.city === 'string' && ac.city) ||
                            (ac.city && Array.isArray(ac.city) && ac.city.length > 0 ? ac.city[0] : '') ||
                            ac.province || '当前位置';
                        document.getElementById('departureCity').value = cityName;
                        document.getElementById('departureLng').value = lng;
                        document.getElementById('departureLat').value = lat;

                        inputEl.innerHTML = '<span class="city-value"><span class="locate-icon">📍</span> ' + shortAddr + '</span>' +
                            '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

                        // 更新地图Marker
                        if (typeof updateMapMarker === 'function') {
                            updateMapMarker('departure', lng, lat, cityName);
                        }
                    } else {
                        // 逆地理编码失败，使用坐标
                        document.getElementById('departureCity').value = '当前位置';
                        document.getElementById('departureLng').value = lng;
                        document.getElementById('departureLat').value = lat;
                        inputEl.innerHTML = '<span class="city-value"><span class="locate-icon">📍</span> 当前位置</span>' +
                            '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                    }
                });
            } else {
                // 高德API未加载，直接用坐标
                document.getElementById('departureCity').value = '当前位置';
                document.getElementById('departureLng').value = lng;
                document.getElementById('departureLat').value = lat;
                inputEl.innerHTML = '<span class="city-value"><span class="locate-icon">📍</span> 当前位置</span>' +
                    '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
            }
        },
        function(error) {
            // 定位失败，提示用户手动选择
            var msg = '定位失败';
            switch (error.code) {
                case error.PERMISSION_DENIED: msg = '定位被拒绝，请手动选择'; break;
                case error.POSITION_UNAVAILABLE: msg = '无法获取位置，请手动选择'; break;
                case error.TIMEOUT: msg = '定位超时，请手动选择'; break;
            }
            inputEl.innerHTML = '<span class="city-value"><span class="locate-icon">📍</span> ' + msg + '</span>' +
                '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
}


// ========================================
// 城市选择器交互增强（initCitySelectors）
// ========================================

/**
 * 初始化城市选择器的完整交互逻辑
 * 使用高德 AMap.AutoComplete 实现搜索建议
 * - 点击输入框展开下拉面板
 * - 输入文字时调用 AutoComplete 获取搜索建议
 * - 点击搜索结果直接选中并关闭下拉
 * - 按回车键选中第一个搜索结果
 * - 点击热门城市标签直接选中
 * - 选中后更新隐藏 input 的值（city/lng/lat）
 */
function initCitySelectors() {
    // 为出发地选择器绑定增强交互
    enhanceCitySelector('departure');
    // 为目的地选择器绑定增强交互
    enhanceCitySelector('destination');
}

/**
 * 为单个城市选择器绑定增强交互
 * @param {string} type - 选择器类型：'departure' 或 'destination'
 */
function enhanceCitySelector(type) {
    var inputEl = document.getElementById(type + 'Input');
    var dropdownEl = document.getElementById(type + 'Dropdown');
    var searchInput = document.getElementById(type + 'Search');
    var searchResults = document.getElementById(type + 'SearchResults');
    var hotCitiesEl = document.getElementById(type + 'HotCities');
    var hiddenCity = document.getElementById(type + 'City');
    var hiddenLng = document.getElementById(type + 'Lng');
    var hiddenLat = document.getElementById(type + 'Lat');

    if (!inputEl || !dropdownEl) return;

    // 当前搜索结果缓存（用于回车键选中第一个）
    var currentResults = [];
    // 搜索防抖定时器
    var searchTimer = null;

    // --- 点击输入框展开下拉面板 ---
    inputEl.addEventListener('click', function(e) {
        e.stopPropagation();
        // 切换下拉面板显示状态
        var isOpen = dropdownEl.classList.contains('show');
        if (isOpen) {
            dropdownEl.classList.remove('show');
            inputEl.classList.remove('active');
        } else {
            dropdownEl.classList.add('show');
            inputEl.classList.add('active');
            searchInput.value = '';
            searchResults.classList.remove('show');
            // 聚焦搜索框
            setTimeout(function() { searchInput.focus(); }, 100);
        }
    });

    // --- 输入文字时调用 AutoComplete 获取搜索建议 ---
    searchInput.addEventListener('input', function(e) {
        var keyword = e.target.value.trim();
        clearTimeout(searchTimer);

        if (!keyword || keyword.length < 1) {
            searchResults.classList.remove('show');
            currentResults = [];
            return;
        }

        // 防抖：300ms 后执行搜索
        searchTimer = setTimeout(function() {
            searchResults.innerHTML = '<div class="search-loading">搜索中...</div>';
            searchResults.classList.add('show');

            try {
                // 使用高德 AutoComplete 插件，city 设为空字符串（全国搜索）
                var autoComplete = new AMap.AutoComplete({
                    city: '',
                    citylimit: false
                });
                autoComplete.search(keyword, function(status, result) {
                    if (status === 'complete' && result.tips) {
                        // 过滤出有坐标的结果，并智能排序
                        currentResults = result.tips.filter(function(tip) {
                            return tip.location && tip.location.lng && tip.location.lat && tip.name;
                        });

                        // 智能排序：名称完全匹配 > 名称以关键词开头 > 名称包含关键词 > 其他
                        var kw = keyword.toLowerCase();
                        currentResults.sort(function(a, b) {
                            var aName = (a.name || '').toLowerCase();
                            var bName = (b.name || '').toLowerCase();
                            var aDistrict = (a.district || '').toLowerCase();
                            var bDistrict = (b.district || '').toLowerCase();

                            // 完全匹配名称（最高优先）
                            if (aName === kw && bName !== kw) return -1;
                            if (bName === kw && aName !== kw) return 1;
                            // 名称以关键词开头
                            if (aName.startsWith(kw) && !bName.startsWith(kw)) return -1;
                            if (bName.startsWith(kw) && !aName.startsWith(kw)) return 1;
                            // district包含关键词（省份/城市级别匹配）
                            var aInDist = aDistrict.indexOf(kw) !== -1 ? 1 : 0;
                            var bInDist = bDistrict.indexOf(kw) !== -1 ? 1 : 0;
                            if (aInDist !== bInDist) return bInDist - aInDist;
                            // 名称包含关键词
                            var aInName = aName.indexOf(kw) !== -1 ? 1 : 0;
                            var bInName = bName.indexOf(kw) !== -1 ? 1 : 0;
                            if (aInName !== bInName) return bInName - aInName;
                            return 0;
                        });

                        currentResults = currentResults.slice(0, 10);

                        if (currentResults.length === 0) {
                            searchResults.innerHTML = '<div class="no-result">未找到匹配的地点，请尝试其他关键词</div>';
                            return;
                        }

                        // 渲染搜索结果列表
                        searchResults.innerHTML = currentResults.map(function(item, idx) {
                            var district = item.district || '';
                            var typeStr = getTypeName(item.typecode) || '';
                            return '<div class="search-result-item" data-index="' + idx + '">' +
                                '<span class="result-name">' + item.name + '</span>' +
                                '<span class="result-address">' + district + '</span>' +
                                (typeStr ? '<span class="result-type">' + typeStr + '</span>' : '') +
                                '</div>';
                        }).join('');

                        // --- 点击搜索结果直接选中并关闭下拉 ---
                        searchResults.querySelectorAll('.search-result-item').forEach(function(el) {
                            el.addEventListener('click', function() {
                                var idx = parseInt(this.dataset.index);
                                var item = currentResults[idx];
                                if (item) {
                                    selectCity(type, item.name, item.location.lng, item.location.lat, item.district || '');
                                }
                            });
                        });
                    } else {
                        searchResults.innerHTML = '<div class="no-result">未找到匹配的地点，请尝试其他关键词</div>';
                        currentResults = [];
                    }
                });
            } catch (err) {
                console.error('AutoComplete 搜索失败:', err);
                searchResults.innerHTML = '<div class="no-result">搜索出错，请稍后重试</div>';
                currentResults = [];
            }
        }, 300);
    });

    // --- 按回车键智能选中 ---
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            var keyword = searchInput.value.trim();
            if (!keyword) return;

            if (currentResults.length > 0) {
                var first = currentResults[0];
                var firstName = (first.name || '').toLowerCase();
                var firstDistrict = (first.district || '').toLowerCase();
                var kw = keyword.toLowerCase();

                // 智能判断是否使用Geocoder
                // 条件1：短关键词（<=4字）且第一个结果不是精确匹配（如"新疆"不应匹配"新疆图书馆"）
                // 条件2：第一个结果名称中包含括号（说明是具体POI如地铁站/公交站，而非城市）
                var isExactMatch = firstName === kw;
                var isCityLike = firstName.length <= kw.length + 2 && !firstName.includes('(') && !firstName.includes('（');
                var useGeocoder = (kw.length <= 4 && !isExactMatch && !isCityLike) || firstName.includes('(') || firstName.includes('（');

                if (!useGeocoder) {
                    selectCity(type, first.name, first.location.lng, first.location.lat, first.district || '');
                } else {
                    // 使用Geocoder做地理编码获取区域中心
                    searchResults.innerHTML = '<div class="search-loading">正在定位 ' + keyword + '...</div>';
                    try {
                        var geocoder = new AMap.Geocoder({ city: '' });
                        geocoder.getLocation(keyword, function(status, geoResult) {
                            if (status === 'complete' && geoResult.geocodes && geoResult.geocodes.length > 0) {
                                var geo = geoResult.geocodes[0];
                                var geoName = geo.formattedAddress || keyword;
                                // 提取简短名称：优先城市 > 区县 > 省份
                                if (geo.city && geo.city.length > 0 && geo.city[0] !== kw) {
                                    geoName = geo.city[0];
                                } else if (geo.district && geo.district.length > 0 && geo.district[0] !== kw) {
                                    geoName = geo.district[0];
                                } else if (geo.province) {
                                    geoName = geo.province.replace(/(省|市|自治区|特别行政区|维吾尔|壮族|回族)/g, '').trim();
                                    if (!geoName) geoName = geo.province;
                                }
                                selectCity(type, geoName, geo.location.lng, geo.location.lat, geo.formattedAddress || '');
                            } else {
                                // Geocoder也找不到，回退到第一个AutoComplete结果
                                selectCity(type, first.name, first.location.lng, first.location.lat, first.district || '');
                            }
                        });
                    } catch (err) {
                        console.error('Geocoder失败:', err);
                        selectCity(type, first.name, first.location.lng, first.location.lat, first.district || '');
                    }
                }
            } else {
                // 没有搜索结果，尝试用Geocoder直接定位
                searchResults.innerHTML = '<div class="search-loading">正在定位 ' + keyword + '...</div>';
                try {
                    var geocoder2 = new AMap.Geocoder({ city: '' });
                    geocoder2.getLocation(keyword, function(status, geoResult) {
                        if (status === 'complete' && geoResult.geocodes && geoResult.geocodes.length > 0) {
                            var geo = geoResult.geocodes[0];
                            var geoName = geo.formattedAddress || keyword;
                            if (geo.city && geo.city.length > 0) {
                                geoName = geo.city[0];
                            } else if (geo.district && geo.district.length > 0) {
                                geoName = geo.district[0];
                            } else if (geo.province) {
                                geoName = geo.province;
                            }
                            selectCity(type, geoName, geo.location.lng, geo.location.lat, geo.formattedAddress || '');
                        } else {
                            searchResults.innerHTML = '<div class="no-result">未找到 "' + keyword + '"，请尝试更具体的名称</div>';
                        }
                    });
                } catch (err) {
                    searchResults.innerHTML = '<div class="no-result">搜索出错，请稍后重试</div>';
                }
            }
        }
        // 按 Escape 关闭下拉
        if (e.key === 'Escape') {
            dropdownEl.classList.remove('show');
            inputEl.classList.remove('active');
        }
    });

    // --- 点击热门城市标签直接选中 ---
    if (hotCitiesEl) {
        hotCitiesEl.querySelectorAll('.city-tag').forEach(function(tag) {
            tag.addEventListener('click', function() {
                var name = this.dataset.city;
                var lng = parseFloat(this.dataset.lng);
                var lat = parseFloat(this.dataset.lat);
                selectCity(type, name, lng, lat, '');
            });
        });
    }

    // --- 点击外部关闭下拉 ---
    document.addEventListener('click', function(e) {
        if (!dropdownEl.contains(e.target) && !inputEl.contains(e.target)) {
            dropdownEl.classList.remove('show');
            inputEl.classList.remove('active');
        }
    });

    // 阻止下拉面板内部点击冒泡关闭
    dropdownEl.addEventListener('click', function(e) {
        e.stopPropagation();
    });
}

/**
 * 选中城市并更新界面
 * @param {string} type - 选择器类型
 * @param {string} name - 城市名
 * @param {number} lng - 经度
 * @param {number} lat - 纬度
 * @param {string} district - 区域信息
 */
function selectCity(type, name, lng, lat, district) {
    var inputEl = document.getElementById(type + 'Input');
    var dropdownEl = document.getElementById(type + 'Dropdown');
    var hiddenCity = document.getElementById(type + 'City');
    var hiddenLng = document.getElementById(type + 'Lng');
    var hiddenLat = document.getElementById(type + 'Lat');
    var hotCitiesEl = document.getElementById(type + 'HotCities');

    // 更新隐藏 input 的值
    hiddenCity.value = name;
    hiddenLng.value = lng;
    hiddenLat.value = lat;

    // 更新显示文本
    var displayText = district ? name + ' (' + district + ')' : name;
    inputEl.innerHTML = '<span class="city-value">' + displayText + '</span>' +
        '<svg class="city-arrow" width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

    // 更新热门城市标签的选中状态
    if (hotCitiesEl) {
        hotCitiesEl.querySelectorAll('.city-tag').forEach(function(tag) {
            if (tag.dataset.city === name) {
                tag.classList.add('selected');
            } else {
                tag.classList.remove('selected');
            }
        });
    }

    // 关闭下拉面板
    dropdownEl.classList.remove('show');
    inputEl.classList.remove('active');

    // 如果地图选点器已初始化，更新地图上的 Marker
    updateMapMarker(type, lng, lat, name);
}


// ========================================
// 地图点击选点（initMapPicker）
// ========================================

// 地图相关全局变量
var mapPickerMap = null;       // 高德地图实例
var departureMarker = null;    // 出发地 Marker
var destinationMarker = null;   // 目的地 Marker
var geocoder = null;            // 逆地理编码器

/**
 * 初始化地图选点功能
 * - 在 resultSection 上方显示地图容器
 * - 地图上显示两个可拖拽的 Marker（出发地/目的地）
 * - 点击地图空白处弹出确认框，选择设为出发地还是目的地
 * - 拖拽 Marker 更新对应的城市名和坐标
 * - 使用 AMap.Geocoder 进行逆地理编码
 */
function initMapPicker() {
    var mapContainer = document.getElementById('mapPicker');
    if (!mapContainer) return;

    // 初始化逆地理编码器
    geocoder = new AMap.Geocoder({
        radius: 1000,
        extensions: 'base'
    });

    // 初始化高德地图，默认中心为中国中心位置
    mapPickerMap = new AMap.Map('mapPicker', {
        zoom: 5,
        center: [108.946, 34.263], // 中国大致中心
        resizeEnable: true,
        mapStyle: 'amap://styles/normal'
    });

    // 添加地图控件
    mapPickerMap.addControl(new AMap.Scale());
    mapPickerMap.addControl(new AMap.ToolBar({
        position: 'RT'
    }));

    // 创建出发地 Marker（绿色）
    departureMarker = new AMap.Marker({
        map: mapPickerMap,
        position: [116.397128, 39.916527], // 默认北京
        draggable: true,
        animation: 'AMAP_ANIMATION_DROP',
        content: '<div style="width:28px;height:28px;background:#10b981;border:3px solid #fff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:bold;">出</div>',
        label: {
            content: '出发地',
            direction: 'top',
            offset: new AMap.Pixel(0, -5)
        }
    });

    // 创建目的地 Marker（紫色）
    destinationMarker = new AMap.Marker({
        map: mapPickerMap,
        position: [121.473658, 31.230378], // 默认上海
        draggable: true,
        animation: 'AMAP_ANIMATION_DROP',
        content: '<div style="width:28px;height:28px;background:#8b5cf6;border:3px solid #fff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:bold;">目</div>',
        label: {
            content: '目的地',
            direction: 'top',
            offset: new AMap.Pixel(0, -5)
        }
    });

    // --- 拖拽 Marker 更新对应的城市名和坐标 ---
    departureMarker.on('dragend', function(e) {
        var lnglat = e.lnglat;
        reverseGeocode(lnglat.lng, lnglat.lat, 'departure');
    });

    destinationMarker.on('dragend', function(e) {
        var lnglat = e.lnglat;
        reverseGeocode(lnglat.lng, lnglat.lat, 'destination');
    });

    // --- 点击地图空白处弹出确认框 ---
    mapPickerMap.on('click', function(e) {
        var lng = e.lnglat.lng;
        var lat = e.lnglat.lat;

        // 创建自定义确认弹窗
        showMapPickerDialog(lng, lat);
    });

    // 监听城市选择器变化，同步更新地图 Marker
    observeCitySelectors();
}

/**
 * 逆地理编码：坐标 -> 城市名
 * @param {number} lng - 经度
 * @param {number} lat - 纬度
 * @param {string} type - 'departure' 或 'destination'
 */
function reverseGeocode(lng, lat, type) {
    if (!geocoder) return;

    geocoder.getAddress(new AMap.LngLat(lng, lat), function(status, result) {
        if (status === 'complete' && result.regeocode) {
            // 提取城市名或区域名
            var addressComponent = result.regeocode.addressComponent || {};
            var cityName = addressComponent.city || addressComponent.province || result.regeocode.formattedAddress || '未知位置';
            // 如果 city 是空数组（某些直辖市），使用 province
            if (Array.isArray(cityName) && cityName.length === 0) {
                cityName = addressComponent.province || '未知位置';
            }
            // 简化显示：取城市名即可
            if (typeof cityName === 'string' && cityName.length > 10) {
                cityName = cityName.substring(0, 10);
            }
            selectCity(type, cityName, lng, lat, addressComponent.district || '');
        } else {
            // 逆地理编码失败时使用坐标作为名称
            selectCity(type, lng.toFixed(4) + ', ' + lat.toFixed(4), lng, lat, '');
        }
    });
}

/**
 * 显示地图点击选点确认弹窗
 * @param {number} lng - 经度
 * @param {number} lat - 纬度
 */
function showMapPickerDialog(lng, lat) {
    // 移除已有的弹窗
    var existingDialog = document.getElementById('mapPickerDialog');
    if (existingDialog) existingDialog.remove();

    // 创建弹窗 DOM
    var dialog = document.createElement('div');
    dialog.id = 'mapPickerDialog';
    dialog.className = 'map-picker-dialog';
    dialog.innerHTML =
        '<div class="map-picker-dialog-content">' +
            '<div class="map-picker-dialog-title">选择设置类型</div>' +
            '<div class="map-picker-dialog-desc">将此位置设为：</div>' +
            '<div class="map-picker-dialog-buttons">' +
                '<button class="map-picker-btn departure-btn" id="mapPickerSetDeparture">' +
                    '<span class="btn-icon">出</span> 设为出发地' +
                '</button>' +
                '<button class="map-picker-btn destination-btn" id="mapPickerSetDestination">' +
                    '<span class="btn-icon">目</span> 设为目的地' +
                '</button>' +
            '</div>' +
            '<button class="map-picker-cancel" id="mapPickerCancel">取消</button>' +
        '</div>';

    document.body.appendChild(dialog);

    // 绑定按钮事件
    document.getElementById('mapPickerSetDeparture').addEventListener('click', function() {
        reverseGeocode(lng, lat, 'departure');
        dialog.remove();
    });

    document.getElementById('mapPickerSetDestination').addEventListener('click', function() {
        reverseGeocode(lng, lat, 'destination');
        dialog.remove();
    });

    document.getElementById('mapPickerCancel').addEventListener('click', function() {
        dialog.remove();
    });

    // 点击弹窗外部关闭
    dialog.addEventListener('click', function(e) {
        if (e.target === dialog) dialog.remove();
    });
}

/**
 * 更新地图上的 Marker 位置
 * 当城市选择器选中城市后调用
 * @param {string} type - 'departure' 或 'destination'
 * @param {number} lng - 经度
 * @param {number} lat - 纬度
 * @param {string} name - 城市名
 */
function updateMapMarker(type, lng, lat, name) {
    if (!mapPickerMap) return;

    var marker = (type === 'departure') ? departureMarker : destinationMarker;
    if (!marker) return;

    // 清除旧的路线
    clearRouteLines();

    // 更新 Marker 位置
    marker.setPosition([lng, lat]);

    // 更新 Marker 标签
    marker.setLabel({
        content: name,
        direction: 'top',
        offset: new AMap.Pixel(0, -5)
    });

    // 调整地图视野以包含两个 Marker
    if (departureMarker && destinationMarker) {
        mapPickerMap.setFitView([departureMarker, destinationMarker], false, [60, 60, 60, 60]);
    }
}

/**
 * 监听城市选择器的隐藏 input 变化，同步更新地图 Marker
 */
function observeCitySelectors() {
    // 监听出发地变化
    var depLngInput = document.getElementById('departureLng');
    var depLatInput = document.getElementById('departureLat');
    var depCityInput = document.getElementById('departureCity');

    // 监听目的地变化
    var destLngInput = document.getElementById('destinationLng');
    var destLatInput = document.getElementById('destinationLat');
    var destCityInput = document.getElementById('destinationCity');

    // 使用 MutationObserver 监听 input 值变化
    var observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            var target = mutation.target;
            if (target === depLngInput || target === depLatInput) {
                var lng = parseFloat(depLngInput.value);
                var lat = parseFloat(depLatInput.value);
                var name = depCityInput.value;
                if (lng && lat && name) {
                    updateMapMarker('departure', lng, lat, name);
                }
            }
            if (target === destLngInput || target === destLatInput) {
                var lng = parseFloat(destLngInput.value);
                var lat = parseFloat(destLatInput.value);
                var name = destCityInput.value;
                if (lng && lat && name) {
                    updateMapMarker('destination', lng, lat, name);
                }
            }
        });
    });

    // 监听属性变化（value 属性通过 setAttribute 修改时触发）
    var inputsToObserve = [depLngInput, depLatInput, destLngInput, destLatInput];
    inputsToObserve.forEach(function(input) {
        if (input) {
            observer.observe(input, { attributes: true, attributeFilter: ['value'] });
        }
    });
}

// ========================================
// 天气功能模块
// ========================================

/**
 * WMO天气代码映射表
 * 将WMO天气代码转换为中文描述和emoji
 */
const WMO_WEATHER_MAP = {
    0:  { desc: '晴天', emoji: '☀️' },
    1:  { desc: '大部晴朗', emoji: '⛅' },
    2:  { desc: '多云', emoji: '⛅' },
    3:  { desc: '阴天', emoji: '☁️' },
    45: { desc: '雾', emoji: '🌫️' },
    48: { desc: '雾凇', emoji: '🌫️' },
    51: { desc: '小毛毛雨', emoji: '🌦️' },
    53: { desc: '中毛毛雨', emoji: '🌦️' },
    55: { desc: '大毛毛雨', emoji: '🌦️' },
    56: { desc: '冻毛毛雨', emoji: '🌧️' },
    57: { desc: '冻毛毛雨', emoji: '🌧️' },
    61: { desc: '小雨', emoji: '🌧️' },
    63: { desc: '中雨', emoji: '🌧️' },
    65: { desc: '大雨', emoji: '🌧️' },
    66: { desc: '冻雨', emoji: '🌧️' },
    67: { desc: '冻雨', emoji: '🌧️' },
    71: { desc: '小雪', emoji: '❄️' },
    73: { desc: '中雪', emoji: '❄️' },
    75: { desc: '大雪', emoji: '❄️' },
    77: { desc: '雪粒', emoji: '❄️' },
    80: { desc: '小阵雨', emoji: '🌦️' },
    81: { desc: '中阵雨', emoji: '🌦️' },
    82: { desc: '大阵雨', emoji: '🌦️' },
    85: { desc: '小阵雪', emoji: '❄️' },
    86: { desc: '大阵雪', emoji: '❄️' },
    95: { desc: '雷暴', emoji: '⛈️' },
    96: { desc: '雷暴伴冰雹', emoji: '⛈️' },
    99: { desc: '雷暴伴冰雹', emoji: '⛈️' }
};

/**
 * 根据WMO天气代码获取天气描述和emoji
 * @param {number} code - WMO天气代码
 * @returns {Object} 包含desc和emoji的对象
 */
function getWeatherInfo(code) {
    return WMO_WEATHER_MAP[code] || { desc: '未知天气', emoji: '🌤️' };
}

/**
 * 根据WMO天气代码获取对应的emoji图标（兼容旧调用）
 * @param {number|string} weather - WMO天气代码或天气描述
 * @returns {string} 对应的emoji图标
 */
function getWeatherIcon(weather) {
    if (typeof weather === 'number') {
        return getWeatherInfo(weather).emoji;
    }
    // 如果传入的是字符串描述（兼容旧逻辑）
    if (!weather) return '🌤️';
    if (weather.includes('晴')) return '☀️';
    if (weather.includes('多云')) return '⛅';
    if (weather.includes('阴')) return '☁️';
    if (weather.includes('雷')) return '⛈️';
    if (weather.includes('大雨') || weather.includes('暴雨')) return '🌧️';
    if (weather.includes('雨')) return '🌦️';
    if (weather.includes('雪')) return '❄️';
    if (weather.includes('雾') || weather.includes('霾')) return '🌫️';
    return '🌤️';
}

/**
 * 通过Open-Meteo API获取天气预报数据
 * @param {string} cityName - 城市名称
 * @param {number} lng - 经度
 * @param {number} lat - 纬度
 * @param {number} days - 需要的天数（最多7天）
 * @returns {Promise<Object>} 格式化后的天气数据
 */
function fetchWeather(cityName, lng, lat, days) {
    return new Promise((resolve, reject) => {
        if (!lng || !lat) {
            reject(new Error('缺少目的地经纬度信息'));
            return;
        }
        const forecastDays = Math.min(days, 7);
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,uv_index_max,precipitation_probability_max,wind_direction_10m_dominant,apparent_temperature_max,apparent_temperature_min&timezone=auto&forecast_days=${forecastDays}`;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (!data.daily || !data.daily.time) {
                    reject(new Error('获取天气数据失败'));
                    return;
                }
                // 将Open-Meteo返回数据格式化为统一格式
                const daily = data.daily;
                const casts = daily.time.map((date, i) => ({
                    date: date,
                    weatherCode: daily.weather_code[i],
                    weatherDesc: getWeatherInfo(daily.weather_code[i]).desc,
                    weatherEmoji: getWeatherInfo(daily.weather_code[i]).emoji,
                    tempMax: Math.round(daily.temperature_2m_max[i]),
                    tempMin: Math.round(daily.temperature_2m_min[i]),
                    apparentTempMax: Math.round(daily.apparent_temperature_max[i]),
                    apparentTempMin: Math.round(daily.apparent_temperature_min[i]),
                    precipitation: daily.precipitation_sum[i],
                    precipitationProbability: daily.precipitation_probability_max[i],
                    windSpeed: Math.round(daily.wind_speed_10m_max[i]),
                    windDirection: daily.wind_direction_10m_dominant[i],
                    uvIndex: daily.uv_index_max[i]
                }));

                resolve({
                    city: cityName,
                    timezone: data.timezone || data.timezone_abbreviation || '',
                    casts: casts
                });
            })
            .catch(err => reject(err));
    });
}

/**
 * 根据WMO天气代码判断天气类型
 * @param {number} code - WMO天气代码
 * @returns {string} 天气类型：sunny/cloudy/foggy/rainy/snowy/stormy
 */
function getWeatherType(code) {
    if (code === 0) return 'sunny';
    if (code <= 3) return 'cloudy';
    if (code <= 48) return 'foggy';
    if (code <= 57) return 'rainy';
    if (code <= 67) return 'rainy';
    if (code <= 77) return 'snowy';
    if (code <= 82) return 'rainy';
    if (code <= 86) return 'snowy';
    return 'stormy';
}

/**
 * 将风向角度转换为中文描述
 * @param {number} degrees - 风向角度
 * @returns {string} 风向描述
 */
function getWindDirectionText(degrees) {
    if (degrees === undefined || degrees === null) return '';
    const dirs = ['北风', '东北风', '东风', '东南风', '南风', '西南风', '西风', '西北风'];
    const index = Math.round(degrees / 45) % 8;
    return dirs[index];
}

/**
 * 根据单日天气状况生成出行建议（增强版）
 * @param {Object} dayWeather - 单日天气数据（Open-Meteo格式）
 * @returns {Array} 建议列表 [{icon, text}]
 */
function generateWeatherAdvice(dayWeather) {
    const advices = [];
    const tempMax = dayWeather.tempMax;
    const tempMin = dayWeather.tempMin;
    const apparentMax = dayWeather.apparentTempMax;
    const apparentMin = dayWeather.apparentTempMin;
    const weatherCode = dayWeather.weatherCode;
    const weatherType = getWeatherType(weatherCode);
    const windSpeed = dayWeather.windSpeed;
    const uvIndex = dayWeather.uvIndex;
    const precipProb = dayWeather.precipitationProbability;

    // 雨天建议
    if (weatherType === 'rainy') {
        if (precipProb >= 70) {
            advices.push({ icon: '🌂', text: '降水概率很高，务必携带雨伞，建议穿防水鞋' });
        } else {
            advices.push({ icon: '🌂', text: '有降水可能，建议携带雨伞备用' });
        }
    }

    // 雪天建议
    if (weatherType === 'snowy') {
        advices.push({ icon: '🧣', text: '有降雪，注意路面结冰，穿防滑鞋' });
        if (tempMin < -5) {
            advices.push({ icon: '🧊', text: '气温极低，注意保暖防冻，减少户外停留时间' });
        }
    }

    // 雷暴建议
    if (weatherType === 'stormy') {
        advices.push({ icon: '⛈️', text: '有雷暴天气，尽量避免户外活动，远离空旷地带和高大树木' });
    }

    // 雾天建议
    if (weatherType === 'foggy') {
        advices.push({ icon: '😷', text: '能见度较低，出行注意安全，驾车减速慢行' });
    }

    // 高温建议
    if (tempMax > 40) {
        advices.push({ icon: '🌡️', text: '极端高温预警！避免中午时段外出，多喝水防中暑' });
    } else if (tempMax > 35) {
        advices.push({ icon: '🌡️', text: '高温预警，注意防暑降温，多喝水，避免中午出行' });
    } else if (tempMax > 30) {
        advices.push({ icon: '☀️', text: '气温较高，注意防晒补水' });
    }

    // 体感温度与实际温度差异大时的建议
    if (apparentMax - tempMax >= 5) {
        advices.push({ icon: '🔥', text: '体感温度明显高于实际温度（' + apparentMax + '°C），闷热感强，注意防暑' });
    }
    if (tempMin - apparentMin >= 5) {
        advices.push({ icon: '🥶', text: '夜间体感温度较低（' + apparentMin + '°C），注意额外保暖' });
    }

    // 低温建议
    if (tempMin < -10) {
        advices.push({ icon: '🧊', text: '严寒天气，务必穿羽绒服、戴手套围巾帽子' });
    } else if (tempMin < 0) {
        advices.push({ icon: '🧥', text: '气温低于零度，注意保暖，穿厚外套' });
    } else if (tempMin < 10) {
        advices.push({ icon: '🧥', text: '早晚温差大，注意保暖，建议带件外套' });
    }

    // 大风建议（风速单位km/h）
    if (windSpeed > 60) {
        advices.push({ icon: '💨', text: '大风预警（' + windSpeed + 'km/h），尽量避免户外活动' });
    } else if (windSpeed > 40) {
        advices.push({ icon: '💨', text: '风力较大（' + windSpeed + 'km/h），注意防风' });
    } else if (windSpeed > 25) {
        advices.push({ icon: '🌬️', text: '有一定风力（' + windSpeed + 'km/h），户外活动注意安全' });
    }

    // 紫外线建议
    if (uvIndex >= 11) {
        advices.push({ icon: '🧴', text: '紫外线极强（指数' + uvIndex + '），尽量避免外出，必须涂抹高倍防晒霜' });
    } else if (uvIndex >= 8) {
        advices.push({ icon: '🧴', text: '紫外线很强（指数' + uvIndex + '），注意涂抹防晒霜，戴帽子和墨镜' });
    } else if (uvIndex >= 6) {
        advices.push({ icon: '🧴', text: '紫外线较强（指数' + uvIndex + '），建议涂抹防晒霜' });
    } else if (uvIndex >= 3 && weatherType === 'sunny') {
        advices.push({ icon: '🧴', text: '紫外线中等，晴天户外活动建议适当防晒' });
    }

    // 降水概率较高但无明确天气类型时
    if (precipProb >= 60 && weatherType !== 'rainy' && weatherType !== 'snowy' && weatherType !== 'stormy') {
        advices.push({ icon: '☔', text: '降水概率较高（' + precipProb + '%），建议携带雨具' });
    }

    // 好天气建议（无恶劣天气时）
    if (weatherType === 'sunny' && tempMax <= 30 && tempMin >= 10 && windSpeed <= 25 && uvIndex < 6) {
        advices.push({ icon: '😎', text: '天气晴好，非常适合户外活动和拍照' });
    } else if (weatherType === 'cloudy' && tempMax <= 30 && tempMin >= 10 && windSpeed <= 25) {
        advices.push({ icon: '😊', text: '天气舒适，适合出游' });
    }

    return advices;
}

/**
 * 渲染天气卡片（适配Open-Meteo数据格式）
 * @param {Object} weatherData - 天气数据
 * @param {number} travelDays - 旅行天数
 * @param {string} destinationCity - 目的地城市
 */
function renderWeather(weatherData, travelDays, destinationCity) {
    const section = document.getElementById('weatherSection');
    const content = document.getElementById('weatherContent');

    if (!weatherData || !weatherData.casts || weatherData.casts.length === 0) {
        content.innerHTML = `
            <div class="weather-error">
                <div class="error-icon">😔</div>
                <div class="error-text">暂无${destinationCity}的天气数据</div>
            </div>
        `;
        section.style.display = 'block';
        return;
    }

    let html = '';

    // 天气卡片网格
    html += '<div class="weather-grid">';
    weatherData.casts.forEach((cast, index) => {
        const isToday = index === 0;
        const dateObj = new Date(cast.date + 'T00:00:00');
        const month = dateObj.getMonth() + 1;
        const day = dateObj.getDate();
        const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
        const weekDay = weekDays[dateObj.getDay()];
        const dateStr = month + '月' + day + '日';
        const weatherInfo = getWeatherInfo(cast.weatherCode);
        const windDir = getWindDirectionText(cast.windDirection);

        html += `
            <div class="weather-day-card ${isToday ? 'today' : ''}">
                <div class="weather-date">${dateStr}</div>
                <div class="weather-week">${weekDay}</div>
                <div class="weather-icon-row">
                    <div class="weather-icon-item">
                        <span class="icon">${weatherInfo.emoji}</span>
                        <span class="label">${weatherInfo.desc}</span>
                    </div>
                </div>
                <div class="weather-temp">
                    <span class="temp-high">${cast.tempMax}°</span>
                    <span class="temp-separator">/</span>
                    <span class="temp-low">${cast.tempMin}°</span>
                </div>
                <div class="weather-apparent-temp">
                    <span class="apparent-label">体感</span>
                    <span class="apparent-high">${cast.apparentTempMax}°</span>
                    <span class="temp-separator">/</span>
                    <span class="apparent-low">${cast.apparentTempMin}°</span>
                </div>
                <div class="weather-wind">
                    <span class="wind-icon">🌬️</span>
                    ${windDir} ${cast.windSpeed}km/h
                </div>
                <div class="weather-extra">
                    <span class="precip-info">💧${cast.precipitationProbability}%</span>
                    <span class="uv-info">☀️UV ${cast.uvIndex}</span>
                </div>
                <div class="weather-desc">${weatherInfo.desc} · 降水${cast.precipitation}mm</div>
            </div>
        `;
    });
    html += '</div>';

    // 生成出行建议（汇总所有天数的建议，去重）
    const allAdvices = [];
    const adviceSet = new Set();
    weatherData.casts.forEach(cast => {
        const dayAdvices = generateWeatherAdvice(cast);
        dayAdvices.forEach(advice => {
            if (!adviceSet.has(advice.text)) {
                adviceSet.add(advice.text);
                allAdvices.push(advice);
            }
        });
    });

    if (allAdvices.length > 0) {
        html += `
            <div class="weather-advice">
                <div class="weather-advice-title">📋 出行建议</div>
                <div class="weather-advice-list">
                    ${allAdvices.map(a => `
                        <div class="weather-advice-item">
                            <span class="advice-icon">${a.icon}</span>
                            <span>${a.text}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

// 天气预警横幅
    var warningHTML = '';
    var hasSevereWeather = false;
    weatherData.casts.forEach(function(cast) {
        var weatherType = getWeatherType(cast.weatherCode);
        if (weatherType === 'stormy' || weatherType === 'rainy' || weatherType === 'snowy') {
            hasSevereWeather = true;
        }
        if (cast.tempMax > 35 || cast.tempMin < 0) {
            hasSevereWeather = true;
        }
        if (cast.windSpeed > 40) {
            hasSevereWeather = true;
        }
    });
    if (hasSevereWeather) {
        var warnings = [];
        weatherData.casts.forEach(function(cast) {
            var dateObj = new Date(cast.date + 'T00:00:00');
            var dateStr = (dateObj.getMonth() + 1) + '月' + dateObj.getDate() + '日';
            var weatherType = getWeatherType(cast.weatherCode);
            if (weatherType === 'stormy') {
                warnings.push('⚡ ' + dateStr + '有雷暴天气，请尽量避免户外活动');
            } else if (weatherType === 'rainy' && cast.precipitationProbability >= 80) {
                warnings.push('🌧️ ' + dateStr + '降水概率' + cast.precipitationProbability + '%，请务必携带雨具');
            } else if (weatherType === 'snowy') {
                warnings.push('❄️ ' + dateStr + '有降雪，请注意保暖和防滑');
            }
            if (cast.tempMax > 35) {
                warnings.push('🌡️ ' + dateStr + '高温' + cast.tempMax + '°C，请注意防暑降温');
            }
            if (cast.tempMin < 0) {
                warnings.push('🧊 ' + dateStr + '低温' + cast.tempMin + '°C，请注意保暖防冻');
            }
            if (cast.windSpeed > 40) {
                warnings.push('💨 ' + dateStr + '大风' + cast.windSpeed + 'km/h，请注意安全');
            }
        });
        if (warnings.length > 0) {
            warningHTML = '<div class="weather-warning-banner"><div class="weather-warning-icon">⚠️</div><div class="weather-warning-content"><div class="weather-warning-title">天气预警</div><div class="weather-warning-list">' +
                warnings.slice(0, 5).map(function(w) {
                    return '<div class="weather-warning-item">' + w + '</div>';
                }).join('') +
                '</div></div></div>';
        }
    }

    content.innerHTML = warningHTML + html;
    section.style.display = 'block';
    // 显示导出按钮
    var exportSection = document.getElementById('exportSection');
    if (exportSection) exportSection.style.display = 'block';
    // 显示费用记账
    var expenseSection = document.getElementById('expenseSection');
    if (expenseSection) {
        expenseSection.style.display = 'block';
        // 清空旧费用记录，开始新旅行
        currentExpenses = [];
        saveExpensesToStorage();
        initExpenseTracker();
        updateBudgetComparison();
    }
    // 显示打包清单
    initPackingList();
    // 显示旅行回顾按钮（仅 LLM 可用时）
    var reviewSection = document.getElementById('reviewSection');
    if (reviewSection && llmAvailable) reviewSection.style.display = 'block';
}

function collapseFormToSummary(data, pace) {
    var form = document.getElementById('travelForm');
    var summaryRow = document.getElementById('planSummaryRow');
    if (!form || !summaryRow) return;

    var paceLabels = { compact: '🏃紧凑', comfort: '🚶舒适', relax: '🧘躺平' };
    var paceText = paceLabels[data.pace || pace] || '';
    var prefs = (data.preferences || []).map(function(p) {
        var map = { nature: '🌲', history: '🏛️', food: '🍜', instagram: '📸' };
        return map[p] || '';
    }).join('');

    document.getElementById('planSummaryText').innerHTML =
        '<strong>' + data.departureCity + ' → ' + data.destinationCity + '</strong>'
        + ' · ' + data.travelDate
        + ' · ' + data.travelDays + '天'
        + ' · ¥' + data.budget.toLocaleString()
        + (paceText ? ' · ' + paceText : '')
        + (prefs ? ' · ' + prefs : '');

    form.style.display = 'none';
    summaryRow.style.display = 'flex';
}

function showEditForm() {
    var form = document.getElementById('travelForm');
    var summaryRow = document.getElementById('planSummaryRow');
    if (!form || !summaryRow) return;
    form.style.display = '';
    summaryRow.style.display = 'none';
}


// ========================================
// 地图路线可视化
// ========================================

var currentRouteLines = []; // 存储当前显示的路线

/**
 * 清除地图上已有的路线
 */
function clearRouteLines() {
    currentRouteLines.forEach(function(line) {
        mapPickerMap.remove(line);
    });
    currentRouteLines = [];
}

/**
 * 在地图上绘制驾车路线
 * @param {Array} start - [lng, lat]
 * @param {Array} end - [lng, lat]
 * @param {string} color - 路线颜色
 */
function drawDrivingRoute(start, end, color) {
    clearRouteLines();
    var driving = new AMap.Driving({
        policy: AMap.DrivingPolicy.LEAST_TIME
    });
    driving.search(new AMap.LngLat(start[0], start[1]), new AMap.LngLat(end[0], end[1]), function(status, result) {
        if (status === 'complete') {
            // 获取路线路径点并绘制
            var path = [];
            result.routes[0].steps.forEach(function(step) {
                step.path.forEach(function(p) {
                    path.push(p);
                });
            });
            var polyline = new AMap.Polyline({
                path: path,
                strokeColor: color || '#10b981',
                strokeWeight: 5,
                strokeOpacity: 0.8,
                showDir: true,
                lineJoin: 'round'
            });
            polyline.setMap(mapPickerMap);
            currentRouteLines.push(polyline);
            // 调整视野
            mapPickerMap.setFitView([polyline, departureMarker, destinationMarker], true, [60, 60, 60, 60]);
        } else {
            // 驾车路线规划失败（距离太远），回退到直线
            drawFlightRoute(start, end, color);
        }
    });
}

/**
 * 在地图上绘制公交/火车路线
 * @param {Array} start - [lng, lat]
 * @param {Array} end - [lng, lat]
 * @param {string} color - 路线颜色
 */
function drawTransferRoute(start, end, color) {
    clearRouteLines();
    var transfer = new AMap.Transfer({
        policy: AMap.TransferPolicy.LEAST_TIME,
        city: window._routeDepCity || '北京市',
        cityd: window._routeDestCity || '成都市'
    });
    transfer.search(new AMap.LngLat(start[0], start[1]), new AMap.LngLat(end[0], end[1]), function(status, result) {
        if (status === 'complete') {
            var path = [];
            result.plans[0].path.forEach(function(p) {
                path.push(p);
            });
            var polyline = new AMap.Polyline({
                path: path,
                strokeColor: color || '#f59e0b',
                strokeWeight: 5,
                strokeOpacity: 0.8,
                showDir: true,
                lineJoin: 'round'
            });
            polyline.setMap(mapPickerMap);
            currentRouteLines.push(polyline);
            mapPickerMap.setFitView([polyline, departureMarker, destinationMarker], true, [60, 60, 60, 60]);
        } else {
            // Transfer只支持同城公交，跨省长途会失败
            // 回退到驾车路线近似（国内高铁和高速公路走向大致相同）
            drawDrivingRoute(start, end, color);
        }
    });
}

/**
 * 在地图上绘制飞机直线（大圆航线示意）
 * @param {Array} start - [lng, lat]
 * @param {Array} end - [lng, lat]
 * @param {string} color - 路线颜色
 */
function drawFlightRoute(start, end, color) {
    clearRouteLines();
    var polyline = new AMap.Polyline({
        path: [new AMap.LngLat(start[0], start[1]), new AMap.LngLat(end[0], end[1])],
        strokeColor: color || '#6366f1',
        strokeWeight: 4,
        strokeOpacity: 0.8,
        strokeStyle: 'dashed',
        lineJoin: 'round'
    });
    polyline.setMap(mapPickerMap);
    currentRouteLines.push(polyline);
    // 添加飞机图标在路线上
    var midLng = (start[0] + end[0]) / 2;
    var midLat = (start[1] + end[1]) / 2;
    var planeMarker = new AMap.Marker({
        position: [midLng, midLat],
        content: '<div style="font-size:24px;">✈️</div>',
        offset: new AMap.Pixel(-12, -12),
        zIndex: 100
    });
    planeMarker.setMap(mapPickerMap);
    currentRouteLines.push(planeMarker);
    mapPickerMap.setFitView([polyline, departureMarker, destinationMarker], true, [60, 60, 60, 60]);
}

/**
 * 根据路线类型调用对应的绘制函数
 * @param {string} routeType - 路线类型：flight/train/driving/transfer
 * @param {Array} start - [lng, lat]
 * @param {Array} end - [lng, lat]
 */
function drawRouteByType(routeType, start, end) {
    var colorMap = {
        'flight': '#6366f1',
        'train': '#f59e0b',
        'driving': '#10b981',
        'transfer': '#3b82f6'
    };
    var color = colorMap[routeType] || '#6366f1';
    try {
        if (routeType === 'driving' || routeType === 'train') {
            // 火车路线用驾车路线近似（国内高铁和高速公路走向大致相同）
            drawDrivingRoute(start, end, color);
        } else if (routeType === 'flight') {
            drawFlightRoute(start, end, color);
        } else if (routeType === 'transfer') {
            drawTransferRoute(start, end, color);
        }
    } catch (e) {
        // 路线绘制失败时静默处理，不报错
    }
}

/**
 * 用户点击交通方案卡片时的处理函数
 * @param {HTMLElement} card - 被点击的卡片元素
 */
function selectTransportPlan(card) {
    // 移除所有卡片的高亮样式
    document.querySelectorAll('.transport-option-card').forEach(function(c) {
        c.classList.remove('active');
    });
    // 为当前点击的卡片添加高亮样式
    card.classList.add('active');

    var routeType = card.dataset.routeType;
    var startLng = parseFloat(card.dataset.startLng);
    var startLat = parseFloat(card.dataset.startLat);
    var endLng = parseFloat(card.dataset.endLng);
    var endLat = parseFloat(card.dataset.endLat);

    if (!startLng || !startLat || !endLng || !endLat) return;

    drawRouteByType(routeType, [startLng, startLat], [endLng, endLat]);
}


// ========================================
// 历史记录持久化
// ========================================

/**
 * 保存当前规划到历史记录
 */
function savePlanToHistory(formData) {
    try {
        var records = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');

        // 精简天气数据：只保留前5天
        var weatherData = window._lastWeatherData || null;
        if (weatherData && weatherData.casts && weatherData.casts.length > 5) {
            weatherData = JSON.parse(JSON.stringify(weatherData));
            weatherData.casts = weatherData.casts.slice(0, 5);
        }

        var record = {
            id: Date.now(),
            version: '2',
            timestamp: Date.now(),
            dateStr: new Date().toLocaleString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
            tags: [],
            formData: {
                departureCity: formData.departureCity,
                destinationCity: formData.destinationCity,
                travelDate: formData.travelDate,
                travelDays: formData.travelDays,
                budget: formData.budget,
                preferences: formData.preferences,
                pace: formData.pace || 'compact',
                departureLng: formData.departureLng,
                departureLat: formData.departureLat,
                destinationLng: formData.destinationLng,
                destinationLat: formData.destinationLat
            },
            transportData: window._lastTransportData || null,
            weatherData: weatherData,
            attractionsData: window._lastAttractionsData || null,
            hotelsData: window._lastHotelsData || null
        };

        // 去重
        var dupIndex = records.findIndex(function(r) {
            return r.formData.departureCity === record.formData.departureCity &&
                r.formData.destinationCity === record.formData.destinationCity &&
                r.formData.travelDate === record.formData.travelDate &&
                r.formData.travelDays === record.formData.travelDays &&
                r.formData.budget === record.formData.budget;
        });
        if (dupIndex !== -1) {
            records.splice(dupIndex, 1);
        }

        records.unshift(record);
        if (records.length > MAX_HISTORY) records.pop();

        localStorage.setItem(HISTORY_KEY, JSON.stringify(records));
        renderHistoryList();
    } catch (e) {
        console.warn('保存历史记录失败:', e);
    }
}

/**
 * 加载历史记录列表
 */
function loadHistory() {
    try {
        return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    } catch (e) {
        return [];
    }
}

/**
 * 渲染历史记录列表
 */
function renderHistoryList() {
    const container = document.getElementById('historyList');
    const section = document.getElementById('historySection');
    if (!container || !section) {
        setTimeout(renderHistoryList, 100);
        return;
    }

    const records = loadHistory();
    if (records.length === 0) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';
    container.innerHTML = '<div class="history-search-bar">' +
        '<input type="text" class="history-search-input" id="historySearchInput" placeholder="搜索历史记录..." oninput="filterHistoryList()">' +
        '<div class="history-tag-filters">' +
            '<button class="history-tag-filter active" data-tag="all" onclick="filterHistoryList()">全部</button>' +
            '<button class="history-tag-filter" data-tag="已出行" onclick="filterHistoryList()">✅ 已出行</button>' +
            '<button class="history-tag-filter" data-tag="收藏" onclick="filterHistoryList()">⭐ 收藏</button>' +
            '<button class="history-tag-filter" data-tag="备选" onclick="filterHistoryList()">📋 备选</button>' +
        '</div>' +
    '</div>' +
    '<div class="history-items-container" id="historyItemsContainer"></div>';

    filterHistoryList();
}

function filterHistoryList() {
    var itemsContainer = document.getElementById('historyItemsContainer');
    if (!itemsContainer) return;

    var records = loadHistory();
    var searchText = (document.getElementById('historySearchInput') || {}).value || '';
    searchText = searchText.toLowerCase().trim();

    var activeTagBtn = document.querySelector('.history-tag-filter.active');
    var activeTag = activeTagBtn ? activeTagBtn.getAttribute('data-tag') : 'all';

    // 更新标签按钮active状态
    document.querySelectorAll('.history-tag-filter').forEach(function(btn) {
        btn.classList.toggle('active', btn.getAttribute('data-tag') === activeTag);
    });

    // 过滤
    var filtered = records.filter(function(r) {
        // 标签过滤
        if (activeTag !== 'all') {
            if (!r.tags || r.tags.indexOf(activeTag) === -1) return false;
        }
        // 搜索过滤
        if (searchText) {
            var displayName = (r.customName || (r.formData.departureCity + ' ' + r.formData.destinationCity)).toLowerCase();
            if (displayName.indexOf(searchText) === -1 && r.formData.departureCity.toLowerCase().indexOf(searchText) === -1 && r.formData.destinationCity.toLowerCase().indexOf(searchText) === -1) {
                return false;
            }
        }
        return true;
    });

    itemsContainer.innerHTML = filtered.map(function(r) {
        var prefs = r.formData.preferences.map(function(p) {
            var map = { nature: '🌲', history: '🏛️', food: '🍜', instagram: '📸' };
            return map[p] || '';
        }).join('');
        var displayName = r.customName || (r.formData.departureCity + ' → ' + r.formData.destinationCity);
        var currentTag = (r.tags && r.tags.length > 0) ? r.tags[0] : '';

        return '<div class="history-item" data-id="' + r.id + '">' +
            '<div class="history-info" onclick="restorePlan(' + r.id + ')">' +
                '<div class="history-route">' + displayName + '</div>' +
                '<div class="history-meta">' + r.formData.travelDate + ' · ' + r.formData.travelDays + '天 · ¥' + r.formData.budget + ' ' + prefs + '</div>' +
                '<div class="history-time">' + r.dateStr + '</div>' +
            '</div>' +
            '<div class="history-actions">' +
                '<select class="history-tag-select" onchange="event.stopPropagation();setHistoryTag(' + r.id + ', this.value)" title="设置标签">' +
                    '<option value="">🏷️</option>' +
                    '<option value="已出行"' + (currentTag === '已出行' ? ' selected' : '') + '>✅ 已出行</option>' +
                    '<option value="收藏"' + (currentTag === '收藏' ? ' selected' : '') + '>⭐ 收藏</option>' +
                    '<option value="备选"' + (currentTag === '备选' ? ' selected' : '') + '>📋 备选</option>' +
                '</select>' +
                '<button class="history-rename" onclick="event.stopPropagation();renameHistoryItem(' + r.id + ')" title="重命名">✏️</button>' +
                '<button class="history-delete" onclick="event.stopPropagation();deleteHistoryItem(' + r.id + ')" title="删除">×</button>' +
            '</div>' +
        '</div>';
    }).join('');
}

function setHistoryTag(id, tag) {
    var records = loadHistory();
    var record = records.find(function(r) { return r.id === id; });
    if (!record) return;
    record.tags = tag ? [tag] : [];
    localStorage.setItem(HISTORY_KEY, JSON.stringify(records));
    filterHistoryList();
}

function getHistoryRecords() {
    var rawRecords = loadHistory();
    return rawRecords.map(function(r) {
        var fd = r.formData || {};
        return {
            id: r.id,
            name: (fd.departureCity || '?') + ' → ' + (fd.destinationCity || '?'),
            dateStr: r.dateStr || '',
            timestamp: r.timestamp || 0,
            formData: fd,
            attractionsData: r.attractionsData || [],
            hotelsData: r.hotelsData || [],
            transportData: r.transportData || null,
            weatherData: r.weatherData || null
        };
    });
}

/**
 * 恢复历史规划
 */
function restorePlan(id) {
    var records = loadHistory();
    var record = records.find(function(r) { return r.id === id; });
    if (!record) return;

    var fd = record.formData;

    // 版本检查：旧格式记录（无version或version < '2'）只恢复表单数据
    if (!record.version || record.version < '2') {
        alert('该历史记录为旧格式，已自动恢复表单数据，请重新点击"开始规划"生成结果。');
        fillFormFromRecord(fd);
        return;
    }

    // 填入表单数据
    fillFormFromRecord(fd);

    var welcomeTip = document.querySelector('.welcome-tip');
    if (welcomeTip) welcomeTip.style.display = 'none';
    hideWelcomeTip();

    // 获取目的地数据
    var di = getDestinationData(fd.destinationCity);
    var travelDays = parseInt(fd.travelDays);
    var budget = parseInt(fd.budget);
    var preferences = fd.preferences;

    // 1. 天气：优先使用缓存数据
    if (record.weatherData) {
        renderWeather(record.weatherData, travelDays, fd.destinationCity);
    } else {
        var weatherSection = document.getElementById('weatherSection');
        var weatherContent = document.getElementById('weatherContent');
        if (weatherSection) weatherSection.style.display = 'block';
        if (weatherContent) weatherContent.innerHTML = '<div class="weather-loading"><div class="loading-icon">🌤️</div><div>正在获取天气数据...</div></div>';
        fetchWeather(fd.destinationCity, fd.destinationLng, fd.destinationLat, travelDays)
            .then(function(weatherData) {
                window._lastWeatherData = weatherData;
                renderWeather(weatherData, travelDays, fd.destinationCity);
            })
            .catch(function(err) {
                console.error('获取天气失败:', err);
                if (weatherContent) weatherContent.innerHTML = '<div class="weather-error"><div class="error-icon">😔</div><div class="error-text">获取天气数据失败</div><button class="retry-btn" onclick="location.reload()">↻ 重试</button></div>';
            });
    }

    // 2. 交通：优先使用缓存数据
    if (record.transportData && record.transportData.plans) {
        window._lastTransportData = record.transportData;
        renderTransportNew(record.transportData.plans);
        window._routeStartLng = parseFloat(fd.departureLng);
        window._routeStartLat = parseFloat(fd.departureLat);
        window._routeEndLng = parseFloat(fd.destinationLng);
        window._routeEndLat = parseFloat(fd.destinationLat);
        window._routeDepCity = fd.departureCity;
        window._routeDestCity = fd.destinationCity;
    }

    // 3. 酒店：先生成（供预算使用真实价格）
    var hotelRecommendations = null;
    if (record.hotelsData) {
        hotelRecommendations = record.hotelsData;
        renderHotels(record.hotelsData);
    } else {
        hotelRecommendations = generateHotelRecommendations(fd.destinationCity, budget, travelDays);
        renderHotels(hotelRecommendations);
    }

    // 4. 预算：重新计算并渲染（传入酒店和景点数据）
    var recommendTransportCost = null;
    if (record.transportData && record.transportData.plans && record.transportData.plans.length > 0) {
        var recommendPlan = record.transportData.plans.find(function(p) { return p.recommend; }) || record.transportData.plans[0];
        recommendTransportCost = recommendPlan.cost;
    }
    var cachedAttractions = record.attractionsData || null;
    renderBudgetChart(calculateBudgetAllocation(budget, travelDays, fd.destinationCity, recommendTransportCost, hotelRecommendations, cachedAttractions), budget);

    // 5. 美食：重新渲染
    if (di && di.foods) {
        renderFoods(di.foods.slice(0, 5), fd.destinationCity, fd.destinationLng, fd.destinationLat);
    }

    // 6. 景点：优先使用缓存，否则重新获取
    if (record.attractionsData) {
        renderAttractions(record.attractionsData);
    } else if (fd.destinationLng && fd.destinationLat) {
        searchAttractionsByAmap(fd.destinationCity, fd.destinationLng, fd.destinationLat).then(function(realAttractions) {
            if (realAttractions && realAttractions.length > 0) {
                window._lastAttractionsData = realAttractions;
                renderAttractions(realAttractions);
                updateBudgetTickets(realAttractions, budget, travelDays, fd.destinationCity, recommendTransportCost, hotelRecommendations);
            } else {
                renderAttractions(filterAttractions(di.attractions, preferences));
            }
        }).catch(function() {
            renderAttractions(filterAttractions(di.attractions, preferences));
        });
    } else {
        renderAttractions(filterAttractions(di.attractions, preferences));
    }

    // 7. 行程：重新生成
    if (di) {
        renderItinerary(generateItinerary(di, travelDays, fd.pace || 'compact'));
    }

    // 折叠左侧表单为摘要
    collapseFormToSummary(fd, fd.pace || 'compact');

    // 重置卡片折叠状态：只展开行程和预算
    resetCollapsibleCards();

    // 移动端：自动切换到行程标签
    if (window.matchMedia('(max-width: 640px)').matches && window._switchMobileTab) {
        window._switchMobileTab('itinerarySection');
    }

    // 滚动到结果区域
    var resultSection = document.getElementById('resultSection');
    if (resultSection) resultSection.scrollTop = 0;
    setTimeout(function() {
        var ws = document.getElementById('weatherSection');
        if (ws && ws.style.display !== 'none') {
            ws.scrollIntoView({behavior: 'smooth', block: 'start'});
        }
    }, 300);

    // 恢复地图标记
    setTimeout(function() {
        clearRouteLines();
        if (mapPickerMap && departureMarker && fd.departureLng && fd.departureLat) {
            departureMarker.setPosition([fd.departureLng, fd.departureLat]);
        }
        if (mapPickerMap && destinationMarker && fd.destinationLng && fd.destinationLat) {
            destinationMarker.setPosition([fd.destinationLng, fd.destinationLat]);
            mapPickerMap.setFitView([departureMarker, destinationMarker], true, [100, 100, 100, 100]);
        }
    }, 500);
}

function fillFormFromRecord(fd) {
    document.getElementById('departureCity').value = fd.departureCity;
    document.getElementById('departureLng').value = fd.departureLng || '';
    document.getElementById('departureLat').value = fd.departureLat || '';
    document.getElementById('destinationCity').value = fd.destinationCity;
    document.getElementById('destinationLng').value = fd.destinationLng || '';
    document.getElementById('destinationLat').value = fd.destinationLat || '';
    document.getElementById('travelDate').value = fd.travelDate;
    document.getElementById('travelDays').value = fd.travelDays;
    document.getElementById('budget').value = fd.budget;

    var depInput = document.getElementById('departureInput');
    var destInput = document.getElementById('destinationInput');
    if (depInput) depInput.innerHTML = '<span class="city-value">' + (fd.departureCity ? '📍 ' + fd.departureCity : '') + '</span>';
    if (destInput) destInput.innerHTML = '<span class="city-value">' + (fd.destinationCity || '') + '</span>';

    document.querySelectorAll('input[name="preference"]').forEach(function(cb) {
        cb.checked = (fd.preferences || []).indexOf(cb.value) !== -1;
    });

    // 恢复行程节奏
    if (fd.pace) {
        var paceRadio = document.querySelector('input[name="pace"][value="' + fd.pace + '"]');
        if (paceRadio) {
            paceRadio.checked = true;
            document.querySelectorAll('.pace-label').forEach(function(l) { l.classList.remove('active'); });
            var paceLabel = paceRadio.closest('.pace-label');
            if (paceLabel) paceLabel.classList.add('active');
        }
    }
}

function rebindAttractionClicks(destCity, preferences) {
    var di = getDestinationData(destCity);
    if (!di || !di.attractions) return;
    
    var attractions = filterAttractions(di.attractions, preferences);
    window._currentAttractions = attractions;
    
    var listEl = document.getElementById('attractionsList');
    if (!listEl) return;
    
    listEl.innerHTML = attractions.map(function(at, i) {
        return '<div class="attraction-item" onclick="openAttractionDetail(' + i + ')">' +
            '<div class="attraction-badge"><span class="rating">' + at.rating + '</span><span class="max-rating">/5</span></div>' +
            '<div class="attraction-info">' +
            '<div class="attraction-name">' + (i+1) + '. ' + at.name + '</div>' +
            '<div class="attraction-desc">' + at.desc + '</div>' +
            '<div class="attraction-tags">' + at.tags.map(function(t) { return '<span class="tag">' + t + '</span>'; }).join('') + '</div>' +
            '</div>' +
            '<div class="attraction-price">' + (at.price===0?'免费':'¥'+at.price) + (at.price>0?'<div class="unit">/人</div>':'') + '</div>' +
            '<div class="attraction-arrow">→</div>' +
            '</div>';
    }).join('');
    
    document.getElementById('attractionsSection').style.display = 'block';
}

/**
 * 删除单条历史记录
 */
function deleteHistory(id, event) {
    if (event) event.stopPropagation();
    if (!confirm('确定删除这条规划记录？')) return;

    try {
        let records = loadHistory();
        records = records.filter(r => r.id !== id);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(records));
        renderHistoryList();
    } catch (e) {
        console.warn('删除历史记录失败:', e);
    }
}

/**
 * 清空全部历史记录
 */
function deleteHistoryItem(id) {
    var records = loadHistory();
    var record = records.find(function(r) { return r.id === id; });
    if (!record) return;
    var label = record.formData.departureCity + ' → ' + record.formData.destinationCity;
    if (!confirm('确定删除记录：' + label + '？')) return;
    records = records.filter(function(r) { return r.id !== id; });
    localStorage.setItem(HISTORY_KEY, JSON.stringify(records));
    renderHistoryList();
}

function renameHistoryItem(id) {
    var records = loadHistory();
    var record = records.find(function(r) { return r.id === id; });
    if (!record) return;
    var newName = prompt('给这次旅行起个名字：', record.customName || '');
    if (newName === null) return;
    if (newName.trim() === '') {
        delete record.customName;
    } else {
        record.customName = newName.trim();
    }
    localStorage.setItem(HISTORY_KEY, JSON.stringify(records));
    renderHistoryList();
}

function clearHistory() {
    if (!confirm('确定清空所有历史规划记录？此操作不可恢复。')) return;
    localStorage.removeItem(HISTORY_KEY);
    renderHistoryList();
}

function exportPlan() {
    var depCity = document.getElementById('departureCity').value || '未知';
    var destCity = document.getElementById('destinationCity').value || '未知';
    var travelDate = document.getElementById('travelDate').value || '';
    var travelDays = document.getElementById('travelDays').value || '';
    var budget = document.getElementById('budget').value || '';

    var text = '\u2708\ufe0f \u2605 \u6211\u7684\u65c5\u884c\u8ba1\u5212 \u2605 \u2708\ufe0f\n';
    text += '\u2501'.repeat(20) + '\n\n';
    text += '\ud83d\udccd \u51fa\u53d1\u5730\uff1a' + depCity + '\n';
    text += '\ud83d\udccd \u76ee\u7684\u5730\uff1a' + destCity + '\n';
    text += '\ud83d\udcc5 \u65e5\u671f\uff1a' + travelDate + ' \u00b7 ' + travelDays + '\u5929\n';
    text += '\ud83d\udcb0 \u9884\u7b97\uff1a\u00a5' + budget + '\n\n';

    var transportSummary = document.getElementById('transportSummary');
    if (transportSummary && transportSummary.textContent.trim()) {
        text += '\ud83d\ude86 \u4ea4\u901a\u5efa\u8bae\uff1a\n' + transportSummary.textContent.trim().replace(/\s+/g, ' ') + '\n\n';
    }

    var attrs = document.querySelectorAll('.attraction-item');
    if (attrs.length > 0) {
        text += '\ud83c\udfd4\ufe0f \u666f\u70b9\u63a8\u8350\uff1a\n';
        attrs.forEach(function(a, i) {
            var name = a.querySelector('.attraction-name');
            var price = a.querySelector('.attraction-price');
            if (name) {
                text += '  ' + (i + 1) + '. ' + name.textContent.trim();
                if (price) text += ' (' + price.textContent.trim() + ')';
                text += '\n';
            }
        });
        text += '\n';
    }

    var foods = document.querySelectorAll('.food-item');
    if (foods.length > 0) {
        text += '\ud83c\udf5c \u7f8e\u98df\u63a8\u8350\uff1a\n';
        foods.forEach(function(f) {
            var name = f.querySelector('.food-name');
            var price = f.querySelector('.food-price');
            if (name) {
                text += '  \u2022 ' + name.textContent.replace(/\s*\(.*?\)\s*/, '').trim();
                if (price) text += ' ' + price.textContent.trim();
                text += '\n';
            }
        });
        text += '\n';
    }

    var weatherCards = document.querySelectorAll('.weather-day-card');
    if (weatherCards.length > 0) {
        text += '\u2600\ufe0f \u5929\u6c14\u9884\u62a5\uff1a\n';
        weatherCards.forEach(function(c) {
            var date = c.querySelector('.weather-date');
            var week = c.querySelector('.weather-week');
            var icon = c.querySelector('.weather-icon-item .icon');
            var label = c.querySelector('.weather-icon-item .label');
            var temp = c.querySelector('.weather-temp');
            if (date && icon) {
                text += '  ' + date.textContent + ' ' + (week ? week.textContent : '') + ' ' + icon.textContent + ' ' + (label ? label.textContent : '') + ' ' + (temp ? temp.textContent.trim() : '') + '\n';
            }
        });
        text += '\n';
    }

    text += '\u2501'.repeat(20) + '\n';
    text += '\ud83e\udd16 \u7531 TRAE AI \u65c5\u6e38\u89c4\u5212\u52a9\u624b\u751f\u6210\n';

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function() {
            showToast('\u2705 \u884c\u7a0b\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f\uff01');
        }).catch(function() {
            showToast('\u274c \u590d\u5236\u5931\u8d25\uff0c\u8bf7\u624b\u52a8\u590d\u5236');
        });
    } else {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            showToast('\u2705 \u884c\u7a0b\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f\uff01');
        } catch (e) {
            showToast('\u274c \u590d\u5236\u5931\u8d25\uff0c\u8bf7\u624b\u52a8\u590d\u5236');
        }
        document.body.removeChild(textarea);
    }
}

function showToast(message) {
    var existing = document.querySelector('.toast-message');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(function() {
        toast.classList.add('toast-hide');
        setTimeout(function() { toast.remove(); }, 300);
    }, 2500);
}
// ========================================
// 全局错误提示
// ========================================
function showErrorToast(message, retryFn) {
    var existing = document.querySelector('.error-toast');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.className = 'error-toast';
    var html = '<div class="error-toast-icon">' + '⚠️' + '</div>' +
        '<div class="error-toast-text">' + message + '</div>';
    if (retryFn) {
        html += '<button class="error-toast-retry">' + '重试' + '</button>';
    }
    toast.innerHTML = html;
    if (retryFn) {
        toast.querySelector('.error-toast-retry').addEventListener('click', function() {
            toast.remove();
            retryFn();
        });
    }
    document.body.appendChild(toast);
    setTimeout(function() {
        toast.classList.add('toast-hide');
        setTimeout(function() { toast.remove(); }, 300);
    }, 5000);
}

window.addEventListener('error', function(e) {
    console.error('全局错误:', e.message);
    if (e.target && e.target.tagName === 'IMG') {
        showErrorToast('图片加载失败：' + e.target.src);
    }
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('未处理的 Promise 错误:', e.reason);
    showErrorToast('操作失败，请稍后重试');
});

// ========================================
// 费用记账
// ========================================
var EXPENSE_KEY = 'travel_planner_expenses';
var currentExpenses = [];
var llmAvailable = false; // 由 checkLLMAvailability 异步更新，默认隐藏 reviewSection

function initExpenseTracker() {
    loadExpenses();
    renderExpenseList();
    updateBudgetComparison();
}

function loadExpenses() {
    try {
        var saved = JSON.parse(localStorage.getItem(EXPENSE_KEY) || '[]');
        currentExpenses = saved;
        renderExpenseList();
        updateBudgetComparison();
    } catch (e) { currentExpenses = []; }
}

function saveExpensesToStorage() {
    try {
        localStorage.setItem(EXPENSE_KEY, JSON.stringify(currentExpenses));
    } catch (e) { console.warn('Save expenses failed:', e); }
}

function getTotalSpent() {
    return currentExpenses.reduce(function(sum, e) { return sum + (parseFloat(e.amount) || 0); }, 0);
}

function getSpentByCategory() {
    var map = {};
    currentExpenses.forEach(function(e) {
        var cat = e.category || '其他';
        map[cat] = (map[cat] || 0) + (parseFloat(e.amount) || 0);
    });
    return map;
}

function addExpense() {
    var category = document.getElementById('expenseCategory').value;
    var amountInput = document.getElementById('expenseAmount');
    var note = document.getElementById('expenseNote').value.trim();
    var amount = parseFloat(amountInput.value);

    if (!category) { showErrorToast('请选择费用类别'); return; }
    if (!amount || amount <= 0) { showErrorToast('请输入有效的金额'); return; }

    var expense = {
        id: Date.now(),
        category: category,
        amount: amount,
        note: note || category,
        time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    };

    currentExpenses.push(expense);
    saveExpensesToStorage();
    renderExpenseList();
    updateBudgetComparison();

    // 清空输入
    amountInput.value = '';
    document.getElementById('expenseNote').value = '';
    document.getElementById('expenseCategory').value = '';
}

function deleteExpense(id) {
    currentExpenses = currentExpenses.filter(function(e) { return e.id !== id; });
    saveExpensesToStorage();
    renderExpenseList();
    updateBudgetComparison();
}

function clearExpenses() {
    if (confirm('确定要清空所有记账记录吗？')) {
        currentExpenses = [];
        saveExpensesToStorage();
        renderExpenseList();
        updateBudgetComparison();
    }
}

function renderExpenseList() {
    var list = document.getElementById('expenseList');
    if (!list) return;

    if (currentExpenses.length === 0) {
        list.innerHTML = '<div class="expense-empty">还没有记账，添加一笔吧 ✏️</div>';
        return;
    }

    var categoryEmoji = { '住宿': '🏨', '交通': '🚗', '餐饮': '🍜', '门票': '🎫', '购物': '🛍️', '其他': '📦' };

    list.innerHTML = currentExpenses.slice().reverse().map(function(e) {
        return '<div class="expense-item">' +
            '<span class="expense-cat">' + (categoryEmoji[e.category] || '📦') + ' ' + e.category + '</span>' +
            '<span class="expense-note">' + e.note + '</span>' +
            '<span class="expense-amount">¥' + e.amount.toLocaleString() + '</span>' +
            '<span class="expense-time">' + (e.time || '') + '</span>' +
            '<button class="expense-delete" onclick="deleteExpense(' + e.id + ')">×</button>' +
        '</div>';
    }).join('') +
    '<div class="expense-actions-bar">' +
        '<button class="expense-clear-btn" onclick="clearExpenses()">清空记录</button>' +
    '</div>';
}

function updateBudgetComparison() {
    var totalBudget = parseInt(document.getElementById('budget').value) || 5000;
    var totalSpent = getTotalSpent();
    var remaining = totalBudget - totalSpent;
    var percent = Math.min(100, Math.round((totalSpent / totalBudget) * 100));

    var spentByCat = getSpentByCategory();

    // 更新 expenseSummary 汇总
    var summary = document.getElementById('expenseSummary');
    if (summary) {
        var statusColor = percent > 90 ? '#ef4444' : (percent > 60 ? '#f59e0b' : '#10b981');
        summary.innerHTML =
            '<div class="expense-summary-row">' +
                '<div class="expense-summary-item">' +
                    '<div class="es-label">已花费</div>' +
                    '<div class="es-value" style="color:' + statusColor + '">¥' + totalSpent.toLocaleString() + '</div>' +
                '</div>' +
                '<div class="expense-summary-item">' +
                    '<div class="es-label">剩余</div>' +
                    '<div class="es-value">¥' + Math.max(0, remaining).toLocaleString() + '</div>' +
                '</div>' +
                '<div class="expense-summary-item">' +
                    '<div class="es-label">预算</div>' +
                    '<div class="es-value">¥' + totalBudget.toLocaleString() + '</div>' +
                '</div>' +
            '</div>' +
            '<div class="expense-progress">' +
                '<div class="expense-progress-bar">' +
                    '<div class="expense-progress-fill" style="width:' + percent + '%; background:' + statusColor + '"></div>' +
                '</div>' +
                '<span class="expense-progress-text" style="color:' + statusColor + '">' + percent + '%</span>' +
            '</div>' +
            (remaining < 0 ? '<div class="expense-overbudget">⚠️ 已超预算 ¥' + Math.abs(remaining).toLocaleString() + '</div>' : '');
    }

    // 在 budgetDetails 下方追加对比表
    var details = document.getElementById('budgetDetails');
    if (details && Object.keys(spentByCat).length > 0) {
        var oldComparison = details.querySelector('.budget-comparison');
        if (oldComparison) oldComparison.remove();

        var comparisonHTML = '<div class="budget-comparison"><div class="comparison-title-small">💡 实际花费 vs 预算分配</div>';
        var categoryBudget = { '交通': 0.25, '住宿': 0.30, '餐饮': 0.20, '门票': 0.15, '其他': 0.10 };
        Object.keys(spentByCat).forEach(function(cat) {
            var spent = spentByCat[cat];
            var budgetForCat = Math.round(totalBudget * (categoryBudget[cat] || 0.10));
            var overBudget = spent > budgetForCat;
            comparisonHTML += '<div class="comp-row">' +
                '<span class="comp-cat">' + cat + '</span>' +
                '<span class="comp-spent' + (overBudget ? ' over' : '') + '">¥' + spent.toLocaleString() + '</span>' +
                '<span class="comp-budget">/ ¥' + budgetForCat.toLocaleString() + '</span>' +
                (overBudget ? '<span class="comp-warn">超支</span>' : '') +
            '</div>';
        });
        comparisonHTML += '</div>';
        details.appendChild(createElementFromHTML(comparisonHTML));
    }
}

function createElementFromHTML(html) {
    var div = document.createElement('div');
    div.innerHTML = html.trim();
    return div.firstChild;
}


function generateTripReview() {
    var reviewSection = document.getElementById('reviewSection');
    var reviewContent = reviewSection.querySelector('.review-content') || null;

    // 如果没有 review-content 容器，创建一个
    if (!reviewContent) {
        reviewContent = document.createElement('div');
        reviewContent.className = 'review-content';
        reviewSection.appendChild(reviewContent);
    }

    reviewContent.innerHTML = '<div class="review-loading">✍️ AI 正在为你生成旅行回顾...</div>';

    // 收集当前规划数据
    var destCity = document.getElementById('destinationCity').value || '目的地';
    var days = parseInt(document.getElementById('travelDays').value) || 3;
    var pace = (document.querySelector('input[name="pace"]:checked') || {}).value || 'compact';
    var budget = parseInt(document.getElementById('budget').value) || 5000;

    // 获取景点名称
    var attractionNames = [];
    if (window._currentAttractions) {
        attractionNames = window._currentAttractions.map(function(a) { return a.name; });
    }

    // 获取美食名称
    var foodNames = [];
    var foodItems = document.querySelectorAll('.food-item .food-name');
    foodItems.forEach(function(el) { foodNames.push(el.textContent.trim()); });
    if (foodNames.length === 0) {
        var di = getDestinationData(destCity);
        if (di && di.foods) foodNames = di.foods.map(function(f) { return f.name; });
    }

    // 获取天气信息
    var weatherStr = '未知';
    if (window._lastWeatherData && window._lastWeatherData.casts && window._lastWeatherData.casts.length > 0) {
        var w = window._lastWeatherData.casts[0];
        weatherStr = (w.weatherDesc || w.dayweather || '未知') + '，' + (w.tempMin || 0) + '°C ~ ' + (w.tempMax || 0) + '°C';
    }

    // 请求后端
    fetch('/api/generate-review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            city: destCity,
            days: days,
            pace: pace,
            attractions: attractionNames.slice(0, 8),
            foods: foodNames.slice(0, 5),
            weather: weatherStr,
            budget: budget
        })
    })
    .then(function(resp) {
        if (!resp.ok) {
            // 503 = LLM 未配置，其他状态码也返回错误信息
            return resp.json().then(function(d) {
                throw new Error(d.error || '服务暂不可用（HTTP ' + resp.status + '）');
            });
        }
        return resp.json();
    })
    .then(function(data) {
        if (data.success && data.review) {
            reviewContent.innerHTML = '<div class="review-text">' + data.review.replace(/\n/g, '<br>') + '</div>';
        } else {
            reviewContent.innerHTML = '<div class="review-error">' + (data.error || '生成失败，请确认已配置 LLM_API_KEY') + '</div>';
        }
    })
    .catch(function(err) {
        console.error('Review failed:', err);
        var msg = err.message || '网络请求失败';
        // 如果后端返回了具体错误原因，直接展示
        if (msg.indexOf('LLM') > -1 || msg.indexOf('API') > -1 || msg.indexOf('configured') > -1) {
            reviewContent.innerHTML = '<div class="review-error">' + msg + '</div>';
        } else {
            reviewContent.innerHTML = '<div class="review-error">生成回顾失败：' + msg + '<br><small>请确认后端服务已启动且 LLM_API_KEY 已配置</small></div>';
        }
    });
}

// 页面加载时渲染历史记录
window.addEventListener('load', renderHistoryList);

// ========================================
// 旅行清单/打包建议
// ========================================
var PACKING_KEY = 'travel_planner_packing';

function initPackingList() {
    var section = document.getElementById('packingSection');
    if (!section) return;
    section.style.display = 'block';
    renderPackingList();
}

function getDefaultPackingItems(days) {
    var items = [
        { id: 'doc', category: '证件', name: '身份证/护照', checked: false },
        { id: 'cash', category: '证件', name: '现金/银行卡', checked: false },
        { id: 'phone', category: '电子', name: '手机及充电器', checked: false },
        { id: 'powerbank', category: '电子', name: '充电宝', checked: false },
        { id: 'camera', category: '电子', name: '相机/自拍杆', checked: false },
        { id: 'clothes', category: '衣物', name: '换洗衣物（' + days + '套）', checked: false },
        { id: 'jacket', category: '衣物', name: '外套/防晒衣', checked: false },
        { id: 'shoes', category: '衣物', name: '舒适步行鞋', checked: false },
        { id: 'umbrella', category: '日用', name: '雨伞/遮阳伞', checked: false },
        { id: 'toiletries', category: '日用', name: '洗漱用品', checked: false },
        { id: 'sunscreen', category: '日用', name: '防晒霜', checked: false },
        { id: 'mask', category: '日用', name: '口罩', checked: false },
        { id: 'medicine', category: '药品', name: '常用药品（感冒药、肠胃药等）', checked: false },
        { id: 'bandaid', category: '药品', name: '创可贴', checked: false },
        { id: 'snacks', category: '其他', name: '零食/水', checked: false },
        { id: 'bag', category: '其他', name: '背包/行李箱', checked: false },
        { id: 'tissue', category: '其他', name: '纸巾/湿巾', checked: false },
        { id: 'earphone', category: '电子', name: '耳机', checked: false },
    ];
    return items;
}

function getPackingItems() {
    try {
        var saved = JSON.parse(localStorage.getItem(PACKING_KEY));
        return saved || [];
    } catch(e) {
        return [];
    }
}

function savePackingItems(items) {
    try { localStorage.setItem(PACKING_KEY, JSON.stringify(items)); } catch(e) {}
}

function renderPackingList() {
    var list = document.getElementById('packingList');
    if (!list) return;
    var items = getPackingItems();
    if (items.length === 0) {
        var days = parseInt(document.getElementById('travelDays').value) || 3;
        items = getDefaultPackingItems(days);
        savePackingItems(items);
    }

    var categories = {};
    items.forEach(function(item) {
        if (!categories[item.category]) categories[item.category] = [];
        categories[item.category].push(item);
    });

    var checkedCount = items.filter(function(i) { return i.checked; }).length;
    var totalCount = items.length;
    var percent = Math.round((checkedCount / totalCount) * 100);

    var html = '<div class="packing-progress">' +
        '<div class="packing-progress-bar"><div class="packing-progress-fill" style="width:' + percent + '%"></div></div>' +
        '<div class="packing-progress-text">已准备 ' + checkedCount + '/' + totalCount + ' 项（' + percent + '%）</div>' +
    '</div>';

    Object.keys(categories).forEach(function(cat) {
        html += '<div class="packing-category">' +
            '<div class="packing-category-title">' + cat + '</div>' +
            categories[cat].map(function(item) {
                return '<label class="packing-item' + (item.checked ? ' checked' : '') + '">' +
                    '<input type="checkbox" class="packing-checkbox" ' + (item.checked ? 'checked' : '') + ' onchange="togglePackingItem(\'' + item.id + '\')">' +
                    '<span class="packing-item-name">' + item.name + '</span>' +
                '</label>';
            }).join('') +
        '</div>';
    });

    html += '<div class="packing-actions">' +
        '<button class="packing-reset-btn" onclick="resetPackingList()">重置清单</button>' +
    '</div>';

    list.innerHTML = html;
}

function togglePackingItem(id) {
    var items = getPackingItems();
    var found = false;
    items.forEach(function(item) {
        if (item.id === id) {
            item.checked = !item.checked;
            found = true;
        }
    });
    if (!found) {
        // 新建项
        items.push({ id: id, category: '自定义', name: id, checked: true });
    }
    savePackingItems(items);
    renderPackingList();
}

function resetPackingList() {
    if (confirm('确定要重置打包清单吗？')) {
        savePackingItems([]);
        renderPackingList();
    }
}

// ========================================
// 多目的地对比模式
// ========================================
function comparePlans() {
    var records = getHistoryRecords();
    if (records.length < 2) {
        showErrorToast('至少需要2条历史记录才能对比');
        return;
    }

    // 创建对比弹窗
    var overlay = document.createElement('div');
    overlay.className = 'compare-overlay';
    overlay.innerHTML = '<div class="compare-modal">' +
        '<div class="compare-header">' +
            '<h3>📊 方案对比</h3>' +
            '<button class="compare-close-btn" onclick="this.closest(\'.compare-overlay\').remove()">✕</button>' +
        '</div>' +
        '<div class="compare-body">' +
            '<div class="compare-selector">' +
                '<span>选择对比方案（最多3个）：</span>' +
                '<div class="compare-checkboxes">' +
                    records.slice(-5).reverse().map(function(r, i) {
                        return '<label class="compare-checkbox-label"><input type="checkbox" class="compare-checkbox" value="' + i + '" ' + (i < 2 ? 'checked' : '') + '>' + r.name + '</label>';
                    }).join('') +
                '</div>' +
                '<button class="compare-start-btn" onclick="startCompare()">开始对比</button>' +
            '</div>' +
            '<div class="compare-table-container" id="compareTableContainer"></div>' +
        '</div>' +
    '</div>';
    document.body.appendChild(overlay);

    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) overlay.remove();
    });

    // 自动开始对比
    setTimeout(function() { startCompare(); }, 100);
}

function startCompare() {
    var records = getHistoryRecords().slice(-5).reverse();
    var checkboxes = document.querySelectorAll('.compare-checkbox:checked');
    var selected = [];
    checkboxes.forEach(function(cb) {
        var idx = parseInt(cb.value);
        if (idx >= 0 && idx < records.length) selected.push(records[idx]);
    });

    if (selected.length < 2) {
        showErrorToast('请至少选择2个方案进行对比');
        return;
    }
    if (selected.length > 3) {
        showErrorToast('最多选择3个方案进行对比');
        return;
    }

    var container = document.getElementById('compareTableContainer');
    if (!container) return;

    var html = '<table class="compare-table">' +
        '<thead><tr>' +
            '<th>对比项</th>' +
            selected.map(function(r) { return '<th>' + r.name + '</th>'; }).join('') +
        '</tr></thead>' +
        '<tbody>' +
            '<tr><td>目的地</td>' + selected.map(function(r) { return '<td>' + (r.formData ? r.formData.destinationCity : '-') + '</td>'; }).join('') + '</tr>' +
            '<tr><td>出发城市</td>' + selected.map(function(r) { return '<td>' + (r.formData ? r.formData.departureCity : '-') + '</td>'; }).join('') + '</tr>' +
            '<tr><td>天数</td>' + selected.map(function(r) { return '<td>' + (r.formData ? r.formData.travelDays + '天' : '-') + '</td>'; }).join('') + '</tr>' +
            '<tr><td>预算</td>' + selected.map(function(r) { return '<td>¥' + (r.formData ? r.formData.budget : '-') + '</td>'; }).join('') + '</tr>' +
            '<tr><td>偏好</td>' + selected.map(function(r) {
                var prefMap = { nature: '自然风光', history: '历史人文', food: '美食探店', instagram: '网红打卡' };
                var prefs = (r.formData && r.formData.preferences) ? r.formData.preferences.map(function(p) { return prefMap[p] || p; }).join('、') : '-';
                return '<td>' + prefs + '</td>';
            }).join('') + '</tr>' +
            '<tr><td>景点数</td>' + selected.map(function(r) { return '<td>' + (r.attractionsData ? r.attractionsData.length : '-') + '个</td>'; }).join('') + '</tr>' +
            '<tr><td>酒店数</td>' + selected.map(function(r) { return '<td>' + (r.hotelsData ? r.hotelsData.length : '-') + '个</td>'; }).join('') + '</tr>' +
        '</tbody>' +
    '</table>';

    container.innerHTML = html;
}

// ========================================
// 语音输入
// ========================================
function initVoiceInput() {
    var departureInput = document.getElementById('departureInput');
    var destinationInput = document.getElementById('destinationInput');
    if (!departureInput || !destinationInput) return;

    addVoiceButton(departureInput, 'departureSearch');
    addVoiceButton(destinationInput, 'destinationSearch');
}

function addVoiceButton(inputEl, searchInputId) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'voice-input-btn';
    btn.title = '语音输入';
    btn.innerHTML = '🎤';
    btn.onclick = function(e) {
        e.stopPropagation();
        startVoiceInput(searchInputId, btn);
    };
    inputEl.parentNode.insertBefore(btn, inputEl.nextSibling);
}

function startVoiceInput(searchInputId, btn) {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        showErrorToast('您的浏览器不支持语音输入，请使用 Chrome 浏览器');
        return;
    }
    var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    var recognition = new SpeechRecognition();
    recognition.lang = 'zh-CN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    btn.style.background = '#ef4444';
    btn.style.color = '#fff';
    btn.textContent = '🔴';

    recognition.start();
    recognition.onresult = function(event) {
        var text = event.results[0][0].transcript;
        var searchInput = document.getElementById(searchInputId);
        if (searchInput) {
            searchInput.value = text;
            searchInput.dispatchEvent(new Event('input'));
        }
    };
    recognition.onerror = function() {
        showErrorToast('语音识别失败，请重试');
    };
    recognition.onend = function() {
        btn.style.background = '';
        btn.style.color = '';
        btn.textContent = '🎤';
    };
}
